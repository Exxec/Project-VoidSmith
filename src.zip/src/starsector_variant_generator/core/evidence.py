"""Shared, serializable provenance and uncertainty vocabulary."""
from __future__ import annotations
from dataclasses import dataclass
from enum import StrEnum
from typing import Any


class EvidenceClass(StrEnum):
    """How a fact was obtained, distinct from whether it is available."""

    DIRECT_DATA = "DIRECT_DATA"
    LOCAL_SOURCE_CODE = "LOCAL_SOURCE_CODE"
    LOCAL_CONFIG = "LOCAL_CONFIG"
    ADAPTER_MODELED = "ADAPTER_MODELED"
    CURATED_GUIDANCE = "CURATED_GUIDANCE"
    REVIEWER_EXPECTATION = "REVIEWER_EXPECTATION"
    INFERRED_MECHANICS = "INFERRED_MECHANICS"
    UNKNOWN = "UNKNOWN"
    CONFLICTING = "CONFLICTING"

@dataclass(frozen=True)
class EvidenceRecord:
    evidence_id: str
    entity_id: str
    source_file: str | None
    source_class: str | None
    source_line_or_symbol: str | None
    evidence_type: str
    extracted_value: Any
    confidence: float
    parser_or_adapter: str
    evidence_class: EvidenceClass = EvidenceClass.UNKNOWN
