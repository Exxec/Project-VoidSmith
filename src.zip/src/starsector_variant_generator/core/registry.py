from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Generic, Iterable, TypeVar

from starsector_variant_generator.core.models import Entity, Faction, ModInfo, ScanResult, Variant


T = TypeVar("T", bound=Entity)


@dataclass
class EntityIndex(Generic[T]):
    """Deterministic ID index that never resolves duplicate IDs by guessing."""

    by_id: dict[str, T] = field(default_factory=dict)
    duplicates: dict[str, list[T]] = field(default_factory=dict)

    @classmethod
    def build(cls, entities: Iterable[T]) -> "EntityIndex[T]":
        index = cls()
        for entity in entities:
            if entity.id in index.duplicates:
                # A third-or-later claimant of an already-ambiguous id. The
                # original two-branch version only ever populated
                # `duplicates` from the `by_id` branch below, so this case
                # (id already fully moved into `duplicates`, `by_id` no
                # longer holding it) matched neither branch and silently
                # dropped every claimant past the second -- verified against
                # a real install where "hegemony" has three real sources
                # (core, plus two unrelated mods each shipping a same-id
                # `hegemony.faction` patch file).
                index.duplicates[entity.id].append(entity)
            elif entity.id in index.by_id:
                index.duplicates[entity.id] = [index.by_id.pop(entity.id), entity]
            else:
                index.by_id[entity.id] = entity
        return index


@dataclass(frozen=True)
class UnresolvedReference:
    variant_id: str
    reference_type: str
    reference_id: str


@dataclass(frozen=True)
class MissingDependency:
    mod_id: str
    dependency_id: str


@dataclass
class Registry:
    hulls: EntityIndex = field(default_factory=EntityIndex)
    weapons: EntityIndex = field(default_factory=EntityIndex)
    fighters: EntityIndex = field(default_factory=EntityIndex)
    hullmods: EntityIndex = field(default_factory=EntityIndex)
    variants: EntityIndex = field(default_factory=EntityIndex)
    factions: EntityIndex = field(default_factory=EntityIndex)
    unresolved_references: list[UnresolvedReference] = field(default_factory=list)
    missing_dependencies: list[MissingDependency] = field(default_factory=list)

    @classmethod
    def from_scan(cls, scan: ScanResult) -> "Registry":
        registry = cls(
            hulls=EntityIndex.build(scan.hulls), weapons=EntityIndex.build(scan.weapons),
            fighters=EntityIndex.build(scan.fighters), hullmods=EntityIndex.build(scan.hullmods),
            variants=EntityIndex.build(scan.variants), factions=EntityIndex.build(scan.factions),
        )
        registry._resolve_variants(scan.variants)
        registry._resolve_dependencies(scan.mods)
        return registry

    def _resolve_variants(self, variants: Iterable[Variant]) -> None:
        for variant in variants:
            if variant.hull_id and variant.hull_id not in self.hulls.by_id:
                self.unresolved_references.append(UnresolvedReference(variant.id, "hull", variant.hull_id))
            for weapon_id in variant.weapons_by_mount.values():
                if weapon_id not in self.weapons.by_id:
                    self.unresolved_references.append(UnresolvedReference(variant.id, "weapon", weapon_id))
            for hullmod_id in variant.hullmods:
                if hullmod_id not in self.hullmods.by_id:
                    self.unresolved_references.append(UnresolvedReference(variant.id, "hullmod", hullmod_id))

    def _resolve_dependencies(self, mods: Iterable[ModInfo]) -> None:
        mod_list = list(mods)
        available = {mod.mod_id for mod in mod_list}
        for mod in mod_list:
            for dependency in mod.dependencies:
                if dependency not in available:
                    self.missing_dependencies.append(MissingDependency(mod.mod_id, dependency))

    def weapons_matching(self, size: str | None = None, mount_type: str | None = None) -> tuple[Entity, ...]:
        """Return only unambiguous indexed weapons matching explicit fields."""
        normalized_size = size.upper() if size else None
        normalized_type = mount_type.upper() if mount_type else None
        return tuple(
            weapon for weapon in sorted(self.weapons.by_id.values(), key=lambda item: item.id)
            if (normalized_size is None or (getattr(weapon, "size", "") or "").upper() == normalized_size)
            and (normalized_type is None or (getattr(weapon, "mount_type", "") or "").upper() == normalized_type)
        )

    def fighters_matching(self, role: str | None = None) -> tuple[Entity, ...]:
        """Return only unambiguous indexed fighter wings matching explicit fields."""
        normalized_role = role.upper() if role else None
        return tuple(
            fighter for fighter in sorted(self.fighters.by_id.values(), key=lambda item: item.id)
            if normalized_role is None or (getattr(fighter, "role", "") or "").upper() == normalized_role
        )

    def hullmods_matching(self, hidden: bool | None = None) -> tuple[Entity, ...]:
        """Return only unambiguous indexed hullmods matching explicit fields."""
        return tuple(
            hullmod for hullmod in sorted(self.hullmods.by_id.values(), key=lambda item: item.id)
            if hidden is None or bool(getattr(hullmod, "hidden", False)) == hidden
        )

    def hulls_matching(self, hull_size: str | None = None) -> tuple[Entity, ...]:
        """Return only unambiguous indexed hulls matching explicit fields."""
        normalized_size = hull_size.upper() if hull_size else None
        return tuple(
            hull for hull in sorted(self.hulls.by_id.values(), key=lambda item: item.id)
            if normalized_size is None or (getattr(hull, "hull_size", "") or "").upper() == normalized_size
        )

    def variants_for_hull(self, hull_id: str) -> tuple[Variant, ...]:
        return tuple(sorted((variant for variant in self.variants.by_id.values() if variant.hull_id == hull_id), key=lambda item: item.id))

    def _faction_candidates(self, faction_id: str) -> list[Faction]:
        return ([self.factions.by_id[faction_id]] if faction_id in self.factions.by_id
                else list(self.factions.duplicates.get(faction_id, [])))

    def resolve_faction(self, faction_id: str, source_mod: str | None = None) -> Faction | None:
        """Resolve a faction id to a single `Faction`, merging same-id sources.

        Starsector mods commonly ship a partial `<id>.faction` file that
        patches an existing faction (for example adding new hulls to
        Hegemony's `knownShips`) rather than redefining it from scratch --
        these collide on id under `EntityIndex.build`'s duplicate handling,
        which would otherwise make the whole faction id unresolvable and
        silently drop every known_* entry a patch file contributes (see
        docs/BUGS.md). When `source_mod` is not given, same-id candidates
        are merged: known_hulls/known_weapons/known_fighters/known_hullmods
        are unioned -- each entry is real, independently declared evidence
        from its own source file, so unioning never fabricates a claim --
        and identity fields (name/tags/etc.) are taken from whichever
        candidate declares the most complete identity evidence (a real name
        distinct from the bare id, more tags, more known equipment already).
        Passing `source_mod` still selects exactly one raw, unmerged source,
        for callers that need one mod's literal declared faction data.
        """
        candidates = self._faction_candidates(faction_id)
        if source_mod is not None:
            candidates = [faction for faction in candidates if faction.source_mod == source_mod]
            return candidates[0] if len(candidates) == 1 else None
        if not candidates:
            return None
        if len(candidates) == 1:
            return candidates[0]
        base = max(candidates, key=lambda faction: (
            faction.name != faction.id and bool(faction.name), len(faction.tags),
            len(faction.known_hulls) + len(faction.known_weapons) + len(faction.known_fighters) + len(faction.known_hullmods),
        ))
        return replace(
            base,
            known_hulls=tuple(sorted({item for faction in candidates for item in faction.known_hulls})),
            known_weapons=tuple(sorted({item for faction in candidates for item in faction.known_weapons})),
            known_fighters=tuple(sorted({item for faction in candidates for item in faction.known_fighters})),
            known_hullmods=tuple(sorted({item for faction in candidates for item in faction.known_hullmods})),
        )

    def faction_contributing_sources(self, faction_id: str) -> tuple[str, ...]:
        """Every `source_mod` that declares a faction file for this id, sorted."""
        return tuple(sorted({faction.source_mod for faction in self._faction_candidates(faction_id)}))

    def faction_equipment(self, faction_id: str, source_mod: str | None = None) -> dict[str, tuple[str, ...]]:
        faction = self.resolve_faction(faction_id, source_mod)
        if faction is None:
            provided = "; provide source_mod for overrides" if source_mod is None else ""
            raise ValueError(f"Faction not found or ambiguous: {faction_id}{provided}")
        return {
            "known_hulls": tuple(sorted(faction.known_hulls)),
            "known_weapons": tuple(sorted(faction.known_weapons)),
            "known_fighters": tuple(sorted(faction.known_fighters)),
            "known_hullmods": tuple(sorted(faction.known_hullmods)),
        }
