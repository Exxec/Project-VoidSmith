"""Qt-independent presentation state derived from normalized backend data."""
from __future__ import annotations

from dataclasses import dataclass

from starsector_variant_generator.core.models import Hull, ScanResult


@dataclass(frozen=True)
class HullListRecord:
    hull_id: str
    name: str
    hull_size: str
    source_mod: str
    role_hints: tuple[str, ...]


class HullCatalog:
    """Search/filter adapter only; it neither infers roles nor validates fits."""

    def __init__(self, hulls: tuple[Hull, ...]) -> None:
        self._hulls = hulls

    @classmethod
    def from_scan(cls, scan: ScanResult) -> HullCatalog:
        return cls(tuple(sorted(scan.hulls, key=lambda hull: (hull.name.casefold(), hull.source_mod, hull.id))))

    def hull_sizes(self) -> tuple[str, ...]:
        return tuple(sorted({hull.hull_size for hull in self._hulls if hull.hull_size}))

    def source_mods(self) -> tuple[str, ...]:
        return tuple(sorted({hull.source_mod for hull in self._hulls}))

    def filter(self, text: str = "", hull_size: str | None = None, source_mod: str | None = None) -> tuple[Hull, ...]:
        needle = text.strip().casefold()
        return tuple(hull for hull in self._hulls if
                     (not needle or needle in hull.name.casefold() or needle in hull.id.casefold()) and
                     (hull_size is None or hull.hull_size == hull_size) and
                     (source_mod is None or hull.source_mod == source_mod))
