"""Read-only Qt resource resolution for locally scanned hull artwork."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtGui import QPixmap

from starsector_variant_generator.core.models import Hull


class HullSpriteCache:
    """Resolve a hull's declared local sprite without copying or exporting it."""

    def __init__(self) -> None:
        self._cache: dict[Path, QPixmap | None] = {}

    def sprite_for(self, hull: Hull) -> QPixmap | None:
        sprite_name = hull.raw.get("ship_data", {}).get("spriteName") if isinstance(hull.raw.get("ship_data"), dict) else None
        if not isinstance(sprite_name, str) or not sprite_name.strip():
            return None
        source_root = _source_root(hull.source_path)
        candidate = _safe_sprite_path(source_root, sprite_name)
        if candidate is None:
            return None
        if candidate not in self._cache:
            pixmap = QPixmap(str(candidate)) if candidate.is_file() else QPixmap()
            self._cache[candidate] = pixmap if not pixmap.isNull() else None
        return self._cache[candidate]


def _source_root(source_path: Path) -> Path:
    """Return a hull CSV's source root (``<core-or-mod>/``), defensively."""
    # Standard source path is <root>/data/hulls/ship_data.csv.  A malformed
    # path is harmless: resolve only from its immediate parent tree.
    return source_path.parents[2] if len(source_path.parents) >= 3 else source_path.parent


def _safe_sprite_path(source_root: Path, sprite_name: str) -> Path | None:
    """Accept only a sprite path physically beneath the scanned source root."""
    try:
        relative = Path(sprite_name.replace("/", "\\"))
        if relative.suffix:
            candidates = (relative,)
        else:
            candidates = (relative.with_suffix(".png"), relative.with_suffix(".jpg"))
        root = source_root.resolve()
        for item in candidates:
            candidate = (root / item).resolve()
            if candidate.is_relative_to(root):
                return candidate
    except (OSError, ValueError):
        return None
    return None
