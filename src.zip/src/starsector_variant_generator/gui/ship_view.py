"""Interactive 2D ship graphics view with Starsector coordinate mapping and HUD callouts."""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional
from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QWheelEvent,
)
from PyQt6.QtWidgets import (
    QGraphicsItem,
    QGraphicsObject,
    QGraphicsScene,
    QGraphicsView,
    QWidget,
)


class ShipSpriteItem(QGraphicsObject):
    """Draws the ship hull sprite centered at the Starsector center of rotation (0, 0)."""

    def __init__(self, pixmap: QPixmap, center_x: float, center_y: float) -> None:
        super().__init__()
        self.pixmap = pixmap
        self.cx = float(center_x)
        self.cy = float(center_y)
        self.img_w = float(pixmap.width())
        self.img_h = float(pixmap.height())

    def boundingRect(self) -> QRectF:
        # Starsector (cx, cy) is measured from sprite bottom-left:
        # Top-left in Qt coordinates is (-cx, -(img_h - cy))
        return QRectF(-self.cx, -(self.img_h - self.cy), self.img_w, self.img_h)

    def paint(self, painter: QPainter, option: Any, widget: Optional[QWidget] = None) -> None:
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        top_left_x = -self.cx
        top_left_y = -(self.img_h - self.cy)
        painter.drawPixmap(int(top_left_x), int(top_left_y), self.pixmap)


class MountCalloutItem(QGraphicsItem):
    """HUD callout box with a dogleg leader line pointing to a weapon mount."""

    def __init__(
        self,
        mount_id: str,
        slot_type: str,
        slot_size: str,
        fitted_weapon: str,
        target_scene_pos: QPointF,
        is_left_side: bool,
    ) -> None:
        super().__init__()
        self.mount_id = mount_id
        self.slot_type = slot_type.upper()
        self.slot_size = slot_size.upper()
        self.fitted_weapon = fitted_weapon or "<Empty>"
        self.target_pos = target_scene_pos
        self.is_left_side = is_left_side

        self.box_width = 175.0
        self.box_height = 42.0

        # Colors matching Starsector HUD palette
        self.border_pen = QPen(QColor(0, 188, 212, 180), 1.2)
        self.line_pen = QPen(QColor(0, 220, 255, 200), 1.0)
        self.dot_pen = QPen(QColor(0, 255, 255, 255), 1.5)
        self.bg_brush = QBrush(QColor(8, 18, 28, 220))
        self.dot_brush = QBrush(QColor(0, 220, 255, 160))

        self.title_font = QFont("Segoe UI", 8, QFont.Weight.Bold)
        self.sub_font = QFont("Segoe UI", 7, QFont.Weight.DemiBold)

    def set_fitted_weapon(self, weapon_name: str) -> None:
        self.fitted_weapon = weapon_name or "<Empty>"
        self.update()

    def boundingRect(self) -> QRectF:
        box_rect = QRectF(0, 0, self.box_width, self.box_height)
        # Unite local box rect and the relative position of the target mount point
        rel_target = self.mapFromScene(self.target_pos)
        target_rect = QRectF(rel_target.x() - 6, rel_target.y() - 6, 12, 12)
        return box_rect.united(target_rect).adjusted(-10, -10, 10, 10)

    def paint(self, painter: QPainter, option: Any, widget: Optional[QWidget] = None) -> None:
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        # 1. Target Mount Reticle
        rel_target = self.mapFromScene(self.target_pos)
        painter.setPen(self.dot_pen)
        painter.setBrush(self.dot_brush)
        painter.drawEllipse(rel_target, 3.5, 3.5)
        painter.drawEllipse(rel_target, 6.0, 6.0)

        # 2. Leader Line (Dogleg)
        anchor_x = self.box_width if self.is_left_side else 0.0
        anchor_y = self.box_height / 2.0
        anchor = QPointF(anchor_x, anchor_y)

        elbow_offset = 24.0 if self.is_left_side else -24.0
        elbow = QPointF(anchor_x + elbow_offset, anchor_y)

        path = QPainterPath(anchor)
        path.lineTo(elbow)
        path.lineTo(rel_target)

        painter.setPen(self.line_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPath(path)

        # 3. Callout Box
        box_rect = QRectF(0, 0, self.box_width, self.box_height)
        painter.setPen(self.border_pen)
        painter.setBrush(self.bg_brush)
        painter.drawRoundedRect(box_rect, 3.0, 3.0)

        # 4. Text Details
        painter.setFont(self.title_font)
        painter.setPen(QColor(220, 240, 255))
        painter.drawText(
            QRectF(8, 4, self.box_width - 16, 16),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            f"{self.mount_id}: {self.fitted_weapon}",
        )

        painter.setFont(self.sub_font)
        painter.setPen(QColor(90, 160, 200))
        painter.drawText(
            QRectF(8, 20, self.box_width - 16, 16),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            f"{self.slot_size} {self.slot_type}",
        )


class ShipViewportView(QGraphicsView):
    """Zoomable/pannable viewport with a tech-grid background."""

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        super().__init__(parent)
        self.scene = QGraphicsScene(self)
        self.setScene(self.scene)

        self.setRenderHints(
            QPainter.RenderHint.Antialiasing
            | QPainter.RenderHint.SmoothPixmapTransform
            | QPainter.RenderHint.TextAntialiasing
        )
        self.setDragMode(QGraphicsView.DragMode.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setStyleSheet("background-color: #060e17; border: 1px solid #142838;")

        self.sprite_item: Optional[ShipSpriteItem] = None
        self.callout_items: Dict[str, MountCalloutItem] = {}

    def drawBackground(self, painter: QPainter, rect: QRectF) -> None:
        super().drawBackground(painter, rect)
        painter.fillRect(rect, QColor("#060e17"))

        # Tactical background grid
        grid_size = 40.0
        left = int(rect.left()) - (int(rect.left()) % int(grid_size))
        top = int(rect.top()) - (int(rect.top()) % int(grid_size))

        pen = QPen(QColor(16, 38, 58, 120), 0.75)
        painter.setPen(pen)

        x = float(left)
        while x < rect.right():
            painter.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))
            x += grid_size

        y = float(top)
        while y < rect.bottom():
            painter.drawLine(QPointF(rect.left(), y), QPointF(rect.right(), y))
            y += grid_size

    def wheelEvent(self, event: QWheelEvent) -> None:
        zoom_factor = 1.15 if event.angleDelta().y() > 0 else (1.0 / 1.15)
        self.scale(zoom_factor, zoom_factor)

    def zoom_in(self) -> None:
        self.scale(1.2, 1.2)

    def zoom_out(self) -> None:
        self.scale(1.0 / 1.2, 1.0 / 1.2)

    def fit_view(self) -> None:
        if self.scene.items():
            self.fitInView(self.scene.itemsBoundingRect().adjusted(-40, -40, 40, 40), Qt.AspectRatioMode.KeepAspectRatio)

    def load_ship(self, hull_data: Dict[str, Any], pixmap: Optional[QPixmap] = None) -> None:
        """Renders the hull and arranges callout tags with collision avoidance."""
        self.scene.clear()
        self.callout_items.clear()

        # Fallback dummy pixmap if no sprite image file is available
        if pixmap is None or pixmap.isNull():
            pixmap = QPixmap(180, 280)
            pixmap.fill(QColor(30, 50, 70, 180))

        # Starsector center offset
        center = hull_data.get("center", [pixmap.width() / 2.0, pixmap.height() / 2.0])
        cx, cy = float(center[0]), float(center[1])

        # 1. Add Sprite centered at (0, 0)
        self.sprite_item = ShipSpriteItem(pixmap, cx, cy)
        self.scene.addItem(self.sprite_item)

        # 2. Extract weapon mounts
        weapon_slots: List[Dict[str, Any]] = hull_data.get("weaponSlots", [])
        visible_slots = [
            slot for slot in weapon_slots
            if slot.get("type", "").upper() not in ("SYSTEM", "DECORATIVE")
            and slot.get("mount", "").upper() != "HIDDEN"
        ]

        left_slots: List[Dict[str, Any]] = []
        right_slots: List[Dict[str, Any]] = []

        for slot in visible_slots:
            loc = slot.get("loc", [0.0, 0.0])
            if loc[0] <= 0:
                left_slots.append(slot)
            else:
                right_slots.append(slot)

        # Sort slots from bow to stern (+Y Starsector = UP = -Y in Qt scene)
        left_slots.sort(key=lambda s: -s.get("loc", [0.0, 0.0])[1])
        right_slots.sort(key=lambda s: -s.get("loc", [0.0, 0.0])[1])

        half_w = max(cx, pixmap.width() - cx)

        # 3. Layout Left and Right Callouts
        self._layout_callout_column(left_slots, is_left=True, x_pos=-(half_w + 220.0))
        self._layout_callout_column(right_slots, is_left=False, x_pos=(half_w + 45.0))

        self.fit_view()

    def _layout_callout_column(
        self, slots: List[Dict[str, Any]], is_left: bool, x_pos: float
    ) -> None:
        if not slots:
            return

        box_height = 42.0
        min_spacing = 10.0
        slot_height_step = box_height + min_spacing

        # Calculate staggered target Y positions to avoid overlapping callout boxes
        target_positions: List[tuple[Dict[str, Any], QPointF, float]] = []
        for slot in slots:
            loc = slot.get("loc", [0.0, 0.0])
            # Starsector coordinates: +X starboard, +Y bow
            mount_pos = QPointF(float(loc[0]), -float(loc[1]))
            ideal_y = mount_pos.y() - (box_height / 2.0)
            target_positions.append((slot, mount_pos, ideal_y))

        # Relaxation pass from top to bottom
        adjusted_positions: List[float] = []
        for i, (_, _, ideal_y) in enumerate(target_positions):
            if i == 0:
                adjusted_positions.append(ideal_y)
            else:
                prev_y = adjusted_positions[i - 1]
                adjusted_positions.append(max(ideal_y, prev_y + slot_height_step))

        for (slot, mount_pos, _), callout_y in zip(target_positions, adjusted_positions):
            mount_id = slot.get("id", "WS 000")
            slot_type = slot.get("type", "UNIVERSAL")
            slot_size = slot.get("size", "SMALL")

            item = MountCalloutItem(
                mount_id=mount_id,
                slot_type=slot_type,
                slot_size=slot_size,
                fitted_weapon="",
                target_scene_pos=mount_pos,
                is_left_side=is_left,
            )
            item.setPos(x_pos, callout_y)
            self.scene.addItem(item)
            self.callout_items[mount_id] = item

    def update_fitted_weapons(self, weapon_map: Dict[str, str]) -> None:
        """Updates callout box labels when weapons are assigned."""
        for mount_id, weapon_name in weapon_map.items():
            if mount_id in self.callout_items:
                self.callout_items[mount_id].set_fitted_weapon(weapon_name)