"""Pure formatting helpers for GUI output; no scoring or rules live here."""
from __future__ import annotations

from typing import Any


def format_generation_results(assessed_candidates: list[dict[str, Any]], profile: str, flux_mode: str) -> str:
    """Render backend-supplied candidate evidence as compact, comparable cards."""
    lines = [f"PROFILE  {profile}    FLUX POSTURE  {flux_mode}", ""]
    if not assessed_candidates:
        return "\n".join([*lines, "No legal candidates were returned by the backend."])
    for index, item in enumerate(assessed_candidates, 1):
        build = item.get("build_archetype", {})
        label = item.get("recommendation_label") or build.get("role") or "Candidate"
        score = item.get("build_recommendation_score", item.get("quality", {}).get("final_score"))
        compatibility = build.get("compatibility")
        confidence = build.get("confidence")
        variant = item.get("variant", {}).get("id", "unknown")
        lines.append(f"{index}. {label}  |  {item.get('legality', 'UNKNOWN')}")
        lines.append(f"   Score: {score if score is not None else 'Unavailable'}   Compatibility: {compatibility if compatibility is not None else 'Unavailable'}   Confidence: {confidence if confidence is not None else 'Unavailable'}")
        lines.append(f"   Variant: {variant}")
        omissions = item.get("omissions")
        if omissions:
            lines.append(f"   Notes: {', '.join(str(value) for value in omissions)}")
        lines.append("")
    return "\n".join(lines).rstrip()
