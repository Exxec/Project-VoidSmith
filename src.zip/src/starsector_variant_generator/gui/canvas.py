"""Ship Fitting Canvas: the QGraphicsView-based technical fitting diagram.

Extracted from `gui/main_window.py` (Phase 35, GUI modularization) with no
behavior change -- `TechnicalCanvas` and its module-level constants/helpers
moved here verbatim; `main_window.py` re-imports the names it still needs
(`TechnicalCanvas`, `MOUNT_TYPE_COLORS`, `_detect_mirror_mount_pairs`) so
external references (including `tests/test_gui_canvas.py`, which imports
`TechnicalCanvas` and `_detect_mirror_mount_pairs` directly from
`starsector_variant_generator.gui.main_window`) keep working unchanged.
"""
from __future__ import annotations

from typing import Any

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QColor, QMouseEvent, QPainter, QPen, QWheelEvent
from PySide6.QtWidgets import QGraphicsScene, QGraphicsView

from starsector_variant_generator.core.models import Hull
from starsector_variant_generator.gui.resources import HullSpriteCache

# Real Starsector mount `type` values (core/mount_compatibility.py); colors
# chosen only for visual distinction, not a data claim. HYBRID/COMPOSITE/
# SYNERGY share a color family (all multi-type-accepting mounts) so the
# genuinely single-type BALLISTIC/ENERGY/MISSILE colors stay unambiguous.
MOUNT_TYPE_COLORS: dict[str, str] = {
    "BALLISTIC": "#e8743b", "ENERGY": "#24aaf2", "MISSILE": "#d69b27",
    "HYBRID": "#b967ff", "COMPOSITE": "#9d5ce0", "SYNERGY": "#7f4fd1", "UNIVERSAL": "#d7e4ee",
}
_MOUNT_TYPE_COLOR_FALLBACK = "#7d93a3"
# Box half-extent in scene units by declared weapon size -- a UI legibility
# choice, not a claim about real in-game hardpoint dimensions.
_MOUNT_BOX_HALF_EXTENT: dict[str, float] = {"SMALL": 9.0, "MEDIUM": 14.0, "LARGE": 20.0}
_MOUNT_BOX_HALF_EXTENT_FALLBACK = 11.0


class TechnicalCanvas(QGraphicsView):
    """Weapon mounts render as clickable, type-colored boxes directly on the
    hull sprite -- clicking one opens the same backend-filtered weapon
    picker the (now-removed) side list used to, via `slot_clicked`."""

    slot_clicked = Signal(str)

    def __init__(self) -> None:
        self.scene_ = QGraphicsScene()
        super().__init__(self.scene_)
        self.setRenderHint(QPainter.Antialiasing)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self._sprites = HullSpriteCache()
        # scene-space (x1, y1, x2, y2) hit boxes for slots that accept a
        # click -- built-in mounts are shown but omitted here, so clicking
        # one falls through to the normal view-drag/pan behavior instead.
        self._slot_hit_boxes: dict[str, tuple[float, float, float, float]] = {}
        self.show_empty()

    def wheelEvent(self, event: QWheelEvent) -> None:  # type: ignore[override]
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        self.scale(factor, factor)

    def mousePressEvent(self, event: QMouseEvent) -> None:  # type: ignore[override]
        if event.button() == Qt.LeftButton:
            point = self.mapToScene(event.position().toPoint())
            for slot_id, (x1, y1, x2, y2) in self._slot_hit_boxes.items():
                if x1 <= point.x() <= x2 and y1 <= point.y() <= y2:
                    self.slot_clicked.emit(slot_id)
                    return
        super().mousePressEvent(event)

    def reset_view(self) -> None:
        self.resetTransform()
        bounds = self.scene_.itemsBoundingRect()
        if not bounds.isNull():
            self.fitInView(bounds.adjusted(-35, -35, 35, 35), Qt.KeepAspectRatio)

    def zoom_in(self) -> None:
        self.scale(1.15, 1.15)

    def zoom_out(self) -> None:
        self.scale(1 / 1.15, 1 / 1.15)

    def show_empty(self) -> None:
        self.scene_.clear()
        text = self.scene_.addText("Select a scanned hull to inspect normalized fitting data")
        text.setDefaultTextColor(QColor("#91a8b7"))

    def show_hull(self, hull: Hull, weapons: dict[str, str] | None = None) -> None:
        self.scene_.clear()
        self.resetTransform()
        self._slot_hit_boxes = {}
        sprite = self._sprites.sprite_for(hull)
        ship_data = hull.raw.get("ship_data", {}) if isinstance(hull.raw.get("ship_data"), dict) else {}
        width, height = _number(ship_data.get("width"), 320.0), _number(ship_data.get("height"), 180.0)
        center = ship_data.get("center", [0.0, 0.0])
        center_x = _number(center[0], 0.0) if isinstance(center, list) and len(center) >= 2 else 0.0
        center_y = _number(center[1], 0.0) if isinstance(center, list) and len(center) >= 2 else 0.0
        # Per the Starsector modding wiki (File overview: ship /
        # Modding:Weapon Slots): "the defined center of the ship is defined
        # as a set of Cartesian coordinates relative to the most bottom-left
        # pixel of the sprite. The defined center point is the relative
        # reference point for ... weaponSlots" -- i.e. weapon locations are
        # ALREADY given relative to `center` (not needing a further
        # subtraction of it, which the previous code did, silently shifting
        # every mount off the ship), and `center` itself is measured
        # bottom-left-origin/Y-up in sprite pixels, not the naive
        # top-left/Y-down of a raw QPixmap. Confirmed against a real
        # screenshot of a live 25-mount capital hull whose mount boxes
        # rendered nowhere near the ship under the old (wrong) formula.
        if sprite is not None:
            image = self.scene_.addPixmap(sprite)
            image.setOffset(-center_x, center_y - sprite.height())
            top_edge = center_y - sprite.height()
        else:
            outline = self.scene_.addRect(-center_x, center_y - height, width, height, QPen(QColor("#28536b"), 2))
            outline.setToolTip("Local hull sprite unavailable; geometry outline only.")
            top_edge = center_y - height
        # Positioned above the sprite's real top edge (not the scene origin,
        # which sits at the ship's declared center and would otherwise be
        # drawn over by the sprite itself, added after this text -- a real,
        # previously-invisible rendering bug found by comparing a live
        # screenshot against this code).
        title = self.scene_.addText(f"{hull.name or hull.id}\n{len(hull.weapon_mounts)} parsed weapon mounts")
        title.setDefaultTextColor(QColor("#d7e4ee")); title.setPos(-title.boundingRect().width() / 2, top_edge - 46)
        plotted = 0
        for slot in hull.weapon_mounts:
            loc = slot.get("locations")
            if not isinstance(loc, list) or len(loc) < 2 or not all(isinstance(x, (float, int)) for x in loc[:2]):
                continue
            # Already relative to `center` (see the wiki citation above) --
            # only the Y sign flips, for Cartesian-Y-up (game data) vs
            # Qt's Y-down scene convention.
            x, y = float(loc[0]), -float(loc[1])
            mount_type = str(slot.get("type", "")).upper()
            mount_size = str(slot.get("size", "")).upper()
            color = QColor(MOUNT_TYPE_COLORS.get(mount_type, _MOUNT_TYPE_COLOR_FALLBACK))
            half = _MOUNT_BOX_HALF_EXTENT.get(mount_size, _MOUNT_BOX_HALF_EXTENT_FALLBACK)
            slot_id = str(slot.get("id", "slot"))
            selected_weapon = (weapons or {}).get(slot_id)
            built_in = slot_id in hull.built_in_weapons
            if built_in:
                box = self.scene_.addRect(x - half, y - half, half * 2, half * 2, QPen(QColor("#465866"), 1, Qt.DashLine))
                box.setToolTip(f"{slot_id}: built-in mount, filled automatically -- not selectable ({mount_type or 'UNKNOWN'}).")
            else:
                fill = QColor(color); fill.setAlpha(80 if selected_weapon else 0)
                box = self.scene_.addRect(x - half, y - half, half * 2, half * 2, QPen(color, 2), fill)
                action = f"click to change (currently {selected_weapon})" if selected_weapon else "click to assign a weapon"
                box.setToolTip(f"{slot_id}: {mount_type or 'UNKNOWN'} {mount_size or 'UNKNOWN'} mount -- {action}")
                self._slot_hit_boxes[slot_id] = (x - half, y - half, x + half, y + half)
            plotted += 1
        # No external leader-line callouts (removed): on a hull with many
        # mounts (confirmed on a real 25-mount capital hull) they sprawled
        # far enough past the ship that fitInView had to zoom out to fit
        # them all, shrinking the actual ship -- and the clickable boxes on
        # it -- to a barely-visible speck. The boxes' color/size/tooltip
        # already carry the same information the callouts duplicated.
        complex_note = "  •  Composite module behavior is not modeled." if "SHIP_WITH_MODULES" in {hint.upper() for hint in hull.hull_hints} else ""
        note = self.scene_.addText(("Click a highlighted mount to assign a weapon." if self._slot_hit_boxes else ("No parsed slot geometry available." if not plotted else "All parsed mounts are built-in.")) + complex_note)
        note.setDefaultTextColor(QColor("#91a8b7")); note.setPos(-note.boundingRect().width() / 2, -top_edge + 14)
        self.reset_view()

    def drawBackground(self, painter: QPainter, rect: Any) -> None:  # type: ignore[override]
        painter.fillRect(rect, QColor("#061019")); painter.setPen(QPen(QColor("#10293a"), 1))
        for x in range(int(rect.left()) - int(rect.left()) % 32, int(rect.right()), 32):
            painter.drawLine(x, rect.top(), x, rect.bottom())
        for y in range(int(rect.top()) - int(rect.top()) % 32, int(rect.bottom()), 32):
            painter.drawLine(rect.left(), y, rect.right(), y)


def _number(value: object, fallback: float) -> float:
    return float(value) if isinstance(value, (int, float)) else fallback


_MIRROR_MATCH_TOLERANCE = 0.75


def _detect_mirror_mount_pairs(hull: Hull) -> dict[str, str]:
    """Detect left/right mirror-symmetric weapon-mount pairs from a hull's
    real parsed `.ship` geometry (`weaponSlots`' `locations`/`angle`/`arc`/
    `size`/`type`/`mount` fields -- the same raw data the canvas already
    reads to place slot markers).

    Starsector hulls are built bow/stern-asymmetric (a distinct nose and
    engine block, never a fore-aft mirror image), so only a left/right axis
    is ever geometrically meaningful here -- there is no equivalent
    "horizontal" mirror to detect. A mount pairs with another only when its
    position, angle, arc, size, mount kind, and weapon type all match the
    exact mirror image of another mount's (x unchanged, y negated, angle
    negated mod 360), within a small tolerance for non-integer coordinates.
    Centerline mounts (y == 0) and mounts with no matching counterpart are
    left unpaired -- Mirror is then a no-op for that slot, not a guess.
    Verified against real hulls: Hammerhead's 8 mounts pair perfectly (4
    pairs); Odyssey's 19 mounts produce exactly 1 real pair, correctly
    leaving the rest -- deliberately scattered, unique turret placements --
    unpaired rather than forcing a false match.
    """
    entries: list[tuple[str, float, float, float, Any, Any, Any, Any]] = []
    for slot in hull.weapon_mounts:
        slot_id = slot.get("id")
        loc = slot.get("locations")
        if not slot_id or not isinstance(loc, list) or len(loc) < 2:
            continue
        try:
            x, y = float(loc[0]), float(loc[1])
            angle = float(slot.get("angle", 0.0))
        except (TypeError, ValueError):
            continue
        entries.append((str(slot_id), x, y, angle, slot.get("arc"), slot.get("size"), slot.get("type"), slot.get("mount")))

    pairs: dict[str, str] = {}
    for i, (id_a, x_a, y_a, angle_a, arc_a, size_a, type_a, mount_a) in enumerate(entries):
        if id_a in pairs or abs(y_a) < _MIRROR_MATCH_TOLERANCE:
            continue
        for id_b, x_b, y_b, angle_b, arc_b, size_b, type_b, mount_b in entries[i + 1:]:
            if id_b in pairs:
                continue
            if abs(x_a - x_b) > _MIRROR_MATCH_TOLERANCE or abs(y_a + y_b) > _MIRROR_MATCH_TOLERANCE:
                continue
            if arc_a != arc_b or size_a != size_b or type_a != type_b or mount_a != mount_b:
                continue
            angle_sum = (angle_a + angle_b) % 360.0
            if angle_sum > _MIRROR_MATCH_TOLERANCE and angle_sum < 360.0 - _MIRROR_MATCH_TOLERANCE:
                continue
            pairs[id_a] = id_b
            pairs[id_b] = id_a
            break
    return pairs
