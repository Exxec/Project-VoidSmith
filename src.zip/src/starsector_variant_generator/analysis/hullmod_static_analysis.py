"""Offline static recognition of a bounded subset of HullMod Java effects.

Evidence-tier note (see AGENTS.md's "Scripted-mechanic analyzer hierarchy"
and ROADMAP.md Phase 28): this module is tier 2 (local source static
analysis) combined with tier 3 (a versioned known-API-call registry --
`API_EFFECT_REGISTRY_VERSION`/`_CALLS` below). Recognized effects are
resolved from two sub-tiers, both still local-source-only and never a
guess:

  1. A bare numeric literal or a single already-declared `static final`
     constant used directly as the modifier's value argument (e.g.
     `modifyFlat(id, 20f)` or `modifyPercent(id, SPEED_BONUS)`).
  2. A bounded arithmetic expression built only from numeric literals and
     locally-declared constants -- `+`, `-`, `*`, `/`, and unary +/- only
     (e.g. `modifyPercent(id, -HULL_PENALTY)` or
     `modifyMult(id, 1f - (0.01f * RECOIL_BONUS))`). See
     `_fold_constant_expression`. Measured against this project's own real
     149-mod local install (2026-08-25), counting only calls to the
     registered `_CALLS` stat accessors above (the same scope this
     analyzer already recognized, not every `stats.getX()` call in the
     install): of 2,776 real `stats.get<RegisteredAccessor>().
     modifyFlat/Percent/Mult(...)` calls found across all installed mods'
     Java source, the prior single-token-only logic (sub-tier 1) recognized
     1,144 (41%); this expression-folding extension (sub-tier 2) recognizes
     491 more (18%, ~43% relative increase) across 247 distinct files,
     while the remaining 1,141 correctly stay unresolved because they
     reference a genuine runtime value (a method parameter, an instance
     field, a loop variable) that cannot be a compile-time constant --
     never guessed at, exactly like sub-tier 1 already refused to guess at
     a bare unresolvable identifier. One concrete real example: the
     "1130的蔚蓝联邦 translated" mod's real `AF_OpenAmmoDepot` hullmod
     (`data.hullmods.AF_OpenAmmoDepot`) declares
     `public static final float HULL_PENALTY = 25f;` and applies
     `stats.getHullBonus().modifyPercent(id, -HULL_PENALTY);` -- entirely
     unrecognized before this change (a unary-minus expression, not a bare
     literal or identifier), now recognized as `hull_hp PERCENT_ADD -25.0`
     at confidence 0.85.

Any name the expression folder cannot resolve to a local constant --
including a constant declared in a *different* file (tier 4, "referenced
local config/constants", genuinely still unimplemented) or any method
call/attribute access/comparison -- makes the whole expression unresolved
rather than partially guessed, so `UNKNOWN_SCRIPTED_EFFECT` remains the
honest fallback exactly as before.

Known simplification: `_CONSTANT` (and this expression folder) treats
every locally declared `int`/`float`/`double` constant as a Python float,
so a real Java *integer* division between two `int` constants (which
truncates in Java) would be folded here using true division instead. No
real occurrence of that specific shape was found in the measurement above
(every real division case in the local install already carries an
explicit `f`/`F`/`d`/`D` float suffix on at least one literal operand,
matching Java's own promotion-to-float rule), but this remains a
documented, not fully eliminated, edge case rather than a fixed one.
"""
from __future__ import annotations

import ast
import re
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path
from typing import Mapping

from starsector_variant_generator.core.evidence import EvidenceClass, EvidenceRecord
from starsector_variant_generator.core.models import Hullmod

API_EFFECT_REGISTRY_VERSION = "starsector-api-effects-0.3"
_CALLS = {
    "getMaxSpeed": ("max_speed", "SELF"), "getAcceleration": ("acceleration", "SELF"),
    "getDeceleration": ("deceleration", "SELF"), "getTurnAcceleration": ("turn_acceleration", "SELF"),
    "getMaxTurnRate": ("max_turn_rate", "SELF"), "getFluxDissipation": ("flux_dissipation", "SELF"),
    "getFluxCapacity": ("flux_capacity", "SELF"), "getArmorBonus": ("armor_rating", "SELF"),
    "getHullBonus": ("hull_hp", "SELF"), "getSuppliesPerMonth": ("supplies_per_month", "SELF"),
    "getBallisticWeaponFluxCostMod": ("ballistic_weapon_flux_cost", "SELF"),
    "getEnergyWeaponFluxCostMod": ("energy_weapon_flux_cost", "SELF"),
    "getMissileWeaponFluxCostMod": ("missile_weapon_flux_cost", "SELF"),
    "getWeaponTurnRateBonus": ("weapon_turn_rate", "SELF"), "getSightRadiusMod": ("sight_radius", "SELF"),
}
_CALL_START = re.compile(r"stats\.(get\w+)\(\)\.(modifyFlat|modifyPercent|modifyMult)\(")
_CONSTANT = re.compile(r"(?:static\s+final\s+)?(?:float|double|int)\s+(\w+)\s*=\s*([-+]?\d+(?:\.\d+)?)")
_HULL_SIZE = re.compile(r"ShipAPI\.HullSize\.([A-Z_]+)")
_JAVA_NUMERIC_SUFFIX = re.compile(r"(\d)[fFdD](?!\w)")
_BARE_NUMERIC_LITERAL = re.compile(r"[-+]?\d+(?:\.\d+)?$")
_BARE_IDENTIFIER = re.compile(r"[A-Za-z_]\w*$")


class _UnresolvedExpression(Exception):
    """Raised internally when an expression node is not a compile-time constant."""


_ALLOWED_BINOPS = (ast.Add, ast.Sub, ast.Mult, ast.Div)


def _eval_constant_node(node: ast.AST, constants: Mapping[str, float]) -> float:
    """Evaluate a restricted arithmetic AST node against known local constants.

    Only numeric literals, resolved names, unary +/-, and +/-/*// between
    two already-resolved operands are supported -- no calls, attribute
    access, comparisons, subscripts, or any other node type. Anything else
    (including a name this file never declared as a constant) raises
    `_UnresolvedExpression` rather than being approximated.
    """
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return float(node.value)
    if isinstance(node, ast.Name):
        if node.id in constants:
            return constants[node.id]
        raise _UnresolvedExpression(node.id)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        value = _eval_constant_node(node.operand, constants)
        return value if isinstance(node.op, ast.UAdd) else -value
    if isinstance(node, ast.BinOp) and isinstance(node.op, _ALLOWED_BINOPS):
        left = _eval_constant_node(node.left, constants)
        right = _eval_constant_node(node.right, constants)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if right == 0:
            raise _UnresolvedExpression("division by zero")
        return left / right
    raise _UnresolvedExpression(type(node).__name__)


def _fold_constant_expression(expr: str, constants: Mapping[str, float]) -> float | None:
    """Constant-fold a bounded arithmetic expression, or return None.

    `None` covers both a genuinely unresolvable name and a Python syntax
    error (e.g. a Java-only construct this restricted grammar doesn't
    parse at all) -- both are treated identically as "not statically
    resolvable", never a guess.
    """
    normalized = _JAVA_NUMERIC_SUFFIX.sub(r"\1", expr)
    try:
        tree = ast.parse(normalized, mode="eval")
    except SyntaxError:
        return None
    try:
        return _eval_constant_node(tree.body, constants)
    except _UnresolvedExpression:
        return None


def _resolve_modifier_value(raw_expr: str, constants: Mapping[str, float]) -> tuple[float | None, bool]:
    """Resolve a modifier call's value argument to a float, if possible.

    Returns `(value, is_simple)`. `is_simple` is True for a bare numeric
    literal or a single already-declared constant (the original, narrower
    recognition this analyzer always supported -- confidence stays at the
    prior 0.9), and False for a multi-term arithmetic expression resolved
    only via the newer constant-expression folding (confidence 0.85,
    reflecting that the value is synthesized from combining local
    constants rather than read as a single already-declared quantity).
    """
    token = raw_expr.strip()
    bare_numeric = _JAVA_NUMERIC_SUFFIX.sub(r"\1", token)
    if _BARE_NUMERIC_LITERAL.fullmatch(bare_numeric):
        return float(bare_numeric), True
    if _BARE_IDENTIFIER.fullmatch(token):
        value = constants.get(token)
        return (value, True) if value is not None else (None, True)
    return _fold_constant_expression(token, constants), False


def _extract_call_arguments(line: str, args_start: int) -> list[str] | None:
    """Split a call's argument list on top-level commas, honoring nested parens.

    `args_start` is the index of the character immediately after the
    call's opening `(`. Returns `None` if the matching closing paren is
    not found on this same line -- this analyzer is deliberately
    single-line/bounded (matching its prior line-by-line design), so a
    genuinely multi-line call falls through to the existing "unrecognized
    API modifier expression" evidence rather than being guessed at.
    """
    depth = 1
    args: list[str] = []
    current = ""
    for ch in line[args_start:]:
        if ch == "(":
            depth += 1
            current += ch
        elif ch == ")":
            depth -= 1
            if depth == 0:
                if current.strip():
                    args.append(current.strip())
                return args
            current += ch
        elif ch == "," and depth == 1:
            args.append(current.strip())
            current = ""
        else:
            current += ch
    return None


@lru_cache(maxsize=256)
def _java_sources(source_root: str) -> tuple[tuple[Path, str], ...]:
    """Read each local Java source once per scan process/source root.

    This is deliberately an in-memory scan-local cache, not a persistent cache:
    source files remain the source of truth for each independent scan.
    """
    root = Path(source_root)
    sources: list[tuple[Path, str]] = []
    for path in sorted(root.rglob("*.java")):
        try:
            sources.append((path, path.read_text(encoding="utf-8")))
        except (OSError, UnicodeError):
            continue
    return tuple(sources)

@dataclass(frozen=True)
class HullmodEffectRecord:
    target_stat: str
    operation: str
    numeric_value: float
    applicability: str
    condition: str | None
    source_location: str
    confidence: float
    api_registry_version: str
    hull_size: str | None = None

@dataclass(frozen=True)
class HullmodStaticAnalysis:
    hullmod_id: str
    source_files: tuple[str, ...]
    source_association: str
    recognized_effects: tuple[HullmodEffectRecord, ...]
    unknown_scripted_portions: tuple[str, ...]
    confidence: float
    evidence: tuple[EvidenceRecord, ...] = ()

def analyze_hullmod_sources(hullmod: Hullmod, source_root: Path | None) -> HullmodStaticAnalysis:
    if source_root is None or not source_root.is_dir():
        return HullmodStaticAnalysis(hullmod.id, (), "NO_LOCAL_SOURCE", (), ("UNKNOWN_SCRIPTED_EFFECT: no readable local Java source root.",), 0.0, ())
    script = str(hullmod.raw.get("script", hullmod.raw.get("scriptClass", "")))
    script_class = script.rsplit(".", 1)[-1] if script else ""
    declared_candidates: list[tuple[Path, str]] = []
    reference_candidates: list[tuple[Path, str]] = []
    for path, text in _java_sources(str(source_root.resolve())):
        # The CSV script class is the authoritative local association.  Do not
        # merge classes that merely mention a hullmod ID when that class exists:
        # doing so makes unrelated API calls look like hullmod effects.
        if script_class and path.stem == script_class:
            declared_candidates.append((path, text))
        elif hullmod.id in text:
            reference_candidates.append((path, text))
    candidates = declared_candidates or reference_candidates
    association = "DECLARED_SCRIPT_CLASS" if declared_candidates else "ID_REFERENCE_FALLBACK"
    if not candidates:
        return HullmodStaticAnalysis(hullmod.id, (), "NO_ASSOCIATED_CLASS", (), ("UNKNOWN_SCRIPTED_EFFECT: no local Java class could be associated with this hullmod.",), 0.0, ())
    effects, unknown, evidence = [], [], []
    if association == "ID_REFERENCE_FALLBACK":
        unknown.append("UNKNOWN_SCRIPTED_EFFECT: source association is an ID-reference fallback, not a declared script class.")
    for path, text in candidates:
        constants = {name: float(value) for name, value in _CONSTANT.findall(text)}
        lines = text.splitlines()
        for line_no, line in enumerate(lines, 1):
            call_match = _CALL_START.search(line)
            if call_match and call_match.group(1) in _CALLS:
                call_args = _extract_call_arguments(line, call_match.end())
                if call_args is not None and len(call_args) >= 2:
                    raw_value_expr = call_args[1]
                    value, is_simple = _resolve_modifier_value(raw_value_expr, constants)
                    if value is None:
                        kind = "non-literal modifier value" if is_simple else "modifier value expression"
                        unknown.append(f"UNKNOWN_SCRIPTED_EFFECT: {path}:{line_no}: {kind} {raw_value_expr!r} is not statically resolvable.")
                        continue
                    operation = {"modifyFlat": "FLAT_ADD", "modifyPercent": "PERCENT_ADD", "modifyMult": "MULTIPLY"}[call_match.group(2)]
                    stat, applicability = _CALLS[call_match.group(1)]
                    location = f"{path}:{line_no}"
                    hull_size = _enclosing_hull_size(lines, line_no - 1)
                    condition = f"ShipAPI.HullSize.{hull_size}" if hull_size else ("conditional context not statically interpreted" if "if (" in line else None)
                    confidence = .9 if is_simple else .85
                    effect = HullmodEffectRecord(stat, operation, value, applicability, condition, location, confidence, API_EFFECT_REGISTRY_VERSION, hull_size)
                    effects.append(effect)
                    evidence.append(EvidenceRecord(
                        evidence_id=f"hullmod:{hullmod.id}:java:{path.stem}:{line_no}:{stat}", entity_id=hullmod.id,
                        source_file=str(path), source_class=path.stem, source_line_or_symbol=str(line_no),
                        evidence_type="HULLMOD_EFFECT", extracted_value=asdict(effect), confidence=confidence,
                        parser_or_adapter=f"api-effect-registry:{API_EFFECT_REGISTRY_VERSION}",
                        evidence_class=EvidenceClass.LOCAL_SOURCE_CODE,
                    ))
                else:
                    unknown.append(f"UNKNOWN_SCRIPTED_EFFECT: {path}:{line_no}: unrecognized API modifier expression.")
            elif ".modify" in line or "stats." in line and "get" in line:
                unknown.append(f"UNKNOWN_SCRIPTED_EFFECT: {path}:{line_no}: unrecognized API modifier expression.")
    if not effects and not unknown:
        unknown.append("UNKNOWN_SCRIPTED_EFFECT: associated local Java class contains no recognized normalized stat modifier.")
    confidence = .9 if effects and not unknown else (.6 if effects else .2)
    return HullmodStaticAnalysis(hullmod.id, tuple(str(path) for path, _ in candidates), association, tuple(effects), tuple(unknown), confidence, tuple(evidence))

def static_analysis_record(analysis: HullmodStaticAnalysis) -> dict:
    return asdict(analysis)


def _enclosing_hull_size(lines: list[str], line_index: int) -> str | None:
    """Find the nearest simple local hull-size branch without interpreting code flow.

    This is deliberately bounded to the current lexical block. Nested control
    flow, variables, and method calls remain represented by the separate
    condition/unknown evidence rather than being guessed.
    """
    depth = 0
    for source in reversed(lines[:line_index]):
        depth += source.count("}") - source.count("{")
        match = _HULL_SIZE.search(source)
        if match and "if" in source and depth <= 1:
            return match.group(1)
        if depth > 1:
            break
    return None
