"""Portable reviewer-label calibration records for deterministic outputs.

Fixtures deliberately contain only entity fingerprints and reviewer labels, not
copied Starsector/mod records.  They measure whether a generated observation
agrees with a locally reviewed expectation; they never adjust heuristics by
themselves.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any

from starsector_variant_generator.core.evidence import EvidenceClass

CALIBRATION_SCHEMA_VERSION = "calibration-labels-0.1"


class CalibrationStrength(StrEnum):
    HARD_EXPECTATION = "HARD_EXPECTATION"
    SOFT_EXPECTATION = "SOFT_EXPECTATION"
    OBSERVATION = "OBSERVATION"


class CalibrationExpectationKind(StrEnum):
    BUILD_EXPECTATION = "BUILD_EXPECTATION"
    EQUIPMENT_EXPECTATION = "EQUIPMENT_EXPECTATION"
    FACTION_EXPECTATION = "FACTION_EXPECTATION"
    SCENARIO_EXPECTATION = "SCENARIO_EXPECTATION"
    NEGATIVE_EXPECTATION = "NEGATIVE_EXPECTATION"


@dataclass(frozen=True)
class CalibrationLabel:
    entity_key: str
    entity_hash: str
    label: str
    expected: str
    expectation_kind: CalibrationExpectationKind = CalibrationExpectationKind.BUILD_EXPECTATION
    expected_any: tuple[str, ...] = ()
    strength: CalibrationStrength = CalibrationStrength.HARD_EXPECTATION
    note: str | None = None
    evidence_class: EvidenceClass = EvidenceClass.REVIEWER_EXPECTATION


@dataclass(frozen=True)
class CalibrationReport:
    schema_version: str
    fixture_id: str
    heuristic_set: str
    evaluated: int
    matched: int
    mismatched: int
    stale: int
    unsupported: int
    results: tuple[dict[str, object], ...]


def load_calibration_labels(path: Path) -> tuple[str, tuple[CalibrationLabel, ...]]:
    """Load a neutral local fixture, rejecting incomplete or unknown schemas."""
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or raw.get("schema_version") != CALIBRATION_SCHEMA_VERSION:
        raise ValueError(f"Unsupported calibration fixture: {path}")
    fixture_id = raw.get("fixture_id")
    labels = raw.get("labels")
    if not isinstance(fixture_id, str) or not fixture_id or not isinstance(labels, list):
        raise ValueError("Calibration fixture requires fixture_id and labels")
    normalized: list[CalibrationLabel] = []
    for entry in labels:
        if not isinstance(entry, dict) or not all(isinstance(entry.get(key), str) and entry[key] for key in ("entity_key", "entity_hash", "label", "expected")):
            raise ValueError("Each calibration label requires entity_key, entity_hash, label, and expected")
        expected_any = entry.get("expected_any", [])
        if not isinstance(expected_any, list) or not all(isinstance(item, str) and item for item in expected_any):
            raise ValueError("expected_any must be an array of non-empty strings")
        strength = entry.get("strength", CalibrationStrength.HARD_EXPECTATION)
        try: strength = CalibrationStrength(strength)
        except ValueError as exc: raise ValueError("Unknown calibration strength") from exc
        kind = entry.get("expectation_kind", CalibrationExpectationKind.BUILD_EXPECTATION)
        try: kind = CalibrationExpectationKind(kind)
        except ValueError as exc: raise ValueError("Unknown calibration expectation kind") from exc
        note = entry.get("note")
        if note is not None and not isinstance(note, str):
            raise ValueError("Calibration note must be text when supplied")
        normalized.append(CalibrationLabel(entry["entity_key"], entry["entity_hash"], entry["label"], entry["expected"], kind, tuple(expected_any), strength, note))
    return fixture_id, tuple(normalized)


def evaluate_calibration(
    fixture_id: str,
    labels: tuple[CalibrationLabel, ...],
    observations: dict[str, dict[str, Any]],
    heuristic_set: str,
) -> CalibrationReport:
    """Compare labels with caller-supplied normalized observations.

    An observation must provide the source hash used for review and may provide
    an ``actual`` value. Missing actual values are ``UNSUPPORTED``; a changed
    hash is ``STALE``. Neither is counted as a heuristic mismatch.
    """
    results: list[dict[str, object]] = []
    matched = mismatched = stale = unsupported = 0
    for label in labels:
        observation = observations.get(label.entity_key)
        if observation is None or observation.get("entity_hash") != label.entity_hash:
            status = "STALE"; stale += 1; actual = None
        elif "actual" not in observation:
            status = "UNSUPPORTED"; unsupported += 1; actual = None
        else:
            actual = str(observation["actual"])
            expected_values = set(label.expected_any) or {label.expected}
            accepted = actual not in expected_values if label.expectation_kind is CalibrationExpectationKind.NEGATIVE_EXPECTATION else actual in expected_values
            status = "MATCH" if accepted else "MISMATCH"
            if status == "MATCH": matched += 1
            else: mismatched += 1
        results.append({"entity_key": label.entity_key, "label": label.label, "expectation_kind": label.expectation_kind, "expected": label.expected, "expected_any": label.expected_any, "strength": label.strength, "actual": actual, "status": status, "note": label.note})
    return CalibrationReport(CALIBRATION_SCHEMA_VERSION, fixture_id, heuristic_set, len(labels), matched, mismatched, stale, unsupported, tuple(results))
