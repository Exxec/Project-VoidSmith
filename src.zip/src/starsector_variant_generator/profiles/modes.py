from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class UserMode(StrEnum):
    BEGINNER = "beginner"
    GUIDED = "guided"
    ADVANCED = "advanced"


@dataclass(frozen=True)
class ModeDefaults:
    profile_id: str
    faction_mode: str
    control: str
    heuristic_set: str
    flux_mode: str


def resolve_mode(mode: UserMode, requested_profile: str | None = None) -> ModeDefaults:
    profile = requested_profile or "LINE_BRAWLER"
    if mode == UserMode.BEGINNER:
        return ModeDefaults(profile, "FACTION_PLUS", "AI", "baseline_0.2", "SAFE")
    if mode == UserMode.GUIDED:
        # Guided mode's one concrete "meaningful choice" over Beginner today is an
        # explicit flux-sustainability target; see docs/ROADMAP.md Tier 4.
        return ModeDefaults(profile, "FACTION_PLUS", "EITHER", "baseline_0.2", "BALANCED")
    return ModeDefaults(profile, "UNRESTRICTED", "EITHER", "baseline_0.2", "AGGRESSIVE")
