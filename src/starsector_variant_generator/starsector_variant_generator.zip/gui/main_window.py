"""Qt desktop shell; all rules, scoring, and legality stay in the backend."""
from __future__ import annotations

import logging
import threading
from collections import deque
from collections.abc import Callable
from pathlib import Path
from time import monotonic
from typing import Any

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QObject, QSettings, Qt, QThread, QTimer
from PySide6.QtGui import QColor, QDragEnterEvent, QDropEvent, QPainter, QPen, QWheelEvent
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QCheckBox,
    QFileDialog,
    QFormLayout,
    QFrame,
    QGraphicsScene,
    QGraphicsView,
    QGroupBox,
    QHBoxLayout,
    QInputDialog,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QProgressDialog,
    QPushButton,
    QSplitter,
    QSpinBox,
    QTableView,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from starsector_variant_generator import api
from starsector_variant_generator.core.config import AppConfig
from starsector_variant_generator.core.mod_import import ModImportResult, resolve_dropped_mod
from starsector_variant_generator.core.models import Hull, Variant
from starsector_variant_generator.gui.presentation import format_generation_results
from starsector_variant_generator.gui.resources import HullSpriteCache
from starsector_variant_generator.gui.session import HullCatalog
from starsector_variant_generator.gui.workers.analysis_worker import AnalysisWorker
from starsector_variant_generator.gui.workers.scan_worker import ScanWorker
from starsector_variant_generator.profiles.catalog import available_profiles


class TechnicalCanvas(QGraphicsView):
    def __init__(self) -> None:
        self.scene_ = QGraphicsScene()
        super().__init__(self.scene_)
        self.setRenderHint(QPainter.Antialiasing)
        self.setDragMode(QGraphicsView.ScrollHandDrag)
        self.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self._sprites = HullSpriteCache()
        self.show_empty()

    def wheelEvent(self, event: QWheelEvent) -> None:  # type: ignore[override]
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        self.scale(factor, factor)

    def reset_view(self) -> None:
        self.resetTransform()
        bounds = self.scene_.itemsBoundingRect()
        if not bounds.isNull():
            self.fitInView(bounds.adjusted(-35, -35, 35, 35), Qt.KeepAspectRatio)

    def zoom_in(self) -> None:
        self.scale(1.15, 1.15)

    def zoom_out(self) -> None:
        self.scale(1 / 1.15, 1 / 1.15)

    def show_empty(self) -> None:
        self.scene_.clear()
        text = self.scene_.addText("Select a scanned hull to inspect normalized fitting data")
        text.setDefaultTextColor(QColor("#91a8b7"))

    def show_hull(self, hull: Hull, weapons: dict[str, str] | None = None) -> None:
        self.scene_.clear()
        self.resetTransform()
        title = self.scene_.addText(f"{hull.name}\n{len(hull.weapon_mounts)} parsed weapon mounts")
        title.setDefaultTextColor(QColor("#d7e4ee"))
        sprite = self._sprites.sprite_for(hull)
        ship_data = hull.raw.get("ship_data", {}) if isinstance(hull.raw.get("ship_data"), dict) else {}
        width, height = _number(ship_data.get("width"), 320.0), _number(ship_data.get("height"), 180.0)
        center = ship_data.get("center", [0.0, 0.0])
        center_x = _number(center[0], 0.0) if isinstance(center, list) and len(center) >= 2 else 0.0
        center_y = _number(center[1], 0.0) if isinstance(center, list) and len(center) >= 2 else 0.0
        if sprite is not None:
            image = self.scene_.addPixmap(sprite)
            image.setOffset(-sprite.width() / 2 - center_x, -sprite.height() / 2 + center_y)
        else:
            outline = self.scene_.addRect(-width / 2, -height / 2, width, height, QPen(QColor("#28536b"), 2))
            outline.setToolTip("Local hull sprite unavailable; geometry outline only.")
        plotted = 0
        anchors: list[tuple[float, float, str, QColor]] = []
        for slot in hull.weapon_mounts:
            loc = slot.get("locations")
            if not isinstance(loc, list) or len(loc) < 2 or not all(isinstance(x, (float, int)) for x in loc[:2]):
                continue
            x, y = float(loc[0]) - center_x, -float(loc[1]) + center_y
            color = QColor("#d69b27") if str(slot.get("type", "")).upper() == "MISSILE" else QColor("#24aaf2")
            self.scene_.addEllipse(x - 5, y - 5, 10, 10, QPen(color, 2))
            slot_id = str(slot.get("id", "slot"))
            selected_weapon = (weapons or {}).get(slot_id)
            if selected_weapon:
                marker = self.scene_.addRect(x - 3, y - 3, 6, 6, QPen(QColor("#e7f4ff"), 1), QColor("#248bca"))
                marker.setToolTip(f"Selected weapon: {selected_weapon}. Weapon sprite metadata is unavailable; logical mount marker shown.")
            anchors.append((x, y, f"{slot_id}\n{slot.get('size', 'UNKNOWN')} {slot.get('type', 'UNKNOWN')}\n{(weapons or {}).get(slot_id, '<Empty>')}", color))
            plotted += 1
        self._add_packed_callouts(anchors, width)
        complex_note = "  •  Composite module behavior is not modeled." if "SHIP_WITH_MODULES" in {hint.upper() for hint in hull.hull_hints} else ""
        note = self.scene_.addText(("Slot anchors shown from parsed hull geometry." if plotted else "No parsed slot geometry available.") + complex_note)
        note.setDefaultTextColor(QColor("#91a8b7")); note.setPos(0, 65)
        self.reset_view()

    def _add_packed_callouts(self, anchors: list[tuple[float, float, str, QColor]], hull_width: float) -> None:
        """Place labels outside the hull by side and ordered vertical lanes."""
        left = sorted((item for item in anchors if item[0] < 0), key=lambda item: item[1])
        right = sorted((item for item in anchors if item[0] >= 0), key=lambda item: item[1])
        for side, entries in ((-1, left), (1, right)):
            previous_y: float | None = None
            for x, y, text, color in entries:
                label_y = y if previous_y is None else max(y, previous_y + 48)
                previous_y = label_y
                label_x = side * (max(hull_width / 2, 100.0) + 42)
                label = self.scene_.addText(text)
                label.setDefaultTextColor(color)
                label.setPos(label_x if side > 0 else label_x - label.boundingRect().width(), label_y - 20)
                end_x = label_x if side > 0 else label_x
                self.scene_.addLine(x, y, end_x, label_y, QPen(color, 1))

    def drawBackground(self, painter: QPainter, rect: Any) -> None:  # type: ignore[override]
        painter.fillRect(rect, QColor("#061019")); painter.setPen(QPen(QColor("#10293a"), 1))
        for x in range(int(rect.left()) - int(rect.left()) % 32, int(rect.right()), 32):
            painter.drawLine(x, rect.top(), x, rect.bottom())
        for y in range(int(rect.top()) - int(rect.top()) % 32, int(rect.bottom()), 32):
            painter.drawLine(rect.left(), y, rect.right(), y)


def _number(value: object, fallback: float) -> float:
    return float(value) if isinstance(value, (int, float)) else fallback


def _looks_like_starsector_install(root: Path) -> bool:
    """Cheap, local-only sanity check before starting a background scan.

    `core/scanner.py::discover_sources` is deliberately lenient -- if
    `starsector-core` isn't present under the chosen root it silently
    treats the root itself as the core source rather than failing, so it
    never rejects a wrong path on its own. Pointing a scan at an unrelated
    folder (a parent directory, a totally different drive, ...) wouldn't
    error quickly; it would scan whatever real files happen to be there,
    slowly, with a source list that supports no conclusion. Catching an
    obviously-wrong folder here, before any scan starts, is cheap (a few
    filesystem stat calls) and avoids that entirely rather than relying on
    a user cancelling out of it after the fact."""
    return (root / "starsector-core").is_dir() or (root / "starsector.exe").exists() or (root / "starsector.sh").exists()


_MIRROR_MATCH_TOLERANCE = 0.75

# How long a scan can go without a real progress event before the watchdog
# logs a stall warning. Deliberately generous: fingerprinting/parsing one
# large real source can legitimately take several real seconds on its own
# (see core/scanner.py's own per-source logging) -- this is meant to catch
# a genuine stall (no events at all for a long stretch), not to complain
# about ordinary per-source variance.
_SCAN_STALL_WARNING_INTERVAL_S = 20.0


def _detect_mirror_mount_pairs(hull: Hull) -> dict[str, str]:
    """Detect left/right mirror-symmetric weapon-mount pairs from a hull's
    real parsed `.ship` geometry (`weaponSlots`' `locations`/`angle`/`arc`/
    `size`/`type`/`mount` fields -- the same raw data the canvas already
    reads to place slot markers).

    Starsector hulls are built bow/stern-asymmetric (a distinct nose and
    engine block, never a fore-aft mirror image), so only a left/right axis
    is ever geometrically meaningful here -- there is no equivalent
    "horizontal" mirror to detect. A mount pairs with another only when its
    position, angle, arc, size, mount kind, and weapon type all match the
    exact mirror image of another mount's (x unchanged, y negated, angle
    negated mod 360), within a small tolerance for non-integer coordinates.
    Centerline mounts (y == 0) and mounts with no matching counterpart are
    left unpaired -- Mirror is then a no-op for that slot, not a guess.
    Verified against real hulls: Hammerhead's 8 mounts pair perfectly (4
    pairs); Odyssey's 19 mounts produce exactly 1 real pair, correctly
    leaving the rest -- deliberately scattered, unique turret placements --
    unpaired rather than forcing a false match.
    """
    entries: list[tuple[str, float, float, float, Any, Any, Any, Any]] = []
    for slot in hull.weapon_mounts:
        slot_id = slot.get("id")
        loc = slot.get("locations")
        if not slot_id or not isinstance(loc, list) or len(loc) < 2:
            continue
        try:
            x, y = float(loc[0]), float(loc[1])
            angle = float(slot.get("angle", 0.0))
        except (TypeError, ValueError):
            continue
        entries.append((str(slot_id), x, y, angle, slot.get("arc"), slot.get("size"), slot.get("type"), slot.get("mount")))

    pairs: dict[str, str] = {}
    for i, (id_a, x_a, y_a, angle_a, arc_a, size_a, type_a, mount_a) in enumerate(entries):
        if id_a in pairs or abs(y_a) < _MIRROR_MATCH_TOLERANCE:
            continue
        for id_b, x_b, y_b, angle_b, arc_b, size_b, type_b, mount_b in entries[i + 1:]:
            if id_b in pairs:
                continue
            if abs(x_a - x_b) > _MIRROR_MATCH_TOLERANCE or abs(y_a + y_b) > _MIRROR_MATCH_TOLERANCE:
                continue
            if arc_a != arc_b or size_a != size_b or type_a != type_b or mount_a != mount_b:
                continue
            angle_sum = (angle_a + angle_b) % 360.0
            if angle_sum > _MIRROR_MATCH_TOLERANCE and angle_sum < 360.0 - _MIRROR_MATCH_TOLERANCE:
                continue
            pairs[id_a] = id_b
            pairs[id_b] = id_a
            break
    return pairs


class EntityTableModel(QAbstractTableModel):
    """Lazy Qt model for normalized data tables; avoids per-cell widgets."""

    def __init__(self, headers: list[str], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.headers = headers
        self.rows: list[tuple[str, ...]] = []
        self.entities: list[Any] = []

    def rowCount(self, parent: QModelIndex = QModelIndex()) -> int:  # type: ignore[override]
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent: QModelIndex = QModelIndex()) -> int:  # type: ignore[override]
        return 0 if parent.isValid() else len(self.headers)

    def data(self, index: QModelIndex, role: int = Qt.DisplayRole) -> Any:  # type: ignore[override]
        if role == Qt.DisplayRole and index.isValid():
            return self.rows[index.row()][index.column()]
        return None

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.DisplayRole) -> Any:  # type: ignore[override]
        if role == Qt.DisplayRole and orientation == Qt.Horizontal and 0 <= section < len(self.headers):
            return self.headers[section]
        return None

    def set_records(self, rows: list[tuple[str, ...]], entities: list[Any]) -> None:
        self.beginResetModel()
        self.rows = rows
        self.entities = entities
        self.endResetModel()


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self._catalog: HullCatalog | None = None; self._visible: tuple[Hull, ...] = ()
        self._config: AppConfig | None = None
        self._registry: Any = None; self._scan_result: Any = None; self._current_hull: Hull | None = None
        self._fit_weapons: dict[str, str] = {}; self._mirror_pairs: dict[str, str] = {}; self._scan_thread: QThread | None = None; self._threads: set[QThread] = set()
        # `moveToThread` transfers ownership of the underlying Qt object to
        # the target thread, but does nothing to keep the *Python* wrapper
        # object referenced -- if nothing holds a real reference to a worker
        # beyond the local variable in the method that constructs it, that
        # variable goes out of scope the moment the method returns while the
        # worker's own QThread keeps running in the background, risking the
        # Python object being garbage-collected out from under a still-live
        # C++-side QObject (and, in the generic case, corrupting whichever
        # entry belongs to a different in-flight operation once cleared).
        # Retained explicitly for the whole thread lifetime, cleared only
        # once that thread has actually finished (_scan_finished/_finish_thread).
        self._scan_worker: ScanWorker | None = None
        self._active_workers: dict[QThread, QObject] = {}
        self._scan_discarded = False; self._scan_progress: QProgressDialog | None = None; self._scan_cancel_event: threading.Event | None = None
        # Short rolling trail of real source names the current scan has
        # already moved past, shown alongside the live "currently scanning"
        # name so the dialog reads as a real, moving list of activity
        # rather than a single name replacing itself in place.
        self._scan_recent_sources: deque[str] = deque(maxlen=5)
        # Stall diagnostics: the watchdog fires periodically while a scan is
        # in flight and, if no real progress event has arrived recently,
        # logs exactly what was last known (stage, source, how long ago)
        # plus live worker/thread state -- so an apparent hang is
        # diagnosable from the log even if it can't be caught live.
        self._scan_last_progress: Any = None
        self._scan_last_progress_at: float | None = None
        self._scan_stall_warned_at: float | None = None
        self._scan_watchdog = QTimer(self); self._scan_watchdog.setInterval(5000); self._scan_watchdog.timeout.connect(self._check_scan_stall)
        self._data_tables_pending = False
        self._operation_tokens: dict[QPushButton, int] = {}
        self._extra_mods: list[ModImportResult] = []
        self.setAcceptDrops(True)
        self._preferences = QSettings("VoidSmith", "Desktop")
        # Preserve the user's existing local settings across the application
        # rename without retaining the former name as the active namespace.
        previous_preferences = QSettings("Starsector Variant Generator", "Desktop")
        for key in ("window/size", "paths/starsector", "paths/output"):
            if not self._preferences.contains(key) and previous_preferences.contains(key):
                self._preferences.setValue(key, previous_preferences.value(key))
        self.setWindowTitle("VoidSmith")
        self.resize(self._preferences.value("window/size", super().size()))  # type: ignore[call-overload]
        self.setCentralWidget(self._make_tabs())
        self._hull_filter_timer = QTimer(self); self._hull_filter_timer.setSingleShot(True); self._hull_filter_timer.setInterval(150); self._hull_filter_timer.timeout.connect(self._refresh_hulls)
        self.mode_selector.setCurrentIndex(max(0, self.mode_selector.findData(self._preferences.value("fit/mode", "beginner"))))
        self.faction_mode_selector.setCurrentIndex(max(0, self.faction_mode_selector.findData(self._preferences.value("fit/faction_mode", "FACTION_PLUS"))))
        self.slot_include_hidden.setChecked(bool(self._preferences.value("fit/show_hidden", False, type=bool)))
        self.statusBar().showMessage("No scan loaded — configure an installation in Settings / Export.")

    def _make_tabs(self) -> QTabWidget:
        tabs = QTabWidget()
        self.workspace_tabs = tabs
        for widget, title in ((self._ships(), "Ships"), (self._retrofits(), "Retrofits"), (self._faction(), "Faction"), (self._data(), "Data / Analysis"), (self._settings(), "Settings / Export")):
            tabs.addTab(widget, title)
        tabs.currentChanged.connect(self._workspace_changed)
        return tabs

    def _ships(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); tabs = QTabWidget()
        self.ship_tabs = tabs
        tabs.addTab(self._browse(), "Browse / Fit")
        self.inspect_detail = QPlainTextEdit(); self.inspect_detail.setReadOnly(True); self.inspect_detail.setPlainText("Select a hull in Browse / Fit.")
        tabs.addTab(self.inspect_detail, "Inspect")
        self.compare_detail = QPlainTextEdit(); self.compare_detail.setReadOnly(True); self.compare_detail.setPlainText("Generated candidates appear here.")
        tabs.addTab(self.compare_detail, "Compare"); layout.addWidget(tabs); return page

    def _browse(self) -> QWidget:
        split = QSplitter(Qt.Horizontal); split.addWidget(self._browser()); split.addWidget(self._center()); split.addWidget(self._inspector()); split.setSizes([260, 820, 310]); return split

    def _browser(self) -> QWidget:
        panel = QFrame(); panel.setObjectName("panel"); layout = QVBoxLayout(panel); group = QGroupBox("HULL BROWSER & FILTERS"); filters = QVBoxLayout(group)
        self.search = QLineEdit(); self.search.setPlaceholderText("Search scanned hulls…"); self.search.textChanged.connect(self._schedule_hull_refresh); filters.addWidget(self.search)
        self.size_filter, self.source_filter = QComboBox(), QComboBox()
        for label, box in (("HULL SIZE", self.size_filter), ("SOURCE MOD", self.source_filter)):
            filters.addWidget(QLabel(label)); filters.addWidget(box); box.currentIndexChanged.connect(self._refresh_hulls)
        reset = QPushButton("Reset Filters"); reset.clicked.connect(self._reset_filters); filters.addWidget(reset); layout.addWidget(group)
        self.count = QLabel("HULLS (scan required)"); layout.addWidget(self.count)
        self.hull_list = QListWidget(); self.hull_list.addItem("Scan an installation to populate hulls"); self.hull_list.currentRowChanged.connect(self._selected_hull); layout.addWidget(self.hull_list, 1)
        return panel

    def _center(self) -> QWidget:
        panel = QFrame(); panel.setObjectName("panel"); layout = QVBoxLayout(panel)
        self.heading = QLabel("No hull selected"); self.heading.setObjectName("heading"); self.subheading = QLabel("Scan an installation to begin"); self.subheading.setObjectName("muted")
        layout.addWidget(self.heading); layout.addWidget(self.subheading); self.canvas = TechnicalCanvas(); layout.addWidget(self.canvas, 1)
        canvas_controls = QHBoxLayout()
        zoom_in, zoom_out, fit_view = QPushButton("Zoom +"), QPushButton("Zoom −"), QPushButton("Fit View")
        zoom_in.clicked.connect(self.canvas.zoom_in); zoom_out.clicked.connect(self.canvas.zoom_out); fit_view.clicked.connect(self.canvas.reset_view)
        canvas_controls.addWidget(zoom_in); canvas_controls.addWidget(zoom_out); canvas_controls.addWidget(fit_view); canvas_controls.addStretch()
        layout.addLayout(canvas_controls)
        controls = QGroupBox("GENERATION CONTROLS"); form = QFormLayout(controls)
        self.mode_selector = QComboBox()
        for label, value in (("Beginner", "beginner"), ("Guided", "guided"), ("Advanced / Manual", "advanced")):
            self.mode_selector.addItem(label, value)
        self.profile_selector = QComboBox(); self.profile_selector.addItem("Auto: viable build archetypes", None)
        for profile in available_profiles(): self.profile_selector.addItem(profile.display_name, profile.identifier)
        self.flux_selector = QComboBox()
        for value in ("SAFE", "BALANCED", "AGGRESSIVE"): self.flux_selector.addItem(value.title(), value)
        self.faction_mode_selector = QComboBox()
        for label, value in (("Strict Faction", "STRICT_FACTION"), ("Faction+", "FACTION_PLUS"), ("Unrestricted", "UNRESTRICTED")):
            self.faction_mode_selector.addItem(label, value)
        self.generation_faction_selector = QComboBox(); self.generation_faction_selector.addItem("No faction selected", None)
        self.max_candidates = QSpinBox(); self.max_candidates.setRange(1, 20); self.max_candidates.setValue(5)
        self.search_depth = QSpinBox(); self.search_depth.setRange(1, 10); self.search_depth.setValue(1)
        self.advanced_config = QLineEdit(); self.advanced_config.setPlaceholderText("Optional implemented advanced-request JSON")
        pick_advanced = QPushButton("Choose…"); pick_advanced.clicked.connect(self._choose_advanced_config)
        advanced_row = QWidget(); advanced_layout = QHBoxLayout(advanced_row); advanced_layout.setContentsMargins(0, 0, 0, 0); advanced_layout.addWidget(self.advanced_config, 1); advanced_layout.addWidget(pick_advanced)
        for label, widget in (("Mode", self.mode_selector), ("Profile", self.profile_selector), ("Flux posture", self.flux_selector), ("Equipment access", self.faction_mode_selector), ("Faction", self.generation_faction_selector), ("Candidate limit", self.max_candidates), ("Search depth", self.search_depth), ("Advanced request", advanced_row)):
            form.addRow(label, widget)
        layout.addWidget(controls)
        group = QGroupBox("GENERATED BUILD PATHS"); box = QVBoxLayout(group)
        self.candidate_cards = QListWidget(); self.candidate_cards.addItem("Select a hull and choose Generate Best."); self.candidate_cards.currentRowChanged.connect(self._preview_candidate); box.addWidget(self.candidate_cards)
        self.build_results = QPlainTextEdit(); self.build_results.setReadOnly(True); self.build_results.setMaximumHeight(105); self.build_results.setPlainText("Backend score and evidence for the selected candidate appear here."); box.addWidget(self.build_results)
        self.open_advanced_button = QPushButton("Open Selected in Advanced"); self.open_advanced_button.setEnabled(False); self.open_advanced_button.clicked.connect(self._open_selected_in_advanced); box.addWidget(self.open_advanced_button)
        self._generated_candidates: list[dict[str, Any]] = []; layout.addWidget(group)
        return panel

    def _inspector(self) -> QWidget:
        panel = QFrame(); panel.setObjectName("panel"); layout = QVBoxLayout(panel); group = QGroupBox("BUILD INSPECTOR"); box = QVBoxLayout(group); self.values: dict[str, QLabel] = {}
        for key in ("Hull Size", "Source Mod", "OP", "Weapon Mounts", "Built-ins"):
            row = QHBoxLayout(); row.addWidget(QLabel(key)); value = QLabel("—"); value.setObjectName("muted"); row.addWidget(value); box.addLayout(row); self.values[key] = value
        layout.addWidget(group); layout.addWidget(QLabel("WEAPON SLOTS — double-click to select")); self.slots = QListWidget(); self.slots.itemDoubleClicked.connect(self._choose_slot); layout.addWidget(self.slots, 1)
        self.fit_metrics = QLabel("FIT STATUS: select a hull"); self.fit_metrics.setObjectName("muted"); self.fit_metrics.setWordWrap(True); layout.addWidget(self.fit_metrics)
        self.slot_include_hidden = QCheckBox("Show hidden / restricted equipment"); self.slot_include_hidden.setToolTip("Only availability explicitly marked in local scanned data is hidden."); layout.addWidget(self.slot_include_hidden)
        self.mirror_fitting = QCheckBox("Mirror fitting"); self.mirror_fitting.setToolTip("No hull selected yet."); self.mirror_fitting.setEnabled(False); layout.addWidget(self.mirror_fitting)
        self.generate_button = QPushButton("Generate Best"); self.generate_button.setObjectName("primary"); self.generate_button.setEnabled(False); self.generate_button.clicked.connect(self._generate); layout.addWidget(self.generate_button)
        return panel

    def _retrofits(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.addWidget(QLabel("REFIT / REPAIR ASSISTANT")); self.variant_list = QListWidget(); self.variant_list.addItem("Scan an installation to load existing variants"); self.variant_list.itemDoubleClicked.connect(self._open_variant_hull); layout.addWidget(self.variant_list, 1)
        controls = QHBoxLayout(); self.fix_button = QPushButton("Suggest Legality Fix"); self.improve_button = QPushButton("Improve Variant"); self.compare_refit_button = QPushButton("Compare Before / After")
        for button, slot in ((self.fix_button, self._fix_legality), (self.improve_button, self._improve_quality), (self.compare_refit_button, self._compare_refit)):
            button.setEnabled(False); button.clicked.connect(slot); controls.addWidget(button)
        layout.addLayout(controls)
        options = QGroupBox("REFIT CONTROLS"); form = QFormLayout(options)
        self.refit_mode_selector = QComboBox()
        for label, value in (("Balanced Improvement", "BALANCED_IMPROVEMENT"), ("Reduce Flux", "REDUCE_FLUX"), ("Improve Role Match", "IMPROVE_ROLE_MATCH"), ("Improve Logistics", "IMPROVE_LOGISTICS")):
            self.refit_mode_selector.addItem(label, value)
        self.refit_profile_selector = QComboBox()
        for profile in available_profiles(): self.refit_profile_selector.addItem(profile.display_name, profile.identifier)
        self.refit_substitution_selector = QComboBox()
        for label, value in (("Cheapest", "cheapest"), ("Exact", "exact"), ("Starsector Style", "starsector_style"), ("Adaptive", "adaptive")):
            self.refit_substitution_selector.addItem(label, value)
        self.refit_locked_mounts, self.refit_locked_hullmods, self.refit_locked_wings = QLineEdit(), QLineEdit(), QLineEdit()
        for widget in (self.refit_locked_mounts, self.refit_locked_hullmods, self.refit_locked_wings): widget.setPlaceholderText("Comma-separated IDs; optional")
        for label, widget in (("Quality mode", self.refit_mode_selector), ("Target profile", self.refit_profile_selector), ("Legality substitution", self.refit_substitution_selector), ("Locked mounts", self.refit_locked_mounts), ("Locked hullmods", self.refit_locked_hullmods), ("Locked fighter wings", self.refit_locked_wings)):
            form.addRow(label, widget)
        layout.addWidget(options); self.refit_detail = QPlainTextEdit(); self.refit_detail.setReadOnly(True); self.refit_detail.setPlainText("Choose a scanned variant. Suggestions preserve backend legality and selected locks."); layout.addWidget(self.refit_detail, 1); return page

    def _faction(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); layout.addWidget(QLabel("FACTION CAPABILITY & RECOMMENDATIONS")); self.faction_list = QListWidget(); self.faction_list.addItem("Scan an installation to load factions"); self.faction_list.currentRowChanged.connect(self._faction_selected); layout.addWidget(self.faction_list, 1)
        controls = QHBoxLayout(); self.capability_button = QPushButton("Analyze Capability"); self.recommend_button = QPushButton("Find Gap Recommendations")
        for button, slot in ((self.capability_button, self._analyze_capability), (self.recommend_button, self._gap_recommendations)):
            button.setEnabled(False); button.clicked.connect(slot); controls.addWidget(button)
        layout.addLayout(controls); self.faction_detail = QPlainTextEdit(); self.faction_detail.setReadOnly(True); self.faction_detail.setPlainText("Select a faction after scanning."); layout.addWidget(self.faction_detail, 2); return page

    def _data(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); split = QSplitter(Qt.Horizontal); tabs = QTabWidget(); self.data_tables: dict[str, QTableView] = {}; self._data_entities: dict[str, list[Any]] = {}
        for title, headers in (("Weapons", ["Name", "Size", "Type", "Source Mod"]), ("Hullmods", ["Name", "Hidden", "Source Mod"]), ("Fighters", ["Name", "Role", "Source Mod"]), ("Variants", ["Name", "Hull", "Source Mod"])):
            table = QTableView(); table.setModel(EntityTableModel(headers, table)); table.setEditTriggers(QTableView.NoEditTriggers); table.selectionModel().selectionChanged.connect(lambda _selected, _deselected, title=title: self._show_provenance(title)); tabs.addTab(table, title); self.data_tables[title] = table
        self.provenance_detail = QPlainTextEdit(); self.provenance_detail.setReadOnly(True); self.provenance_detail.setPlainText("Select a normalized record to inspect local source provenance.")
        provenance_group = QGroupBox("PROVENANCE"); provenance_layout = QVBoxLayout(provenance_group); provenance_layout.addWidget(self.provenance_detail)
        split.addWidget(tabs); split.addWidget(provenance_group); split.setSizes([860, 360]); layout.addWidget(split); return page

    def _settings(self) -> QWidget:
        page = QWidget(); layout = QVBoxLayout(page); group = QGroupBox("INSTALLATION, SCAN & EXPORT"); box = QVBoxLayout(group)
        self.root = QLineEdit(str(self._preferences.value("paths/starsector", ""))); self.root.setPlaceholderText("Select Starsector installation folder")
        choose = QPushButton("Choose Installation…"); choose.clicked.connect(self._choose_installation); self.output = QLineEdit(str(self._preferences.value("paths/output", (Path.cwd() / "generated" / "gui").resolve())))
        self.scan_button = QPushButton("Scan Installed Data"); self.scan_button.setObjectName("primary"); self.scan_button.clicked.connect(self._start_scan)
        self.cancel_scan_button = QPushButton("Cancel Scan"); self.cancel_scan_button.setEnabled(False); self.cancel_scan_button.clicked.connect(self._discard_scan)
        self.export_button = QPushButton("Export Current Hull (conservative)"); self.export_button.setEnabled(False); self.export_button.clicked.connect(self._export_current)
        for label, widget in (("STARSECTOR PATH", self.root), ("", choose), ("SAFE OUTPUT DIRECTORY", self.output), ("", self.scan_button), ("", self.cancel_scan_button), ("", self.export_button)):
            if label: box.addWidget(QLabel(label))
            box.addWidget(widget)
        layout.addWidget(group)
        mods_group = QGroupBox("ADDITIONAL MODS (drag && drop)"); mods_layout = QVBoxLayout(mods_group)
        mods_layout.addWidget(QLabel("Drag a mod folder or .zip archive anywhere onto this window to add it to the next scan — it does not need to be installed under the Starsector installation's mods folder."))
        self.extra_mods_list = QListWidget(); self.extra_mods_list.addItem("No additional mods added."); mods_layout.addWidget(self.extra_mods_list, 1)
        remove_extra_mod = QPushButton("Remove Selected"); remove_extra_mod.clicked.connect(self._remove_selected_extra_mod); mods_layout.addWidget(remove_extra_mod)
        layout.addWidget(mods_group)
        summary_group = QGroupBox("LATEST LOCAL SCAN / REPORT STATUS"); summary_layout = QVBoxLayout(summary_group)
        self.scan_summary = QPlainTextEdit(); self.scan_summary.setReadOnly(True); self.scan_summary.setMaximumHeight(150)
        self.scan_summary.setPlainText("No local scan has been loaded. Source files are read-only; reports are written only under the configured output directory.")
        summary_layout.addWidget(self.scan_summary); layout.addWidget(summary_group); layout.addStretch(); return page

    def dragEnterEvent(self, event: QDragEnterEvent) -> None:  # type: ignore[override]
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:  # type: ignore[override]
        dropped = [Path(url.toLocalFile()) for url in event.mimeData().urls() if url.isLocalFile()]
        if not dropped:
            return
        event.acceptProposedAction()
        cache_root = Path(self.output.text().strip() or (Path.cwd() / "generated" / "gui")) / "cache" / "dropped_mods"
        failures: list[str] = []
        newly_added: list[ModImportResult] = []
        for path in dropped:
            result = resolve_dropped_mod(path, cache_root)
            if result.error is not None:
                failures.append(f"{path.name}: {result.error}")
                continue
            if any(existing.mod_root == result.mod_root for existing in self._extra_mods):
                continue  # Already added; re-dropping the same archive already refreshed its extraction above.
            self._extra_mods.append(result)
            newly_added.append(result)
        self._refresh_extra_mods_list()
        if failures:
            QMessageBox.warning(self, "Could not add mod", "\n\n".join(failures))
        if not newly_added:
            return
        # A prior scan already exists in this session, and neither a real
        # scan nor another incremental merge is currently running (reusing
        # scan_button's enabled state as that guard -- both paths disable
        # it): incorporate the drop immediately, without waiting for a full
        # rescan of the whole installation, so testing a new mod doesn't
        # mean re-scanning 148 others just to see it. Falls back to the
        # original "rescan to include" behavior otherwise (nothing to merge
        # into yet, or something else is already in flight).
        # Also require no other backend read (_generate, _refit, faction
        # analysis, export, ...) to be in flight (self._threads): those
        # workers read self._registry only when their thread actually
        # executes, not when their button was clicked, so starting an
        # incremental incorporation -- which reassigns self._registry --
        # while one is still running could swap the data out from under it
        # mid-read. See _registry_write_in_progress for the read side of
        # this same guard.
        if self._scan_result is not None and self._config is not None and self._scan_thread is None and self.scan_button.isEnabled() and not self._threads:
            self._incorporate_dropped_mods(newly_added)
        else:
            self.statusBar().showMessage(f"Added {len(self._extra_mods)} additional mod(s); rescan to include {'them' if len(newly_added) > 1 else 'it'}.")

    def _incorporate_dropped_mods(self, newly_added: list[ModImportResult]) -> None:
        config, existing_result = self._config, self._scan_result
        mod_roots = tuple(mod.mod_root for mod in newly_added)
        operation = lambda: api.run_incremental_mod_scan(config, existing_result, mod_roots)  # noqa: E731
        self._run(f"Incorporating {len(newly_added)} dropped mod(s)…", operation, self._apply_incremental_scan_outcome, self.scan_button)

    def _apply_incremental_scan_outcome(self, outcome: Any) -> None:
        """The `completed` half of `_incorporate_dropped_mods`, factored out
        as a directly-callable method (not an inline closure) so it can be
        exercised synchronously in tests without needing a real QThread to
        actually finish -- background-thread completion timing isn't
        reliably observable via processEvents() polling in a headless
        test harness (confirmed directly: even a trivial, guaranteed-fast
        `_run` operation never completed within 5s / 2.3M polls in that
        setup), independent of whether the real app (which runs a normal
        blocking app.exec() event loop, not a polling one) has any issue."""
        self._scan_result, self._registry = outcome.result, outcome.registry
        self._catalog = HullCatalog.from_scan(outcome.result)
        for value in self._catalog.hull_sizes():
            if self.size_filter.findData(value) < 0: self.size_filter.addItem(value, value)
        for value in self._catalog.source_mods():
            if self.source_filter.findData(value) < 0: self.source_filter.addItem(value, value)
        self._refresh_hulls(); self._populate_secondary()
        skipped_note = f"; {len(outcome.skipped_mod_roots)} could not be parsed" if outcome.skipped_mod_roots else ""
        self.statusBar().showMessage(f"Incorporated {len(outcome.added_mod_ids)} dropped mod(s) into the current session{skipped_note} -- a full rescan will re-verify everything together.")
        self.scan_summary.appendPlainText(f"\nIncrementally incorporated (not a full rescan): {', '.join(outcome.added_mod_ids) or 'none'}.")

    def _refresh_extra_mods_list(self) -> None:
        self.extra_mods_list.clear()
        if not self._extra_mods:
            self.extra_mods_list.addItem("No additional mods added.")
            return
        for mod in self._extra_mods:
            item = QListWidgetItem(f"{mod.mod_name or mod.mod_id} [{mod.mod_id}]\n{mod.mod_root}")
            item.setData(Qt.UserRole, mod.mod_root)
            self.extra_mods_list.addItem(item)

    def _remove_selected_extra_mod(self) -> None:
        item = self.extra_mods_list.currentItem()
        if item is None:
            return
        target = item.data(Qt.UserRole)
        if target is None:
            return
        self._extra_mods = [mod for mod in self._extra_mods if mod.mod_root != target]
        self._refresh_extra_mods_list()
        self.statusBar().showMessage("Removed from the next scan's additional mods. Rescan to apply.")

    def _choose_installation(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Select Starsector installation")
        if path: self.root.setText(path)

    def _choose_advanced_config(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select advanced generation request", filter="JSON files (*.json)")
        if path: self.advanced_config.setText(path)

    def _start_scan(self) -> None:
        root_text, output_text = self.root.text().strip(), self.output.text().strip()
        if not root_text: QMessageBox.warning(self, "Installation required", "Choose your Starsector installation folder first."); return
        root = Path(root_text)
        if not root.is_dir(): QMessageBox.warning(self, "Invalid installation", f"'{root}' does not exist or is not a folder. Choose the folder containing your Starsector installation."); return
        if not _looks_like_starsector_install(root):
            QMessageBox.warning(self, "Not a Starsector installation", f"'{root}' does not look like a Starsector installation -- no starsector-core folder or starsector.exe was found there. Scanning an unrelated folder can be slow and won't produce useful results. Choose the top-level folder Starsector was installed into.")
            return
        if not output_text: QMessageBox.warning(self, "Output directory required", "Choose a safe output directory for generated reports and local cache data."); return
        output = Path(output_text)
        try:
            output.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            QMessageBox.warning(self, "Output directory not writable", f"Could not create or write to '{output}': {exc}"); return
        if self._scan_thread is not None: return
        self._scan_discarded = False; self._scan_cancel_event = threading.Event(); self.scan_button.setEnabled(False); self.cancel_scan_button.setEnabled(True)
        self._scan_recent_sources.clear()
        self._scan_progress = QProgressDialog("Scanning read-only Starsector and enabled-mod data…", "Cancel Scan", 0, 0, self)
        self._scan_progress.setWindowTitle("Scanning Local Data"); self._scan_progress.setWindowModality(Qt.WindowModal); self._scan_progress.canceled.connect(self._discard_scan); self._scan_progress.show()
        self._config = AppConfig(root, output, output / "logs", extra_mod_paths=tuple(mod.mod_root for mod in self._extra_mods))
        thread = QThread(self); worker = ScanWorker(self._config, cancel_check=self._scan_cancel_event.is_set); worker.moveToThread(thread); thread.started.connect(worker.run); worker.progress.connect(self._scan_progressed)
        # thread.quit is connected FIRST for every terminal signal, before
        # the application-level handler that acts on the result -- Qt calls
        # slots in connection order, so this guarantees the thread is asked
        # to stop regardless of what _scan_complete/_operation_failed do
        # (including raising), rather than the thread's own termination
        # depending on an application handler completing cleanly first.
        worker.completed.connect(thread.quit); worker.completed.connect(self._scan_complete)
        worker.failed.connect(thread.quit); worker.failed.connect(self._operation_failed)
        worker.cancelled.connect(thread.quit)
        thread.finished.connect(worker.deleteLater); thread.finished.connect(self._scan_finished)
        self._scan_thread = thread; self._scan_worker = worker; self.scan_button.setEnabled(False); self.statusBar().showMessage("Scanning read-only source data…")
        self._scan_last_progress = None; self._scan_last_progress_at = monotonic(); self._scan_stall_warned_at = None; self._scan_watchdog.start()
        thread.start()

    def _scan_progressed(self, progress: Any) -> None:
        """Present scanner telemetry only; the GUI never interprets game data."""
        self._scan_last_progress = progress; self._scan_last_progress_at = monotonic(); self._scan_stall_warned_at = None
        stage = str(getattr(progress, "stage", "SCANNING")).replace("_", " ").title()
        completed = int(getattr(progress, "completed_sources", 0))
        total = int(getattr(progress, "total_sources", 0))
        entities = int(getattr(progress, "entities_found", 0))
        current_source = str(getattr(progress, "current_source", "") or "")
        source_text = f" {completed}/{total} sources" if total else ""
        message = f"{stage}{source_text} - {entities} records found"
        if current_source:
            # A real, named source, not just an aggregate count -- this is
            # what actually proves the scan is doing something specific
            # right now instead of just a number that might be frozen.
            # Tracked in a short rolling trail (not just the single current
            # name) so the dialog reads as a real, moving list of recent
            # activity: see core/scanner.py's own per-source "starting"
            # events, which report this before a slow individual source's
            # own fingerprint/parse has finished, not only after.
            if not self._scan_recent_sources or self._scan_recent_sources[-1] != current_source:
                self._scan_recent_sources.append(current_source)
            message += f"\nCurrently scanning: {current_source}"
            trail = [name for name in self._scan_recent_sources if name != current_source]
            if trail:
                message += f"\nRecently: {', '.join(trail)}"
        if self._scan_progress is not None and not self._scan_discarded:
            self._scan_progress.setLabelText(message)
            # A real total isn't known during the brief initial DISCOVERING
            # stage (0), so the dialog stays an indeterminate spinner until
            # then; once PARSING reports a real source count, switch to a
            # determinate bar with a real, live-updating value so the dialog
            # visibly moves instead of appearing frozen for the scan's
            # duration -- see core/scanner.py's own per-source progress fix.
            if total:
                if self._scan_progress.maximum() != total:
                    self._scan_progress.setMaximum(total)
                self._scan_progress.setValue(completed)
        self.statusBar().showMessage(f"{message.splitlines()[0]}{' -- ' + current_source if current_source else ''}")

    def _scan_complete(self, outcome: Any) -> None:
        if self._scan_discarded:
            self.scan_summary.setPlainText("Latest scan completed but its results were discarded at user request. No source data was changed.")
            self.statusBar().showMessage("Scan completed; results discarded.")
            return
        self._scan_result, self._registry = outcome.result, outcome.registry; self._catalog = HullCatalog.from_scan(outcome.result)
        self.size_filter.clear(); self.source_filter.clear(); self.size_filter.addItem("All sizes", None); self.source_filter.addItem("All source mods", None)
        for value in self._catalog.hull_sizes(): self.size_filter.addItem(value, value)
        for value in self._catalog.source_mods(): self.source_filter.addItem(value, value)
        self._refresh_hulls(); self._populate_secondary()
        extra_note = f"Additional dropped mod(s) included: {', '.join(mod.mod_id or mod.mod_name or '?' for mod in self._extra_mods)}." if self._extra_mods else ""
        self.scan_summary.setPlainText("\n".join(line for line in (
            f"Loaded: {len(outcome.result.hulls)} hulls, {len(outcome.result.weapons)} weapons, {len(outcome.result.hullmods)} hullmods, {len(outcome.result.variants)} variants.",
            f"Diagnostics: {len(outcome.result.warnings)} warnings, {len(outcome.result.errors)} source errors, {len(outcome.result.skipped_entities)} skipped records.",
            self._scan_metrics_summary(outcome.result),
            extra_note,
            "Source data was read-only. Inspect Data / Analysis for entity provenance; local reports are under the configured output directory.",
        ) if line))
        self.statusBar().showMessage(f"Scan complete: {len(outcome.result.hulls)} hulls, {len(outcome.result.errors)} source errors.")

    @staticmethod
    def _scan_metrics_summary(result: Any) -> str:
        metrics = getattr(result, "scan_metrics", None)
        if metrics is None:
            return "Scan timing unavailable."
        total = getattr(metrics, "stage_seconds", {}).get("total", 0.0)
        return f"Performance: {getattr(metrics, 'sources_scanned', 0)} sources, {getattr(metrics, 'files_hashed', 0)} relevant files hashed, {total:.2f}s total."

    def _discard_scan(self) -> None:
        """Requests cooperative cancellation (Scanner.cancel_check, checked
        between sources -- see core/scanner.py's ScanCancelled) and
        discards any result that arrives anyway. Not instant: a source's
        own fingerprint/parse already in flight still finishes first, so
        the scan stops within roughly one source's worth of time rather
        than immediately, but "Scan Installed Data" re-enables as soon as
        that happens instead of waiting for the whole remaining scan."""
        if self._scan_thread is None: return
        self._scan_discarded = True; self.cancel_scan_button.setEnabled(False)
        if self._scan_cancel_event is not None: self._scan_cancel_event.set()
        if self._scan_progress is not None: self._scan_progress.setLabelText("Cancelling… finishing the current source before stopping.")
        self.statusBar().showMessage("Cancelling scan…")

    def _scan_finished(self) -> None:
        self._scan_watchdog.stop()
        self.scan_button.setEnabled(True); self.cancel_scan_button.setEnabled(False); self._scan_thread = None; self._scan_cancel_event = None; self._scan_worker = None
        if self._scan_progress is not None: self._scan_progress.close(); self._scan_progress.deleteLater(); self._scan_progress = None
        if self._scan_discarded: self.statusBar().showMessage("Scan cancelled.")

    def _check_scan_stall(self) -> None:
        """Watchdog tick (every 5s while a scan is in flight): if no real
        progress event has arrived in a while, log exactly what was last
        known -- stage, source, how long ago -- plus live worker/thread
        state, so an apparent hang is diagnosable from the log without
        needing to catch it live. Re-logs at most once per stall (reset the
        moment real progress resumes), not every 5s while it persists."""
        if self._scan_thread is None or self._scan_last_progress_at is None:
            return
        elapsed = monotonic() - self._scan_last_progress_at
        if elapsed < _SCAN_STALL_WARNING_INTERVAL_S:
            return
        if self._scan_stall_warned_at is not None:
            return
        self._scan_stall_warned_at = monotonic()
        stage = getattr(self._scan_last_progress, "stage", None) if self._scan_last_progress is not None else None
        source = getattr(self._scan_last_progress, "current_source", "") if self._scan_last_progress is not None else ""
        logging.getLogger("svg").warning(
            "Scan appears stalled: no progress event for %.1fs (last stage=%s, last source=%s, "
            "thread.isRunning()=%s, thread.isFinished()=%s, worker reference alive=%s)",
            elapsed, stage or "<none yet>", source or "<none>",
            self._scan_thread.isRunning(), self._scan_thread.isFinished(), self._scan_worker is not None,
        )

    def _workspace_changed(self, index: int) -> None:
        # Table rows stay in compact model storage rather than allocating one
        # widget item per cell. Materialization is still deferred until Data /
        # Analysis is opened; normalized backend indexes are already available.
        if index == 3 and self._data_tables_pending:
            self._populate_data_tables()

    def _populate_secondary(self) -> None:
        if self._scan_result is None: return
        self.variant_list.clear(); self.faction_list.clear(); self.generation_faction_selector.clear(); self.generation_faction_selector.addItem("No faction selected", None)
        for variant in sorted(self._scan_result.variants, key=lambda item: (item.name, item.id)):
            item = QListWidgetItem(f"{variant.name} • {variant.hull_id or 'Unknown hull'}"); item.setData(Qt.UserRole, variant.id); self.variant_list.addItem(item)
        for faction in sorted(self._scan_result.factions, key=lambda item: (item.name, item.id)):
            item = QListWidgetItem(f"{faction.name} • {faction.source_mod}"); item.setData(Qt.UserRole, (faction.id, faction.source_mod)); self.faction_list.addItem(item)
        for faction in sorted(self._scan_result.factions, key=lambda item: (item.name, item.id)):
            self.generation_faction_selector.addItem(f"{faction.name} ({faction.source_mod})", faction.id)
        self._data_entities = {"Weapons": self._scan_result.weapons, "Hullmods": self._scan_result.hullmods, "Fighters": self._scan_result.fighters, "Variants": self._scan_result.variants}
        self._data_tables_pending = True
        self.provenance_detail.setPlainText("Open Data / Analysis to materialize local normalized tables on demand.")
        for button in (self.fix_button, self.improve_button, self.compare_refit_button, self.capability_button, self.recommend_button, self.export_button): button.setEnabled(True)

    def _populate_data_tables(self) -> None:
        if not self._data_tables_pending:
            return
        entity_records = self._data_entities
        records: dict[str, list[tuple[str, ...]]] = {"Weapons": [(x.name, x.size or "Unknown", x.mount_type or "Unknown", x.source_mod) for x in entity_records["Weapons"]], "Hullmods": [(x.name, "Yes" if x.hidden else "No", x.source_mod) for x in entity_records["Hullmods"]], "Fighters": [(x.name, x.role or "Unknown", x.source_mod) for x in entity_records["Fighters"]], "Variants": [(x.name, x.hull_id or "Unknown", x.source_mod) for x in entity_records["Variants"]]}
        for name, rows in records.items():
            model = self.data_tables[name].model()
            assert isinstance(model, EntityTableModel)
            model.set_records(rows, list(entity_records[name]))
        self._data_tables_pending = False

    def _refresh_hulls(self) -> None:
        if self._catalog is None: return
        self._visible = self._catalog.filter(self.search.text(), self.size_filter.currentData(), self.source_filter.currentData()); self.hull_list.blockSignals(True); self.hull_list.clear()
        for hull in self._visible:
            item = QListWidgetItem(f"{hull.name}\n{hull.hull_size or 'Unknown'} • {hull.source_mod}"); item.setData(Qt.UserRole, hull.id); self.hull_list.addItem(item)
        self.hull_list.blockSignals(False); self.count.setText(f"HULLS ({len(self._visible)})"); self.hull_list.setCurrentRow(0 if self._visible else -1)

    def _schedule_hull_refresh(self) -> None:
        """Avoid rebuilding a large hull list once per keystroke."""
        self._hull_filter_timer.start()

    def _reset_filters(self) -> None: self.search.clear(); self.size_filter.setCurrentIndex(0); self.source_filter.setCurrentIndex(0)

    def _show_provenance(self, category: str) -> None:
        table = self.data_tables[category]; row = table.currentIndex().row()
        model = table.model()
        if not isinstance(model, EntityTableModel) or row < 0 or row >= len(model.entities): return
        entity = model.entities[row]
        lines = [
            f"ID: {entity.id}", f"Name: {entity.name}", f"Source mod: {entity.source_mod}",
            f"Source file: {entity.source_path}", f"Source hash: {entity.source_hash or 'Unavailable'}",
            f"Source mod version: {entity.source_mod_version or 'Unavailable'}",
        ]
        if category == "Variants":
            lines.append(f"Parent hull: {entity.hull_id or 'Unavailable'}")
            if isinstance(entity.raw.get("modules"), list) and entity.raw["modules"]:
                lines.append("Complex module mappings: retained as provenance only; not compositely analyzed.")
        self.provenance_detail.setPlainText("\n".join(lines))

    def _open_variant_hull(self, item: QListWidgetItem) -> None:
        if self._registry is None: return
        variant = self._registry.variants.by_id.get(str(item.data(Qt.UserRole)))
        hull = self._registry.hulls.by_id.get(variant.hull_id) if variant and variant.hull_id else None
        if hull is None:
            self.refit_detail.setPlainText("The variant parent hull is missing or ambiguous; it cannot be opened safely.")
            return
        self.workspace_tabs.setCurrentIndex(0); self.ship_tabs.setCurrentIndex(0)
        try: self.hull_list.setCurrentRow(self._visible.index(hull))
        except ValueError:
            self.search.clear(); self.size_filter.setCurrentIndex(0); self.source_filter.setCurrentIndex(0); self._refresh_hulls(); self.hull_list.setCurrentRow(self._visible.index(hull))

    def _selected_hull(self, row: int) -> None:
        if row < 0 or row >= len(self._visible): self.canvas.show_empty(); self.generate_button.setEnabled(False); self._mirror_pairs = {}; self.mirror_fitting.setEnabled(False); self.mirror_fitting.setChecked(False); self.mirror_fitting.setText("Mirror fitting"); self.mirror_fitting.setToolTip("No hull selected yet."); return
        hull = self._visible[row]; self._current_hull = hull; self._fit_weapons = dict(hull.built_in_weapons); self.heading.setText(hull.name); self.subheading.setText(f"{hull.id} • {hull.source_mod}")
        data = {"Hull Size": hull.hull_size or "Unknown", "Source Mod": hull.source_mod, "OP": str(hull.ordnance_points or "Unknown"), "Weapon Mounts": str(len(hull.weapon_mounts)), "Built-ins": str(len(hull.built_in_hullmods) + len(hull.built_in_weapons))}
        for key, value in data.items(): self.values[key].setText(value)
        self._mirror_pairs = _detect_mirror_mount_pairs(hull)
        pair_count = len(self._mirror_pairs) // 2
        self.mirror_fitting.setEnabled(pair_count > 0)
        if not pair_count: self.mirror_fitting.setChecked(False)
        self.mirror_fitting.setText(f"Mirror fitting ({pair_count} pair{'s' if pair_count != 1 else ''} detected)" if pair_count else "Mirror fitting (no symmetric pairs detected)")
        self.mirror_fitting.setToolTip("Assigning or clearing a weapon on one mount also applies it to its detected left/right mirror mount." if pair_count else "No left/right mirror-symmetric mount pairs were found in this hull's parsed geometry.")
        self._refresh_slots(); self._update_fit_metrics(); self.canvas.show_hull(hull, self._fit_weapons); self.inspect_detail.setPlainText(f"{hull.name} ({hull.id})\nSource: {hull.source_mod}\nMounts: {len(hull.weapon_mounts)} | OP: {hull.ordnance_points}"); self.generate_button.setEnabled(self._registry is not None)

    def _update_fit_metrics(self) -> None:
        if self._registry is None or self._current_hull is None: return
        fit = Variant(f"gui_{self._current_hull.id}", "GUI Fit", "GENERATED", self._current_hull.source_path, hull_id=self._current_hull.id, weapons_by_mount=dict(self._fit_weapons))
        summary = api.run_fit_summary(self._registry, fit)
        available = summary["hull_ordnance_points"] if summary["hull_ordnance_points"] is not None else "Unknown"
        text = f"FIT STATUS: {summary['legality']}\nWeapon OP {summary['weapon_op_used']}/{available}"
        if summary["weapon_op_remaining"] is not None: text += f" (remaining {summary['weapon_op_remaining']})"
        notes = [*summary["failures"], *summary["uncertainties"]]
        self.fit_metrics.setText(text + (f"\n{'; '.join(notes)}" if notes else ""))

    def _refresh_slots(self) -> None:
        self.slots.clear()
        if self._current_hull is None: return
        for slot in self._current_hull.weapon_mounts:
            slot_id = str(slot.get("id", ""))
            if slot_id:
                item = QListWidgetItem(f"{slot_id}: {self._fit_weapons.get(slot_id, '<Empty>')}"); item.setData(Qt.UserRole, slot_id)
                if slot_id in self._current_hull.built_in_weapons: item.setFlags(item.flags() & ~Qt.ItemIsEnabled)
                self.slots.addItem(item)

    def _choose_slot(self, item: QListWidgetItem) -> None:
        if self._registry is None or self._current_hull is None: return
        slot_id = str(item.data(Qt.UserRole)); faction_id = self.generation_faction_selector.currentData(); faction_mode = str(self.faction_mode_selector.currentData())
        if faction_mode == "STRICT_FACTION" and faction_id is None:
            QMessageBox.information(self, "Faction required", "Select a faction before using Strict Faction equipment access."); return
        # STRICT_FACTION filtering re-classifies every scanned weapon's
        # faction affinity against every scanned faction's known_* lists
        # (analysis/equipment_affinity.py) -- on a large real install this
        # is a real, non-instant computation, and unlike every other
        # backend call in this file it runs synchronously on the GUI
        # thread (a modal QInputDialog needs the result immediately
        # afterwards, so it can't go through the background-thread _run()
        # pattern without restructuring this into an async flow). A wait
        # cursor plus a status-bar message is the minimal, low-risk way to
        # signal "working" for that duration.
        self.statusBar().showMessage("Finding backend-eligible weapons for this mount…")
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            eligible = api.run_slot_eligible_weapons(self._registry, self._current_hull.id, slot_id, include_hidden=self.slot_include_hidden.isChecked(), faction_id=str(faction_id) if faction_id else None, faction_mode=faction_mode)
        except ValueError as exc:
            # Reachable when self._current_hull/slot data has gone stale
            # relative to self._registry -- e.g. an incremental dropped-mod
            # incorporation (see _apply_incremental_scan_outcome) made the
            # displayed hull ambiguous after it was selected but before this
            # slot was double-clicked. Previously unguarded: this raised a
            # bare ValueError straight out of a Qt slot instead of the
            # QMessageBox.critical every other backend call in this file
            # routes failures through.
            self._operation_failed(str(exc)); return
        finally:
            QApplication.restoreOverrideCursor()
        choices = ["<Empty>", *[f"{x.name} [{x.id}] — {x.source_mod}" for x in eligible]]; choice, accepted = QInputDialog.getItem(self, "Select legal weapon", slot_id, choices, 0, True)
        if not accepted: return
        mirror_id = self._mirror_pairs.get(slot_id) if self.mirror_fitting.isChecked() else None
        if mirror_id is not None and mirror_id in self._current_hull.built_in_weapons: mirror_id = None
        if choice == "<Empty>":
            self._fit_weapons.pop(slot_id, None)
            if mirror_id is not None: self._fit_weapons.pop(mirror_id, None)
        else:
            selected = next((weapon for weapon in eligible if f"{weapon.name} [{weapon.id}] — {weapon.source_mod}" == choice), None)
            if selected is None: QMessageBox.warning(self, "Invalid selection", "Choose an item from the backend-filtered list."); return
            self._fit_weapons[slot_id] = selected.id
            if mirror_id is not None: self._fit_weapons[mirror_id] = selected.id
        fit = Variant(f"gui_{self._current_hull.id}", "GUI Fit", "GENERATED", self._current_hull.source_path, hull_id=self._current_hull.id, weapons_by_mount=dict(self._fit_weapons)); assessment = api.run_validate_fit(self._registry, fit); details = "; ".join(x.message for x in (*assessment.failures, *assessment.uncertainties))
        self.statusBar().showMessage(f"{assessment.result}: {details or 'No legality findings.'}"); self._refresh_slots(); self._update_fit_metrics(); self.canvas.show_hull(self._current_hull, self._fit_weapons); self.inspect_detail.appendPlainText(f"\nManual fit legality: {assessment.result}\n{details}")

    def _run(self, message: str, operation: Callable[[], Any], completed: Callable[[Any], None], control: QPushButton) -> None:
        # Backend tasks are immutable snapshots. Token-gating prevents a stale
        # result from replacing a newer UI request without unsafe cancellation.
        token = self._operation_tokens.get(control, 0) + 1; self._operation_tokens[control] = token
        thread = QThread(self); worker = AnalysisWorker(operation); worker.moveToThread(thread); thread.started.connect(worker.run)
        # thread.quit connected first, before the application-level
        # handler -- see _start_scan's identical reasoning.
        worker.completed.connect(thread.quit); worker.completed.connect(lambda result: self._complete_operation(control, token, completed, result))
        worker.failed.connect(thread.quit); worker.failed.connect(self._operation_failed)
        thread.finished.connect(worker.deleteLater); thread.finished.connect(lambda: self._finish_thread(thread, control))
        self._threads.add(thread); self._active_workers[thread] = worker; control.setEnabled(False); self.statusBar().showMessage(message); thread.start()

    def _complete_operation(self, control: QPushButton, token: int, completed: Callable[[Any], None], result: Any) -> None:
        if self._operation_tokens.get(control) == token:
            completed(result)

    def _finish_thread(self, thread: QThread, control: QPushButton) -> None: self._threads.discard(thread); self._active_workers.pop(thread, None); control.setEnabled(self._registry is not None); thread.deleteLater()
    def _operation_failed(self, message: str) -> None: self.statusBar().showMessage(f"Operation failed: {message}"); QMessageBox.critical(self, "Operation failed", message)

    def _registry_write_in_progress(self) -> bool:
        """True while a full scan or an incremental dropped-mod
        incorporation is rewriting self._scan_result/self._registry/
        self._catalog -- both disable scan_button while in flight (see
        _start_scan and dropEvent's own guard). A backend read started via
        _run only actually reads self._registry once its worker thread
        executes, not when its button was clicked, so a write landing in
        that gap would silently swap the data out from under an
        already-running read. Callers that read the registry in a
        background thread (_generate, _refit, faction analysis, export)
        check this first and decline to start rather than race it."""
        return self._scan_thread is not None or not self.scan_button.isEnabled()

    def _generate(self) -> None:
        if self._registry is not None and self._current_hull is not None:
            if self._registry_write_in_progress():
                self.statusBar().showMessage("A scan or mod incorporation is still in progress; wait for it to finish before generating.")
                return
            hull_id = self._current_hull.id
            mode = str(self.mode_selector.currentData())
            profile = self.profile_selector.currentData()
            faction_mode = str(self.faction_mode_selector.currentData())
            faction_id = self.generation_faction_selector.currentData()
            flux_mode = str(self.flux_selector.currentData())
            max_candidates = self.max_candidates.value()
            search_depth = self.search_depth.value()
            config_text = self.advanced_config.text().strip()
            advanced_config = Path(config_text) if config_text else None
            if advanced_config is not None and not advanced_config.is_file():
                QMessageBox.warning(self, "Invalid advanced request", "Choose an existing JSON request file or clear the field.")
                return
            if advanced_config is not None and mode != "advanced":
                QMessageBox.warning(self, "Advanced request", "Select Advanced / Manual mode before applying an advanced request.")
                return
            if faction_mode == "STRICT_FACTION" and faction_id is None:
                QMessageBox.warning(self, "Faction required", "Select a faction before using Strict Faction equipment access.")
                return
            heuristic_set = self._config.heuristic_set if self._config is not None else "baseline_0.7"
            self._run(
                "Generating legal build candidates…",
                lambda: api.run_generate(
                    self._registry, heuristic_set, hull_id, mode, profile=profile, faction_id=str(faction_id) if faction_id else None,
                    faction_mode=faction_mode, advanced_config=advanced_config,
                    flux_mode=flux_mode, max_candidates=max_candidates, search_depth=search_depth,
                ),
                self._generation_complete, self.generate_button,
            )
    def _generation_complete(self, outcome: Any) -> None:
        text = format_generation_results(outcome.assessed_candidates, outcome.selected_profile, outcome.flux_mode)
        self._generated_candidates = list(outcome.assessed_candidates)
        self.candidate_cards.blockSignals(True); self.candidate_cards.clear()
        for index, candidate in enumerate(self._generated_candidates, 1):
            build = candidate.get("build_archetype", {})
            label = candidate.get("recommendation_label") or build.get("role") or "Candidate"
            score = candidate.get("build_recommendation_score", candidate.get("quality", {}).get("final_score"))
            confidence = build.get("confidence")
            item = QListWidgetItem(f"{index}. {label}\nScore: {score if score is not None else 'Unavailable'}   Confidence: {confidence if confidence is not None else 'Unavailable'}")
            item.setData(Qt.UserRole, index - 1); self.candidate_cards.addItem(item)
        self.candidate_cards.blockSignals(False)
        self.open_advanced_button.setEnabled(bool(self._generated_candidates))
        if self._generated_candidates: self.candidate_cards.setCurrentRow(0)
        else: self.build_results.setPlainText(text)
        self.compare_detail.setPlainText(text); self.statusBar().showMessage("Generation complete.")

    def _preview_candidate(self, row: int) -> None:
        if row < 0 or row >= len(self._generated_candidates): return
        candidate = self._generated_candidates[row]
        self.build_results.setPlainText(format_generation_results([candidate], "Selected candidate", "Backend supplied"))
        variant = candidate.get("variant", {})
        weapons = variant.get("weapons_by_mount")
        if self._current_hull is not None and isinstance(weapons, dict):
            self._fit_weapons = {str(mount): str(weapon) for mount, weapon in weapons.items()}
            self._refresh_slots(); self.canvas.show_hull(self._current_hull, self._fit_weapons)

    def _open_selected_in_advanced(self) -> None:
        """Keep the selected backend result visible; never regenerate it here."""
        row = self.candidate_cards.currentRow()
        if row < 0 or row >= len(self._generated_candidates): return
        profile_id = self._generated_candidates[row].get("profile_id")
        if isinstance(profile_id, str):
            index = self.profile_selector.findData(profile_id)
            if index >= 0: self.profile_selector.setCurrentIndex(index)
        mode_index = self.mode_selector.findData("advanced")
        if mode_index >= 0: self.mode_selector.setCurrentIndex(mode_index)
        self.build_results.appendPlainText("Opened in Advanced controls without regenerating; the selected candidate remains on the fitting canvas.")
        self.statusBar().showMessage("Selected candidate preserved in Advanced / Manual controls.")

    def _variant_id(self) -> str | None:
        item = self.variant_list.currentItem(); return str(item.data(Qt.UserRole)) if item is not None else None
    def _refit(self, operation: Callable[[str], Any], button: QPushButton, message: str) -> None:
        variant_id = self._variant_id()
        if self._registry is None or variant_id is None: self.refit_detail.setPlainText("Select an existing scanned variant first."); return
        if self._registry_write_in_progress(): self.refit_detail.setPlainText("A scan or mod incorporation is still in progress; wait for it to finish first."); return
        self._run(message, lambda: operation(variant_id), lambda result: self.refit_detail.setPlainText(str(result)), button)
    def _compare_refit(self) -> None:
        heuristic_set = self._config.heuristic_set if self._config is not None else "baseline_0.7"
        self._refit(lambda item: api.run_analyze_variant(self._registry, item, "LINE_BRAWLER", "BALANCED", heuristic_set), self.compare_refit_button, "Analyzing existing variant…")

    @staticmethod
    def _refit_lock_ids(field: QLineEdit) -> frozenset[str]:
        return frozenset(item.strip() for item in field.text().split(",") if item.strip())

    def _fix_legality(self) -> None:
        mounts, hullmods, wings = self._refit_lock_ids(self.refit_locked_mounts), self._refit_lock_ids(self.refit_locked_hullmods), self._refit_lock_ids(self.refit_locked_wings)
        mode = str(self.refit_substitution_selector.currentData())
        heuristic_set = self._config.heuristic_set if self._config is not None else "baseline_0.7"
        self._refit(lambda item: api.run_fix_legality(self._registry, item, heuristic_set, locked_mount_ids=mounts, locked_hullmod_ids=hullmods, locked_wing_ids=wings, substitution_mode=mode), self.fix_button, "Finding minimal legality fixes")

    def _improve_quality(self) -> None:
        mounts, hullmods, wings = self._refit_lock_ids(self.refit_locked_mounts), self._refit_lock_ids(self.refit_locked_hullmods), self._refit_lock_ids(self.refit_locked_wings)
        mode, profile = str(self.refit_mode_selector.currentData()), str(self.refit_profile_selector.currentData())
        heuristic_set = self._config.heuristic_set if self._config is not None else "baseline_0.7"
        self._refit(lambda item: api.run_improve_quality(self._registry, item, mode, profile, heuristic_set, locked_mount_ids=mounts, locked_hullmod_ids=hullmods, locked_wing_ids=wings), self.improve_button, "Improving existing variant")

    def _faction_selected(self, _: int) -> None: self.faction_detail.setPlainText("Choose capability analysis or gap recommendations.") if self._faction_id() else None
    def _faction_id(self) -> tuple[str, str | None] | None:
        item = self.faction_list.currentItem(); value = item.data(Qt.UserRole) if item is not None else None; return tuple(value) if isinstance(value, tuple) and len(value) == 2 else None
    def _faction_run(self, operation: Callable[[str, str | None], Any], button: QPushButton, message: str) -> None:
        selected = self._faction_id()
        if self._registry is None or selected is None: self.faction_detail.setPlainText("Select a scanned faction first."); return
        if self._registry_write_in_progress(): self.faction_detail.setPlainText("A scan or mod incorporation is still in progress; wait for it to finish first."); return
        faction_id, source_mod = selected; self._run(message, lambda: operation(faction_id, source_mod), lambda result: self.faction_detail.setPlainText(str(result)), button)
    def _analyze_capability(self) -> None:
        heuristic_set = self._config.heuristic_set if self._config is not None else "baseline_0.7"
        self._faction_run(lambda faction, source: api.run_faction_capability(self._registry, faction, source, heuristic_set), self.capability_button, "Computing faction capability vector…")
    def _gap_recommendations(self) -> None:
        heuristic_set = self._config.heuristic_set if self._config is not None else "baseline_0.7"
        self._faction_run(lambda faction, source: api.run_gap_recommendations(self._registry, faction, source, heuristic_set), self.recommend_button, "Ranking Hull + BuildArchetype gap solutions…")

    def _export_current(self) -> None:
        if self._registry is None or self._current_hull is None: QMessageBox.information(self, "No hull selected", "Select a scanned hull before exporting."); return
        output_text = self.output.text().strip()
        # Mirrors _start_scan's own check on this same field: without it, a
        # cleared output box wouldn't raise or warn at all -- write_variant
        # creates missing parent directories on demand, so Path("") would
        # silently resolve to (and write under) the current working
        # directory instead of anywhere the user chose.
        if not output_text: QMessageBox.warning(self, "Output directory required", "Choose a safe output directory for generated reports and local cache data."); return
        if self._registry_write_in_progress(): self.statusBar().showMessage("A scan or mod incorporation is still in progress; wait for it to finish before exporting."); return
        output, hull_id = Path(output_text), self._current_hull.id
        heuristic_set = self._config.heuristic_set if self._config is not None else "baseline_0.7"
        self._run("Creating conservative compatibility-mod export…", lambda: api.run_export(self._registry, heuristic_set, output, hull_id, "LINE_BRAWLER"), lambda path: self.statusBar().showMessage(f"Export complete: {path}"), self.export_button)

    def closeEvent(self, event: Any) -> None:  # type: ignore[override]
        self._preferences.setValue("window/size", super().size()); self._preferences.setValue("paths/starsector", self.root.text()); self._preferences.setValue("paths/output", self.output.text())
        self._preferences.setValue("fit/mode", self.mode_selector.currentData()); self._preferences.setValue("fit/faction_mode", self.faction_mode_selector.currentData()); self._preferences.setValue("fit/show_hidden", self.slot_include_hidden.isChecked()); super().closeEvent(event)
