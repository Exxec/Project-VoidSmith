from __future__ import annotations

from dataclasses import dataclass, field
from typing import Generic, Iterable, TypeVar

from starsector_variant_generator.core.models import Entity, ModInfo, ScanResult, Variant


T = TypeVar("T", bound=Entity)


@dataclass
class EntityIndex(Generic[T]):
    """Deterministic ID index that never resolves duplicate IDs by guessing."""

    by_id: dict[str, T] = field(default_factory=dict)
    duplicates: dict[str, list[T]] = field(default_factory=dict)

    @classmethod
    def build(cls, entities: Iterable[T]) -> "EntityIndex[T]":
        index = cls()
        for entity in entities:
            if entity.id in index.by_id:
                index.duplicates.setdefault(entity.id, [index.by_id.pop(entity.id)]).append(entity)
            elif entity.id not in index.duplicates:
                index.by_id[entity.id] = entity
        return index


@dataclass(frozen=True)
class UnresolvedReference:
    variant_id: str
    reference_type: str
    reference_id: str


@dataclass(frozen=True)
class MissingDependency:
    mod_id: str
    dependency_id: str


@dataclass
class Registry:
    hulls: EntityIndex = field(default_factory=EntityIndex)
    weapons: EntityIndex = field(default_factory=EntityIndex)
    fighters: EntityIndex = field(default_factory=EntityIndex)
    hullmods: EntityIndex = field(default_factory=EntityIndex)
    variants: EntityIndex = field(default_factory=EntityIndex)
    factions: EntityIndex = field(default_factory=EntityIndex)
    unresolved_references: list[UnresolvedReference] = field(default_factory=list)
    missing_dependencies: list[MissingDependency] = field(default_factory=list)

    @classmethod
    def from_scan(cls, scan: ScanResult) -> "Registry":
        registry = cls(
            hulls=EntityIndex.build(scan.hulls), weapons=EntityIndex.build(scan.weapons),
            fighters=EntityIndex.build(scan.fighters), hullmods=EntityIndex.build(scan.hullmods),
            variants=EntityIndex.build(scan.variants), factions=EntityIndex.build(scan.factions),
        )
        registry._resolve_variants(scan.variants)
        registry._resolve_dependencies(scan.mods)
        return registry

    def _resolve_variants(self, variants: Iterable[Variant]) -> None:
        for variant in variants:
            if variant.hull_id and variant.hull_id not in self.hulls.by_id:
                self.unresolved_references.append(UnresolvedReference(variant.id, "hull", variant.hull_id))
            for weapon_id in variant.weapons_by_mount.values():
                if weapon_id not in self.weapons.by_id:
                    self.unresolved_references.append(UnresolvedReference(variant.id, "weapon", weapon_id))
            for hullmod_id in variant.hullmods:
                if hullmod_id not in self.hullmods.by_id:
                    self.unresolved_references.append(UnresolvedReference(variant.id, "hullmod", hullmod_id))

    def _resolve_dependencies(self, mods: Iterable[ModInfo]) -> None:
        mod_list = list(mods)
        available = {mod.mod_id for mod in mod_list}
        for mod in mod_list:
            for dependency in mod.dependencies:
                if dependency not in available:
                    self.missing_dependencies.append(MissingDependency(mod.mod_id, dependency))

    def weapons_matching(self, size: str | None = None, mount_type: str | None = None) -> tuple[Entity, ...]:
        """Return only unambiguous indexed weapons matching explicit fields."""
        normalized_size = size.upper() if size else None
        normalized_type = mount_type.upper() if mount_type else None
        return tuple(
            weapon for weapon in sorted(self.weapons.by_id.values(), key=lambda item: item.id)
            if (normalized_size is None or (getattr(weapon, "size", "") or "").upper() == normalized_size)
            and (normalized_type is None or (getattr(weapon, "mount_type", "") or "").upper() == normalized_type)
        )

    def fighters_matching(self, role: str | None = None) -> tuple[Entity, ...]:
        """Return only unambiguous indexed fighter wings matching explicit fields."""
        normalized_role = role.upper() if role else None
        return tuple(
            fighter for fighter in sorted(self.fighters.by_id.values(), key=lambda item: item.id)
            if normalized_role is None or (getattr(fighter, "role", "") or "").upper() == normalized_role
        )

    def hullmods_matching(self, hidden: bool | None = None) -> tuple[Entity, ...]:
        """Return only unambiguous indexed hullmods matching explicit fields."""
        return tuple(
            hullmod for hullmod in sorted(self.hullmods.by_id.values(), key=lambda item: item.id)
            if hidden is None or bool(getattr(hullmod, "hidden", False)) == hidden
        )

    def hulls_matching(self, hull_size: str | None = None) -> tuple[Entity, ...]:
        """Return only unambiguous indexed hulls matching explicit fields."""
        normalized_size = hull_size.upper() if hull_size else None
        return tuple(
            hull for hull in sorted(self.hulls.by_id.values(), key=lambda item: item.id)
            if normalized_size is None or (getattr(hull, "hull_size", "") or "").upper() == normalized_size
        )

    def variants_for_hull(self, hull_id: str) -> tuple[Variant, ...]:
        return tuple(sorted((variant for variant in self.variants.by_id.values() if variant.hull_id == hull_id), key=lambda item: item.id))

    def faction_equipment(self, faction_id: str, source_mod: str | None = None) -> dict[str, tuple[str, ...]]:
        candidates = ([self.factions.by_id[faction_id]] if faction_id in self.factions.by_id else self.factions.duplicates.get(faction_id, []))
        if source_mod is not None:
            candidates = [faction for faction in candidates if faction.source_mod == source_mod]
        if len(candidates) != 1:
            raise ValueError(f"Faction not found or ambiguous: {faction_id}; provide source_mod for overrides")
        faction = candidates[0]
        return {
            "known_hulls": tuple(sorted(faction.known_hulls)),
            "known_weapons": tuple(sorted(faction.known_weapons)),
            "known_fighters": tuple(sorted(faction.known_fighters)),
            "known_hullmods": tuple(sorted(faction.known_hullmods)),
        }
