"""Run reviewer calibration labels against a current local scan.

This module deliberately evaluates reviewer-authored expectations only.  It
never creates labels, changes heuristics, or treats its own output as ground
truth.  A label whose exact source hull cannot be generated safely remains
``UNSUPPORTED`` rather than selecting a same-ID entity from another mod.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from starsector_variant_generator import api
from starsector_variant_generator.analysis.calibration import (
    CalibrationExpectationKind,
    CalibrationLabel,
)
from starsector_variant_generator.core.models import Hull, ScanResult
from starsector_variant_generator.core.registry import Registry


@dataclass(frozen=True)
class CalibrationRun:
    """Normalized observations and non-authoritative execution diagnostics."""

    observations: dict[str, dict[str, str]]
    diagnostics: tuple[dict[str, str], ...]


def _source_hull(label: CalibrationLabel, scan: ScanResult) -> Hull | None:
    """Resolve only a fully-qualified ``hull:<source_mod>:<id>`` key."""
    parts = label.entity_key.split(":", 2)
    if len(parts) != 3 or parts[0] != "hull":
        return None
    source_mod, hull_id = parts[1:]
    matches = [hull for hull in scan.hulls if hull.source_mod == source_mod and hull.id == hull_id]
    return matches[0] if len(matches) == 1 else None


def _build_actual(outcome: api.GenerateOutcome) -> str | None:
    """Return the best independently generated build ID, if one exists."""
    for candidate in outcome.assessed_candidates:
        if candidate.get("legality") != "LEGAL":
            continue
        build = candidate.get("build_archetype")
        if isinstance(build, dict) and isinstance(build.get("build_id"), str):
            return build["build_id"]
    return None


def collect_build_observations(
    labels: tuple[CalibrationLabel, ...],
    scan: ScanResult,
    registry: Registry,
    heuristic_set: str,
) -> CalibrationRun:
    """Generate hash-bound observations for supported hull build expectations.

    The global registry intentionally refuses ambiguous IDs.  Consequently a
    label for a source-qualified hull with a duplicated global ID is retained
    with its hash but no ``actual`` result; the evaluator will report it as
    ``UNSUPPORTED``.  This is fail-closed and prevents accidental cross-mod
    calibration.
    """
    observations: dict[str, dict[str, str]] = {}
    diagnostics: list[dict[str, str]] = []
    supported_kinds = {
        CalibrationExpectationKind.BUILD_EXPECTATION,
        CalibrationExpectationKind.NEGATIVE_EXPECTATION,
    }
    for label in labels:
        hull = _source_hull(label, scan)
        if hull is None:
            diagnostics.append({"entity_key": label.entity_key, "status": "UNSUPPORTED", "reason": "entity_key_not_a_unique_local_hull"})
            continue
        if hull.source_hash:
            observations[label.entity_key] = {"entity_hash": hull.source_hash}
        if label.expectation_kind not in supported_kinds:
            diagnostics.append({"entity_key": label.entity_key, "status": "UNSUPPORTED", "reason": "expectation_kind_has_no_registered_runtime_observer"})
            continue
        if hull.id not in registry.hulls.by_id:
            diagnostics.append({"entity_key": label.entity_key, "status": "UNSUPPORTED", "reason": "hull_id_is_ambiguous_in_registry"})
            continue
        try:
            actual = _build_actual(api.run_generate(registry, heuristic_set, hull.id, "guided"))
        except (ValueError, KeyError) as exc:
            diagnostics.append({"entity_key": label.entity_key, "status": "UNSUPPORTED", "reason": f"generation_failed:{type(exc).__name__}"})
            continue
        if actual is None:
            diagnostics.append({"entity_key": label.entity_key, "status": "UNSUPPORTED", "reason": "no_legal_build_candidate"})
            continue
        observations[label.entity_key]["actual"] = actual
        diagnostics.append({"entity_key": label.entity_key, "status": "OBSERVED", "reason": "best_legal_build_archetype"})
    return CalibrationRun(observations, tuple(diagnostics))
