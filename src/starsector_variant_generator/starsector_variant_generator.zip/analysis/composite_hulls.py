"""Structural profiles for parent/module hull variants.

This module deliberately models references, not composite combat behavior.  A
module's fitting and raw mechanics remain local to its own hull/variant.  No
consumer may sum or otherwise merge those facts into the parent without a
separate, documented composite-mechanics contract.
"""
from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from starsector_variant_generator.analysis.complex_hulls import ComplexHullFeature
from starsector_variant_generator.core.models import ScanResult, Variant
from starsector_variant_generator.core.registry import Registry


class ModuleResolution(StrEnum):
    RESOLVED = "RESOLVED"
    UNRESOLVED_PARENT = "UNRESOLVED_PARENT"
    UNRESOLVED_CHILD_VARIANT = "UNRESOLVED_CHILD_VARIANT"
    UNRESOLVED_CHILD_HULL = "UNRESOLVED_CHILD_HULL"


@dataclass(frozen=True)
class ModuleProfile:
    """One declared parent slot -> child-variant reference, never an aggregate."""

    module_slot_id: str
    child_variant_id: str
    child_hull_id: str | None
    resolution: ModuleResolution
    source_mod: str
    source_path: str


@dataclass(frozen=True)
class CompositeHullProfile:
    """Parseable structure for a variant with module mappings.

    ``analysis_state`` is intentionally fixed to ``STRUCTURAL_ONLY``.  It is
    a guard against accidentally using this profile as proof of composite
    legality, firepower, shielding, system behavior, or survivability.
    """

    parent_variant_id: str
    parent_hull_id: str | None
    source_mod: str
    modules: tuple[ModuleProfile, ...]
    structural_features: tuple[ComplexHullFeature, ...]
    analysis_state: str = "STRUCTURAL_ONLY"
    confidence: float = 1.0


def module_mappings(variant: Variant) -> tuple[tuple[str, str], ...]:
    """Return actual slot mappings only; empty module arrays have no meaning."""
    raw_modules = variant.raw.get("modules")
    if not isinstance(raw_modules, list) or not raw_modules:
        return ()
    mappings: list[tuple[str, str]] = []
    for mapping in raw_modules:
        if not isinstance(mapping, dict):
            continue
        for slot, target in mapping.items():
            if isinstance(slot, str) and slot and isinstance(target, str) and target:
                mappings.append((slot, target))
    return tuple(mappings)


def build_composite_hull_profiles(scan: ScanResult, registry: Registry) -> tuple[CompositeHullProfile, ...]:
    """Resolve declared module references without guessing duplicate IDs."""
    profiles: list[CompositeHullProfile] = []
    for parent_variant in sorted(scan.variants, key=lambda item: (item.source_mod, item.id, str(item.source_path))):
        mappings = module_mappings(parent_variant)
        if not mappings:
            continue
        parent = registry.hulls.by_id.get(parent_variant.hull_id or "")
        modules: list[ModuleProfile] = []
        for slot, child_variant_id in mappings:
            child_variant = registry.variants.by_id.get(child_variant_id)
            if parent is None:
                resolution = ModuleResolution.UNRESOLVED_PARENT
                child_hull_id = None
            elif child_variant is None:
                resolution = ModuleResolution.UNRESOLVED_CHILD_VARIANT
                child_hull_id = None
            elif not child_variant.hull_id or child_variant.hull_id not in registry.hulls.by_id:
                resolution = ModuleResolution.UNRESOLVED_CHILD_HULL
                child_hull_id = child_variant.hull_id
            else:
                resolution = ModuleResolution.RESOLVED
                child_hull_id = child_variant.hull_id
            modules.append(ModuleProfile(slot, child_variant_id, child_hull_id, resolution, parent_variant.source_mod, str(parent_variant.source_path)))
        targets = [module.child_variant_id for module in modules]
        features = [ComplexHullFeature.MULTIPART_PARENT_CHILD]
        if len(targets) != len(set(targets)):
            features.append(ComplexHullFeature.REPEATED_MODULES)
        if len(set(targets)) > 1:
            features.append(ComplexHullFeature.ASYMMETRIC_MODULES)
        if parent is not None and "STATION" in {hint.upper() for hint in parent.hull_hints}:
            features.append(ComplexHullFeature.STATION_STYLE_MODULES)
        confidence = 1.0 if all(module.resolution is ModuleResolution.RESOLVED for module in modules) else 0.5
        profiles.append(CompositeHullProfile(parent_variant.id, parent_variant.hull_id, parent_variant.source_mod, tuple(modules), tuple(features), confidence=confidence))
    return tuple(profiles)
