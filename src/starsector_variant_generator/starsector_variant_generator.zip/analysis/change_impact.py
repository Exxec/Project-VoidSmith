"""Read-only scan reconciliation and direct analysis-impact planning.

This deliberately plans invalidation only.  It neither caches nor recomputes
analysis, and cannot write game/mod sources.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from starsector_variant_generator.core.cache import build_manifest
from starsector_variant_generator.core.knowledge_packs import KnowledgePack
from starsector_variant_generator.core.models import ScanResult


@dataclass(frozen=True)
class EntityChange:
    category: str
    source_mod: str
    entity_id: str
    source_path: str
    status: str
    previous_hash: str | None
    current_hash: str | None


@dataclass(frozen=True)
class ImpactTarget:
    kind: str
    target_id: str
    certainty: str  # EXACT | CONSERVATIVE
    because: tuple[str, ...]


@dataclass(frozen=True)
class ChangeImpactReport:
    schema_version: str
    changes: tuple[EntityChange, ...]
    impacts: tuple[ImpactTarget, ...]
    warnings: tuple[str, ...]


def analyze_change_impact(previous_manifest: dict[str, Any] | None, current: ScanResult, knowledge_packs: tuple[KnowledgePack, ...] = ()) -> ChangeImpactReport:
    """Compare a prior cache manifest to a scan and plan direct invalidation."""
    prior = (previous_manifest or {}).get("entries", [])
    now = build_manifest(current)["entries"]
    # IDs are game-facing identifiers, not globally unique source records:
    # modules and alternate variants may deliberately share one within a mod.
    # A normalized source path makes the impact key stable without pretending
    # those legitimate duplicates are a parser conflict.
    key = lambda entry: (str(entry["category"]), str(entry["source_mod"]), str(entry["id"]), str(entry["source_path"]))
    old_groups: dict[tuple[str, str, str, str], list[dict]] = {}
    new_groups: dict[tuple[str, str, str, str], list[dict]] = {}
    for entry in prior:
        old_groups.setdefault(key(entry), []).append(entry)
    for entry in now:
        new_groups.setdefault(key(entry), []).append(entry)
    changes: list[EntityChange] = []
    for entity_key in sorted(set(old_groups) | set(new_groups)):
        old, new = old_groups.get(entity_key, []), new_groups.get(entity_key, [])
        category, mod, entity_id, source_path = entity_key
        if len(old) > 1 or len(new) > 1:
            status = "CONFLICTED"
        elif not old:
            status = "ADDED"
        elif not new:
            status = "REMOVED"
        elif old[0] == new[0]:
            status = "UNCHANGED"
        else:
            status = "CHANGED"
        changes.append(EntityChange(category, mod, entity_id, source_path, status,
                                    old[0].get("source_hash") if len(old) == 1 else None,
                                    new[0].get("source_hash") if len(new) == 1 else None))
    impacts = _direct_impacts(tuple(changes), current, knowledge_packs)
    warnings = tuple(
        [f"Ambiguous canonical entity key: {change.category}:{change.source_mod}:{change.entity_id}:{change.source_path}" for change in changes if change.status == "CONFLICTED"]
        + [f"Removed {change.category}:{change.source_mod}:{change.entity_id}:{change.source_path} has no current reverse-reference evidence; dependent stale results require conservative review." for change in changes if change.status == "REMOVED"]
    )
    return ChangeImpactReport("change-impact-0.1", tuple(changes), impacts, warnings)


def _direct_impacts(changes: tuple[EntityChange, ...], scan: ScanResult, knowledge_packs: tuple[KnowledgePack, ...]) -> tuple[ImpactTarget, ...]:
    targets: dict[tuple[str, str, str], set[str]] = {}
    def add(kind: str, target_id: str, because: str, certainty: str = "EXACT") -> None:
        targets.setdefault((kind, target_id, certainty), set()).add(because)
    changed = [change for change in changes if change.status != "UNCHANGED"]
    # Reverse-index which variants reference each weapon/hullmod/fighter/hull
    # id, built once up front instead of re-scanning every variant per
    # changed entity. Measured on the real 148-mod install (~14k entities,
    # ~6.6k variants): the old per-change `[v for v in scan.variants if ...]`
    # scans made this function O(changed_entities x variants) -- 6.98s of a
    # cold scan's real 8.5s total, ~17.9M `dict.values()` calls alone from
    # the weapons branch. This makes it O(variants x mounts + changed_entities).
    # A variant referencing the same weapon/hullmod/fighter id more than once
    # (e.g. two mounts with the same weapon) may be appended more than once
    # here; `add()` below is a set-union per (kind, target_id, certainty), so
    # duplicate entries are idempotent and do not change the result -- same
    # as the original `in variant.weapons_by_mount.values()` membership test,
    # which also collapsed duplicates to a single inclusion.
    categories_present = {change.category for change in changed}
    weapon_to_variants: dict[str, list] = {}
    hullmod_to_variants: dict[str, list] = {}
    fighter_to_variants: dict[str, list] = {}
    hull_to_variants: dict[str, list] = {}
    if categories_present & {"weapons", "hullmods", "fighters", "hulls"}:
        need_weapons = "weapons" in categories_present
        need_hullmods = "hullmods" in categories_present
        need_fighters = "fighters" in categories_present
        need_hulls = "hulls" in categories_present
        for variant in scan.variants:
            if need_weapons:
                for weapon_id in variant.weapons_by_mount.values():
                    weapon_to_variants.setdefault(weapon_id, []).append(variant)
            if need_hullmods:
                for hullmod_id in variant.hullmods:
                    hullmod_to_variants.setdefault(hullmod_id, []).append(variant)
            if need_fighters:
                for fighter_id in variant.fighter_wings:
                    fighter_to_variants.setdefault(fighter_id, []).append(variant)
            if need_hulls and variant.hull_id:
                hull_to_variants.setdefault(variant.hull_id, []).append(variant)
    for change in changed:
        token = f"{change.status}:{change.category}:{change.source_mod}:{change.entity_id}:{change.source_path}"
        if change.category == "weapons":
            add("weapon_profile", change.entity_id, token)
            variants = weapon_to_variants.get(change.entity_id, [])
        elif change.category == "hullmods":
            variants = hullmod_to_variants.get(change.entity_id, [])
        elif change.category == "fighters":
            variants = fighter_to_variants.get(change.entity_id, [])
        elif change.category == "hulls":
            add("mechanical_profile", change.entity_id, token); add("build_archetype_profile", change.entity_id, token)
            variants = hull_to_variants.get(change.entity_id, [])
        elif change.category == "factions":
            add("faction_capability_profile", change.entity_id, token); add("gap_recommendations", change.entity_id, token)
            continue
        else:
            variants = []
        pack_kind = {"factions": "faction", "hulls": "hull", "weapons": "weapon", "hullmods": "hullmod", "fighters": "fighter"}.get(change.category)
        if pack_kind:
            for pack in knowledge_packs:
                if f"{pack_kind}:{change.entity_id}" in pack.manifest.source_hashes:
                    add("knowledge_pack_freshness", str(pack.path), token)
        if change.status == "REMOVED":
            add("scan_analysis_review", f"{change.category}:{change.source_mod}:{change.entity_id}:{change.source_path}", token, "CONSERVATIVE")
        for variant in variants:
            add("variant_analysis", variant.id, token)
            if variant.hull_id:
                add("mechanical_profile", variant.hull_id, token); add("build_archetype_profile", variant.hull_id, token)
                for faction in scan.factions:
                    if variant.hull_id in faction.known_hulls:
                        add("faction_capability_profile", faction.id, token); add("gap_recommendations", faction.id, token)
    return tuple(ImpactTarget(kind, target_id, certainty, tuple(sorted(reasons))) for (kind, target_id, certainty), reasons in sorted(targets.items()))
