"""Gap Recommendation Engine: native, retrofit, and acquisition legs.

See GAP_RECOMMENDATION_ENGINE.md (project-authored, root of the repo) for
the full target design. Native search (section 6) was the only leg
implementable at first, since retrofit/acquisition search structurally
depended on the Equipment Access / Adaptive Autofit and Refit Assistant
phases (root ROADMAP.md phases 8 and 9) -- neither existed yet. Both now
do, so sections 5 and 7 are implemented below too.

Retrofit search (section 5) is NOT "make a structurally weak hull strong
at this role" -- `classify_hull`'s capability axes are purely structural
(mount composition, fighter-bay presence); no refit can add a hull LARGE
mounts it doesn't have. What it actually searches for, per
FACTION_KNOWLEDGE_PACKS.md section 14 ("search native retrofit
solutions"): among the SAME structurally-capable native hulls the native
leg already finds, does that hull's real, currently-fitted variant
actually realize that structural potential, or would a genuine Refit
Assistant pass (`generation/refit.py::improve_quality`, `IMPROVE_ROLE_MATCH`)
meaningfully close a loadout-quality gap on top of it? This is honest,
bounded v1 work: it reuses the native leg's own ranked candidate pool and
the Refit Assistant's own real quality delta, never inventing a new
inference mechanism.

Acquisition search (section 7) ranks non-native hulls (COMMON/FOREIGN/
UNALIGNED per `analysis/equipment_affinity.py`, extended here to hulls)
by `capability_score * affinity_preference_<tier>` -- the same
`baseline_0.2` preference table adaptive substitution scoring already
uses, directly implementing FACTION_KNOWLEDGE_PACKS.md section 9's
"foreign acquisitions normally need a clear capability advantage" without
inventing a new doctrine-strictness mechanism (section 9's LOOSE/BALANCED/
STRICT modes remain unimplemented -- that's a real, separate future step,
not silently approximated here).
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, replace as dataclass_replace, field
from typing import Any

from starsector_variant_generator.analysis.classification import classify_hull
from starsector_variant_generator.analysis.equipment_affinity import classify_equipment_affinity
from starsector_variant_generator.analysis.faction_capability import FactionCapabilityProfile, analyze_faction_capability
from starsector_variant_generator.analysis.mechanical_archetypes import infer_mechanical_archetypes
from starsector_variant_generator.analysis.build_archetypes import BuildArchetypeProfile, infer_build_archetypes, profile_id_for_build
from starsector_variant_generator.core.heuristics import get_heuristic_set
from starsector_variant_generator.core.knowledge_packs import (
    ResolvedKnowledgePack, build_archetype_preference, capability_gap_guidance,
    officer_guidance, progression_guidance_confidence, progression_hull_ids, retrofit_template_ids,
)
from starsector_variant_generator.core.models import Faction, Variant
from starsector_variant_generator.core.registry import Registry
from starsector_variant_generator.core.evidence import EvidenceClass
from starsector_variant_generator.core.result_cache import AnalysisContextFingerprint, CacheReadiness
from starsector_variant_generator.generation.refit import improve_quality


@dataclass(frozen=True)
class CapabilityGap:
    role: str
    tier: str  # "WEAK" or "GAP" -- see GAP_RECOMMENDATION_ENGINE.md section 4
    faction_existing_coverage: float
    evidence_confidence: float
    guidance_notes: tuple[str, ...] = ()
    guidance_confidence: float | None = None
    capability_dimension: str | None = None
    vector_score: float | None = None
    vector_confidence: float | None = None
    evidence_class: EvidenceClass = EvidenceClass.INFERRED_MECHANICS


@dataclass(frozen=True)
class RecommendationConstraints:
    """Lightweight policy filters; never legality or capability inference."""

    allow_foreign_hulls: bool = True
    include_experimental_builds: bool = True
    campaign_stage: str | None = None  # user-selected pack guidance; never inferred from a save


@dataclass(frozen=True)
class NativeRecommendation:
    role: str
    hull_id: str
    capability_score: float
    rank: int
    confidence: float = 1.0  # resolved-faction-hull evidence only; no scripted-mechanic inference
    archetype_scores: dict[str, float] = field(default_factory=dict)
    archetype_evidence: dict[str, tuple[str, ...]] = field(default_factory=dict)
    diversity_reason: str | None = None
    build_archetype_id: str | None = None
    build_archetype_label: str | None = None
    build_compatibility: float | None = None
    build_confidence: float | None = None
    build_maturity: str | None = None
    recommendation_score: float | None = None
    incremental_capability_gain: float = 0.0
    evidence_class: EvidenceClass = EvidenceClass.INFERRED_MECHANICS


@dataclass(frozen=True)
class GapRecommendationResult:
    faction_id: str
    gaps: tuple[CapabilityGap, ...]
    native_recommendations: dict[str, tuple[NativeRecommendation, ...]]
    unaddressed_gaps: tuple[str, ...]  # no NATIVE solution for this gap -- retrofit/acquisition may still exist
    retrofit_recommendations: dict[str, tuple["RetrofitRecommendation", ...]] = field(default_factory=dict)
    acquisition_recommendations: dict[str, tuple["AcquisitionRecommendation", ...]] = field(default_factory=dict)
    fully_unaddressed_gaps: tuple[str, ...] = ()  # no solution across ALL THREE legs -- GAP_RECOMMENDATION_ENGINE.md section 15
    officer_guidance: tuple[dict[str, object], ...] = ()  # advisory pack data, never a score input


def _evidence_confidence(profile: FactionCapabilityProfile) -> float:
    total = profile.known_hulls_examined + len(profile.unresolved_known_hull_ids)
    return (profile.known_hulls_examined / total) if total else 0.0


def _recommendation_confidence(gap: CapabilityGap, build: BuildArchetypeProfile | None = None, extra: float = 1.0) -> float:
    """Conservative confidence propagation for ranking evidence.

    The score and confidence remain separate.  A mechanically viable build
    with incomplete scanned inputs can rank well, but cannot present itself
    as fully certain.
    """
    factors = [gap.evidence_confidence, extra]
    if gap.vector_confidence is not None:
        factors.append(gap.vector_confidence)
    if build is not None:
        factors.append(build.confidence)
    return round(min(factors), 3)


def detect_capability_gaps(
    profile: FactionCapabilityProfile,
    heuristic_set: str = "baseline_0.2",
    knowledge_pack: ResolvedKnowledgePack | None = None,
) -> tuple[CapabilityGap, ...]:
    """Classify each of `classify_hull`'s 5 real capability axes into a tier.

    Only WEAK and GAP tiers are returned -- STRONG/ADEQUATE axes are not
    "meaningful" gaps per GAP_RECOMMENDATION_ENGINE.md section 4.
    Thresholds are named, versioned heuristics (Agent.md's rule), not
    literal constants here.
    """
    heuristics = get_heuristic_set(heuristic_set).values
    weak_threshold = heuristics["gap_weak_threshold"]
    adequate_threshold = heuristics["gap_adequate_threshold"]
    vector_enabled = "weight_pd_coverage" in heuristics
    gaps = []
    role_dimension = {
        "LINE_ARTILLERY": "LONG_RANGE_PRESSURE", "LINE_BRAWLER": "SUSTAINED_PRESSURE",
        "MISSILE_SUPPORT": "MISSILE_PROJECTION", "CARRIER": "CARRIER_PROJECTION",
        "BATTLE_CARRIER": "CARRIER_PROJECTION",
    }
    for capability in profile.role_capabilities:
        dimension = role_dimension.get(capability.role)
        # CapabilityVector was introduced after the legacy role-only sets.
        # Do not silently alter their reproducible recommendations or
        # confidence semantics; baseline_0.5+ opts into this richer evidence.
        vector_evidence = profile.capability_vector.get(dimension) if vector_enabled and dimension else None
        vector_score = vector_evidence.score if vector_evidence and vector_evidence.score is not None else None
        coverage = max(capability.best_score, vector_score or 0.0)
        confidence = min(_evidence_confidence(profile), vector_evidence.confidence) if vector_evidence else _evidence_confidence(profile)
        if coverage >= adequate_threshold:
            continue
        tier = "WEAK" if coverage >= weak_threshold else "GAP"
        guidance = capability_gap_guidance(knowledge_pack, profile.faction_id, capability.role)
        gaps.append(CapabilityGap(
            capability.role, tier, coverage, confidence,
            tuple(note for note, _ in guidance),
            min((guidance_confidence for _, guidance_confidence in guidance), default=None),
            dimension if vector_enabled else None, vector_score, vector_evidence.confidence if vector_evidence else None,
        ))
    return tuple(sorted(gaps, key=lambda gap: gap.role))


def _resolved_known_hulls(faction: Faction, registry: Registry) -> list:
    return [registry.hulls.by_id[hull_id] for hull_id in faction.known_hulls if hull_id in registry.hulls.by_id]


def _rank_candidates_for_role(role: str, resolved_hulls: list) -> list[tuple[float, str]]:
    """Every resolved known hull's real score for `role`, positive-only, ranked.

    Full ranking, not truncated to `gap_recommendation_count` -- shared by
    `recommend_native_solutions` (which truncates) and
    `explain_native_candidate` (which needs a hull's true rank even when
    it falls outside the top N actually recommended).
    """
    candidates = [(classify_hull(hull).role_compatibility.get(role, 0.0), hull.id) for hull in resolved_hulls]
    candidates = [(score, hull_id) for score, hull_id in candidates if score > 0.0]
    candidates.sort(key=lambda item: (-item[0], item[1]))
    return candidates


def _diverse_hull_shortlist(ranked: list[tuple[float, str]], registry: Registry, count: int, heuristic_set: str) -> list[tuple[float, str, str]]:
    """Score-first, deterministic diversity selection for one recommendation leg.

    Only baseline_0.3 enables this behavior. A candidate outside the best
    score's configured tolerance is never selected ahead of a better option
    merely to improve variety.
    """
    if heuristic_set != "baseline_0.3":
        return [(score, hull_id, "Selected by recommendation score.") for score, hull_id in ranked[:count]]
    values = get_heuristic_set(heuristic_set).values
    if not ranked:
        return []
    best_score = ranked[0][0]
    tolerance = values["recommendation_diversity_material_score_tolerance"]
    selected: list[tuple[float, str, str]] = [(ranked[0][0], ranked[0][1], "Highest recommendation score.")]
    remaining = ranked[1:]
    profiles = {hull_id: infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry) for _, hull_id in ranked}
    role_sets = {
        hull_id: {role for role, score in classify_hull(registry.hulls.by_id[hull_id]).role_compatibility.items() if score >= values["recommendation_diversity_min_archetype_compatibility"]}
        for _, hull_id in ranked
    }
    archetype_sets = {
        hull_id: {name for name, score in profile.compatibility_scores.items() if score >= values["recommendation_diversity_min_archetype_compatibility"]}
        for hull_id, profile in profiles.items()
    }
    while remaining and len(selected) < count:
        competitive = [item for item in remaining if item[0] >= best_score * (1.0 - tolerance)]
        pool = competitive or remaining
        selected_ids = [hull_id for _, hull_id, _ in selected]
        def diversity_key(item: tuple[float, str]) -> tuple[float, float, str]:
            similarities = []
            for selected_id in selected_ids:
                role_similarity = _jaccard(role_sets[item[1]], role_sets[selected_id])
                archetype_similarity = _jaccard(archetype_sets[item[1]], archetype_sets[selected_id])
                similarities.append(
                    values["recommendation_diversity_role_difference_weight"] * role_similarity
                    + values["recommendation_diversity_archetype_difference_weight"] * archetype_similarity
                )
            similarity = max(similarities, default=0.0)
            adjusted_score = item[0] - values["recommendation_diversity_similarity_penalty"] * similarity * best_score
            return (adjusted_score, 1.0 - similarity, item[1])
        choice = max(pool, key=diversity_key)
        reason = "Selected after score ranking for distinct functional-role and inferred mechanical-archetype evidence within the material score tolerance." if choice in competitive else "Selected by recommendation score; no remaining score-competitive alternative was available for diversity."
        selected.append((choice[0], choice[1], reason))
        remaining.remove(choice)
    return selected


def _jaccard(left: set[str], right: set[str]) -> float:
    return len(left & right) / len(left | right) if left or right else 1.0


def recommend_native_solutions(
    faction: Faction,
    registry: Registry,
    heuristic_set: str = "baseline_0.2",
    knowledge_pack: ResolvedKnowledgePack | None = None,
    constraints: RecommendationConstraints | None = None,
) -> GapRecommendationResult:
    """Rank the faction's own real known_hulls against each detected gap.

    Ranks by raw `capability_score`, not a gain over `faction_existing_coverage`:
    that coverage figure is itself defined as the *best score among this
    same native hull set* (`analyze_faction_capability`), so a
    "capability_gain vs. existing coverage" filter would be tautologically
    zero for every native hull -- none can ever beat a baseline derived
    from its own set's maximum. That comparison is only meaningful for
    retrofit/acquisition candidates, which sit outside the native pool
    (see GAP_RECOMMENDATION_ENGINE.md sections 5-7, not yet implemented).
    A gap with no known hull scoring above zero for that role at all is
    recorded in `unaddressed_gaps` rather than padded with a zero-score
    recommendation.
    """
    constraints = constraints or RecommendationConstraints()
    profile = analyze_faction_capability(faction, registry, heuristic_set)
    gaps = detect_capability_gaps(profile, heuristic_set, knowledge_pack)
    heuristics = get_heuristic_set(heuristic_set).values
    max_recommendations = int(heuristics["gap_recommendation_count"])

    resolved_hulls = _resolved_known_hulls(faction, registry)

    native_recommendations: dict[str, tuple[NativeRecommendation, ...]] = {}
    unaddressed: list[str] = []
    for gap in gaps:
        if "build_archetype_viable_min_compatibility" in heuristics:
            build_top = _diverse_build_shortlist(
                _rank_build_candidates_for_role(
                    gap.role, resolved_hulls, registry, heuristic_set, knowledge_pack,
                    faction.id, constraints.include_experimental_builds, constraints.campaign_stage,
                ),
                max_recommendations, heuristic_set, registry,
            )
            top = [(score, hull_id, reason, build) for score, hull_id, build, reason in build_top]
        else:
            top = [(score, hull_id, reason, _build_for_gap(hull_id, gap.role, registry, heuristic_set))
                   for score, hull_id, reason in _diverse_hull_shortlist(_rank_candidates_for_role(gap.role, resolved_hulls), registry, max_recommendations, heuristic_set)]
        if not top:
            unaddressed.append(gap.role)
            continue
        native_recommendations[gap.role] = tuple(
            # `capability_score` is always this hull's own raw, structural
            # `classify_hull(...).role_compatibility[role]` (GAP_RECOMMENDATION_ENGINE.md
            # section 6; matches what RetrofitRecommendation/AcquisitionRecommendation
            # and explain_native_candidate's own independent computation report for
            # the same hull/role), never the Hull+Build composite -- that composite
            # is `score` here (already stored separately as `recommendation_score`).
            # In the non-build-aware branch above `score` already *is* this same raw
            # value, so this is a correctness fix specifically for the build-aware
            # branch, where `score` is `capability * build.compatibility * bias`.
            NativeRecommendation(gap.role, hull_id,
                                 classify_hull(registry.hulls.by_id[hull_id]).role_compatibility.get(gap.role, 0.0),
                                 rank=index + 1, confidence=_recommendation_confidence(gap, build),
                                 archetype_scores=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).compatibility_scores,
                                 archetype_evidence=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).evidence_by_archetype,
                                 diversity_reason=reason,
                                 build_archetype_id=build.build_id if build else None,
                                 build_archetype_label=build.role if build else None,
                                 build_compatibility=build.compatibility if build else None,
                                 build_confidence=build.confidence if build else None,
                                 build_maturity=build.maturity if build else None,
                                 recommendation_score=score,
                                 incremental_capability_gain=0.0)
            for index, (score, hull_id, reason, build) in enumerate(top)
        )
    return GapRecommendationResult(profile.faction_id, gaps, native_recommendations, tuple(unaddressed))


# The 5 real `classify_hull` capability axes onto the closest matching
# `profiles/catalog.py` quality profile -- needed because retrofit search
# has to hand a real, existing profile_id to `improve_quality`/
# `score_candidate`, and those two vocabularies were never unified.
# BATTLE_CARRIER (a hybrid carrier/artillery axis) has no dedicated
# profile of its own; CARRIER_SUPPORT is the closest real intent, same as
# CARRIER's own mapping. Explicit and documented, not inferred silently.
_ROLE_TO_PROFILE = {
    "LINE_ARTILLERY": "LINE_ARTILLERY",
    "LINE_BRAWLER": "LINE_BRAWLER",
    "MISSILE_SUPPORT": "MISSILE_SUPPORT",
    "CARRIER": "CARRIER_SUPPORT",
    "BATTLE_CARRIER": "CARRIER_SUPPORT",
}

_ROLE_TO_BUILD_IDS = {
    "LINE_BRAWLER": ("TANK", "LINE_ANCHOR", "FINISHER"),
    "LINE_ARTILLERY": ("ARTILLERY",),
    "MISSILE_SUPPORT": ("MISSILE_SUPPORT", "PD_ESCORT"),
    "CARRIER": ("CARRIER_SUPPORT", "BATTLECARRIER"),
    "BATTLE_CARRIER": ("BATTLECARRIER", "CARRIER_SUPPORT"),
}


def _build_for_gap(hull_id: str, role: str, registry: Registry, heuristic_set: str) -> BuildArchetypeProfile | None:
    if "build_archetype_viable_min_compatibility" not in get_heuristic_set(heuristic_set).values:
        return None
    hull = registry.hulls.by_id[hull_id]
    preferred = set(_ROLE_TO_BUILD_IDS.get(role, ()))
    builds = infer_build_archetypes(hull, registry, heuristic_set)
    candidates = [build for build in builds if build.build_id in preferred] or list(builds)
    return candidates[0] if candidates else None


def _rank_build_candidates_for_role(
    role: str, resolved_hulls: list, registry: Registry, heuristic_set: str,
    knowledge_pack: ResolvedKnowledgePack | None = None, faction_id: str | None = None,
    include_experimental_builds: bool = True, campaign_stage: str | None = None,
) -> list[tuple[float, str, BuildArchetypeProfile]]:
    """Rank independently viable ``Hull + BuildArchetype`` solutions."""
    ranked: list[tuple[float, str, BuildArchetypeProfile]] = []
    preferred = set(_ROLE_TO_BUILD_IDS.get(role, ()))
    values = get_heuristic_set(heuristic_set).values
    progression_ids = set(progression_hull_ids(knowledge_pack, faction_id or "", campaign_stage))
    progression_confidence = progression_guidance_confidence(knowledge_pack, faction_id or "", campaign_stage) or 0.0
    for hull in resolved_hulls:
        capability = classify_hull(hull).role_compatibility.get(role, 0.0)
        if capability <= 0.0:
            continue
        for build in infer_build_archetypes(hull, registry, heuristic_set):
            if preferred and build.build_id not in preferred:
                continue
            if not include_experimental_builds and build.maturity == "EXPERIMENTAL":
                continue
            # The role capability remains the primary signal; build
            # compatibility makes two fits on the same hull independently
            # rankable rather than collapsing them to one hull identity.
            preference = build_archetype_preference(knowledge_pack, faction_id or "", build.build_id)
            bias = 1.0
            if preference is not None:
                preferred_value, guidance_confidence = preference
                bias += (preferred_value - 0.5) * values["knowledge_build_archetype_preference_weight"] * guidance_confidence
            # Stage guidance is only a small, freshness-adjusted advisory
            # tie-breaker. It cannot introduce a hull, build, or role that
            # the mechanical inference did not already admit.
            if hull.id in progression_ids and "knowledge_progression_preference_weight" in values:
                bias += values["knowledge_progression_preference_weight"] * progression_confidence
            ranked.append((round(capability * build.compatibility * bias, 6), hull.id, build))
    return sorted(ranked, key=lambda item: (-item[0], item[1], item[2].build_id))


def _build_similarity(
    candidate: tuple[float, str, BuildArchetypeProfile],
    selected: tuple[float, str, BuildArchetypeProfile],
    registry: Registry | None,
) -> float:
    """Deterministic within-/cross-hull build similarity from stored inference.

    This is deliberately posture- and evidence-based, rather than a
    hand-authored hull-family label.  A different build id is not by itself
    proof of useful variety.
    """
    _, candidate_hull_id, candidate_build = candidate
    _, selected_hull_id, selected_build = selected
    posture_matches = sum((
        candidate_build.tactical_style == selected_build.tactical_style,
        candidate_build.target_range == selected_build.target_range,
        candidate_build.flux_posture == selected_build.flux_posture,
        candidate_build.survivability_posture == selected_build.survivability_posture,
    )) / 4.0
    priority_similarity = _jaccard(set(candidate_build.equipment_priorities), set(selected_build.equipment_priorities))
    mechanical_similarity = 0.0
    if registry is not None:
        candidate_mechanical = infer_mechanical_archetypes(registry.hulls.by_id[candidate_hull_id], registry)
        selected_mechanical = infer_mechanical_archetypes(registry.hulls.by_id[selected_hull_id], registry)
        candidate_roles = {name for name, score in candidate_mechanical.compatibility_scores.items() if score >= 0.20}
        selected_roles = {name for name, score in selected_mechanical.compatibility_scores.items() if score >= 0.20}
        mechanical_similarity = _jaccard(candidate_roles, selected_roles)
    return round(.40 * posture_matches + .30 * priority_similarity + .30 * mechanical_similarity, 6)


def _diverse_build_shortlist(ranked: list[tuple[float, str, BuildArchetypeProfile]], count: int, heuristic_set: str, registry: Registry | None = None) -> list[tuple[float, str, BuildArchetypeProfile, str]]:
    if not ranked:
        return []
    values = get_heuristic_set(heuristic_set).values
    selected = [(ranked[0][0], ranked[0][1], ranked[0][2], "Highest Hull + BuildArchetype recommendation score.")]
    remaining = ranked[1:]
    while remaining and len(selected) < count:
        best_score = ranked[0][0]
        competitive = [item for item in remaining if item[0] >= best_score * (1.0 - values["recommendation_diversity_material_score_tolerance"])]
        pool = competitive or remaining
        similarities = {
            (item[1], item[2].build_id): max((_build_similarity(item, prior[:3], registry) for prior in selected), default=0.0)
            for item in pool
        }
        choice = max(pool, key=lambda item: (
            1.0 - similarities[(item[1], item[2].build_id)], item[0], item[1], item[2].build_id,
        ))
        similarity = similarities[(choice[1], choice[2].build_id)]
        reason = ("Selected after score ranking as a materially competitive mechanically and tactically distinct Hull + BuildArchetype solution "
                  f"(similarity={similarity:.3f})." if choice in competitive else
                  "Selected by Hull + BuildArchetype recommendation score; no remaining score-competitive alternative was available for diversity.")
        selected.append((choice[0], choice[1], choice[2], reason))
        remaining.remove(choice)
    return selected


@dataclass(frozen=True)
class RetrofitRecommendation:
    role: str
    hull_id: str
    variant_id: str  # the real, existing variant a genuine Refit Assistant pass was run against
    capability_score: float  # structural (classify_hull); unchanged by refit, same figure the native leg reports
    role_match_before: float  # this real variant's current role_match component (score_candidate)
    role_match_after: float  # role_match after generation/refit.py::improve_quality's IMPROVE_ROLE_MATCH search
    quality_gain: float
    changes: int
    change_cost: float
    rank: int
    confidence: float = 1.0  # legal, evaluated real-variant evidence; source coverage is folded in by caller
    archetype_scores: dict[str, float] = field(default_factory=dict)
    archetype_evidence: dict[str, tuple[str, ...]] = field(default_factory=dict)
    diversity_reason: str | None = None
    build_archetype_id: str | None = None
    build_archetype_label: str | None = None
    build_compatibility: float | None = None
    build_confidence: float | None = None
    build_maturity: str | None = None
    recommendation_score: float | None = None
    incremental_capability_gain: float = 0.0
    retrofit_disruption: float = 0.0
    role_distortion: float = 0.0
    knowledge_template_ids: tuple[str, ...] = ()
    knowledge_guidance_confidence: float | None = None
    evidence_class: EvidenceClass = EvidenceClass.INFERRED_MECHANICS


def _variants_for_hull(hull_id: str, registry: Registry) -> list[Variant]:
    return sorted((variant for variant in registry.variants.by_id.values() if variant.hull_id == hull_id), key=lambda variant: variant.id)


def _best_retrofit_for_hull(hull_id: str, profile_id: str, registry: Registry, faction: Faction, heuristic_set: str, min_gain: float):
    """The most-improvable of this hull's real, existing variants, if any
    genuinely improves by at least `min_gain` under `IMPROVE_ROLE_MATCH`.

    Examines every real variant for this hull (not just one) since which
    named variant is worth retrofitting is itself real information --
    picks the one with the largest real quality_gain, not the first found.
    Returns None if this hull has no real variant, none are legal/
    scoreable starting points, or none genuinely improve -- never
    fabricates a retrofit opportunity that isn't real.
    """
    best = None  # (gain, variant, QualityRefitResult)
    for variant in _variants_for_hull(hull_id, registry):
        result = improve_quality(variant, registry, "IMPROVE_ROLE_MATCH", profile_id, heuristic_set, faction=faction)
        if result.before_score is None or result.after_score is None:
            continue
        gain = result.after_score - result.before_score
        if gain < min_gain:
            continue
        if best is None or gain > best[0]:
            best = (gain, variant, result)
    return best


def recommend_retrofit_solutions(
    faction: Faction, registry: Registry, gaps: tuple[CapabilityGap, ...],
    heuristic_set: str = "baseline_0.2", constraints: RecommendationConstraints | None = None,
    knowledge_pack: ResolvedKnowledgePack | None = None,
) -> dict[str, tuple[RetrofitRecommendation, ...]]:
    """GAP_RECOMMENDATION_ENGINE.md section 5 / FACTION_KNOWLEDGE_PACKS.md
    section 14's "search native retrofit solutions": among the same
    structurally-capable native hulls `recommend_native_solutions` already
    ranks (bounded to the same top `gap_recommendation_count`, since those
    are the hulls actually being shown), find the real existing variant
    whose current loadout most under-realizes that structural potential,
    and report the genuine quality gain a real Refit Assistant pass
    achieves. A hull with no real variant, or none that improve by at
    least `refit_min_quality_gain`, is simply absent from the result for
    that gap -- never padded with a fabricated recommendation.
    """
    heuristics = get_heuristic_set(heuristic_set).values
    max_recommendations = int(heuristics["gap_recommendation_count"])
    min_gain = heuristics["refit_min_quality_gain"]
    resolved_hulls = _resolved_known_hulls(faction, registry)
    constraints = constraints or RecommendationConstraints()

    retrofits: dict[str, tuple[RetrofitRecommendation, ...]] = {}
    for gap in gaps:
        if "build_archetype_viable_min_compatibility" in heuristics:
            found_builds: list[tuple[float, str, BuildArchetypeProfile, Variant, object, float]] = []
            for structural_score, hull_id, build in _rank_build_candidates_for_role(gap.role, resolved_hulls, registry, heuristic_set, include_experimental_builds=constraints.include_experimental_builds):
                best = _best_retrofit_for_hull(hull_id, profile_id_for_build(build.build_id), registry, faction, heuristic_set, min_gain)
                if best is None:
                    continue
                gain, variant, result = best
                reference_cost = heuristics.get("retrofit_disruption_reference_cost")
                disruption = min(1.0, result.total_change_cost / reference_cost) if reference_cost else 0.0
                score = result.after_score * build.compatibility * (1.0 - heuristics.get("retrofit_disruption_penalty_weight", 0.0) * disruption)
                found_builds.append((round(score, 6), hull_id, build, variant, result, gain))
            found_builds.sort(key=lambda item: (-item[0], item[1], item[2].build_id, item[3].id))
            selected_builds = _diverse_build_shortlist([(score, hull_id, build) for score, hull_id, build, _, _, _ in found_builds], max_recommendations, heuristic_set, registry)
            by_build = {(hull_id, build.build_id): (variant, result, gain) for _, hull_id, build, variant, result, gain in found_builds}
            retrofits[gap.role] = tuple(
                RetrofitRecommendation(
                    gap.role, hull_id, variant.id,
                    classify_hull(registry.hulls.by_id[hull_id]).role_compatibility.get(gap.role, 0.0),
                    result.before_score, result.after_score, gain, len(result.changes), result.total_change_cost, index + 1,
                    confidence=_recommendation_confidence(gap, build), archetype_scores=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).compatibility_scores,
                    archetype_evidence=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).evidence_by_archetype,
                    diversity_reason=reason, build_archetype_id=build.build_id, build_archetype_label=build.role,
                    build_compatibility=build.compatibility, build_confidence=build.confidence, build_maturity=build.maturity,
                    recommendation_score=recommendation_score,
                    incremental_capability_gain=0.0,
                    retrofit_disruption=(min(1.0, result.total_change_cost / heuristics["retrofit_disruption_reference_cost"]) if heuristics.get("retrofit_disruption_reference_cost") else 0.0),
                    role_distortion=round(1.0 - build.compatibility, 6),
                    knowledge_template_ids=tuple(template_id for template_id, _ in templates),
                    knowledge_guidance_confidence=min((confidence for _, confidence in templates), default=None),
                )
                for index, (recommendation_score, hull_id, build, reason) in enumerate(selected_builds)
                for variant, result, gain in (by_build[(hull_id, build.build_id)],)
                for templates in (retrofit_template_ids(knowledge_pack, faction.id, hull_id, gap.role),)
            )
            continue
        profile_id = _ROLE_TO_PROFILE.get(gap.role)
        if profile_id is None:
            continue
        ranked = _rank_candidates_for_role(gap.role, resolved_hulls)[:max_recommendations]
        found: list[tuple[float, str, Variant, object, float]] = []  # (capability_score, hull_id, variant, result, gain)
        for capability_score, hull_id in ranked:
            best = _best_retrofit_for_hull(hull_id, profile_id, registry, faction, heuristic_set, min_gain)
            if best is None:
                continue
            gain, variant, result = best
            found.append((capability_score, hull_id, variant, result, gain))
        found.sort(key=lambda item: (-item[3].after_score, item[1], item[2].id))
        by_hull_id = {hull_id: (capability_score, variant, result, gain) for capability_score, hull_id, variant, result, gain in found}
        selected = _diverse_hull_shortlist(
            [(result.after_score, hull_id) for _, hull_id, _, result, _ in found],
            registry, max_recommendations, heuristic_set,
        )
        retrofits[gap.role] = tuple(
            RetrofitRecommendation(
                gap.role, hull_id, variant.id, capability_score,
                result.before_score, result.after_score, gain, len(result.changes), result.total_change_cost, rank=index + 1,
                confidence=gap.evidence_confidence,
                archetype_scores=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).compatibility_scores,
                archetype_evidence=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).evidence_by_archetype,
                diversity_reason=reason,
                build_archetype_id=build.build_id if build else None,
                build_archetype_label=build.role if build else None,
                build_compatibility=build.compatibility if build else None,
                build_confidence=build.confidence if build else None,
                build_maturity=build.maturity if build else None,
                recommendation_score=result.after_score,
                incremental_capability_gain=0.0,
                retrofit_disruption=0.0,
                role_distortion=0.0,
                knowledge_template_ids=tuple(template_id for template_id, _ in templates),
                knowledge_guidance_confidence=min((confidence for _, confidence in templates), default=None),
            )
            for index, (_, hull_id, reason) in enumerate(selected)
            for capability_score, variant, result, gain in (by_hull_id[hull_id],)
            for build in (_build_for_gap(hull_id, gap.role, registry, heuristic_set),)
            for templates in (retrofit_template_ids(knowledge_pack, faction.id, hull_id, gap.role),)
        )
    return retrofits


@dataclass(frozen=True)
class AcquisitionRecommendation:
    role: str
    hull_id: str
    capability_score: float
    affinity: str  # "COMMON" | "FOREIGN" | "UNALIGNED" -- never NATIVE, that's the native leg's job
    owning_faction_ids: tuple[str, ...]
    preference_weight: float  # affinity_preference_<tier>, baseline_0.2 -- the same table adaptive substitution uses
    rank: int
    confidence: float = 1.0  # source coverage plus optional knowledge-pack evidence
    archetype_scores: dict[str, float] = field(default_factory=dict)
    archetype_evidence: dict[str, tuple[str, ...]] = field(default_factory=dict)
    diversity_reason: str | None = None
    build_archetype_id: str | None = None
    build_archetype_label: str | None = None
    build_compatibility: float | None = None
    build_confidence: float | None = None
    build_maturity: str | None = None
    recommendation_score: float | None = None
    incremental_capability_gain: float = 0.0
    evidence_class: EvidenceClass = EvidenceClass.INFERRED_MECHANICS


def recommend_acquisition_solutions(
    faction: Faction,
    registry: Registry,
    gaps: tuple[CapabilityGap, ...],
    heuristic_set: str = "baseline_0.2",
    knowledge_pack: ResolvedKnowledgePack | None = None,
    constraints: RecommendationConstraints | None = None,
) -> dict[str, tuple[AcquisitionRecommendation, ...]]:
    """GAP_RECOMMENDATION_ENGINE.md section 7: rank real, indexed hulls this
    faction does NOT already know (COMMON/FOREIGN/UNALIGNED per
    `analysis/equipment_affinity.py`, extended to hulls) by
    `capability_score * affinity_preference_<tier>` -- directly
    implementing FACTION_KNOWLEDGE_PACKS.md section 9's "foreign
    acquisitions normally need a clear capability advantage" using the
    already-registered preference table, not a new doctrine-strictness
    mechanism (LOOSE/BALANCED/STRICT remain unimplemented).

    Single pass over every real indexed hull (not per-gap) since both
    `classify_hull` and hull affinity are gap-independent -- avoids
    redundant classification work across gaps.
    """
    heuristics = get_heuristic_set(heuristic_set).values
    constraints = constraints or RecommendationConstraints()
    max_recommendations = int(heuristics["gap_recommendation_count"])
    native_hull_ids = {hull_id for hull_id in faction.known_hulls if hull_id in registry.hulls.by_id}
    gap_roles = {gap.role for gap in gaps}

    per_role_candidates: dict[str, list[tuple[float, float, float, str, object]]] = {role: [] for role in gap_roles}
    for hull_id, hull in registry.hulls.by_id.items():
        if hull_id in native_hull_ids:
            continue
        role_scores = classify_hull(hull).role_compatibility
        relevant = {role: role_scores.get(role, 0.0) for role in gap_roles if role_scores.get(role, 0.0) > 0.0}
        if not relevant:
            continue
        affinity = classify_equipment_affinity(
            hull_id, "hulls", registry, requesting_faction_id=faction.id,
            knowledge_pack=knowledge_pack,
        )
        if not constraints.allow_foreign_hulls and affinity.affinity == "FOREIGN":
            continue
        weight = heuristics[f"affinity_preference_{affinity.affinity.lower()}"]
        for role, score in relevant.items():
            per_role_candidates[role].append((score * weight, score, weight, hull_id, affinity))

    acquisitions: dict[str, tuple[AcquisitionRecommendation, ...]] = {}
    for gap in gaps:
        candidates = per_role_candidates.get(gap.role, [])
        if "build_archetype_viable_min_compatibility" in heuristics:
            build_candidates: list[tuple[float, float, float, str, object, BuildArchetypeProfile]] = []
            preferred = set(_ROLE_TO_BUILD_IDS.get(gap.role, ()))
            for composite, score, weight, hull_id, affinity in candidates:
                hull = registry.hulls.by_id[hull_id]
                for build in infer_build_archetypes(hull, registry, heuristic_set):
                    if preferred and build.build_id not in preferred:
                        continue
                    if not constraints.include_experimental_builds and build.maturity == "EXPERIMENTAL":
                        continue
                    build_candidates.append((round(composite * build.compatibility, 6), score, weight, hull_id, affinity, build))
            build_candidates.sort(key=lambda item: (-item[0], item[3], item[5].build_id))
            selected_builds = _diverse_build_shortlist([(composite, hull_id, build) for composite, _, _, hull_id, _, build in build_candidates], max_recommendations, heuristic_set, registry)
            by_build = {(hull_id, build.build_id): (score, weight, affinity) for _, score, weight, hull_id, affinity, build in build_candidates}
            acquisitions[gap.role] = tuple(
                AcquisitionRecommendation(
                    gap.role, hull_id, score, affinity.affinity, affinity.owning_faction_ids, weight, index + 1,
                    confidence=_recommendation_confidence(gap, build, affinity.guidance_confidence if affinity.guidance_confidence is not None else 1.0),
                    archetype_scores=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).compatibility_scores,
                    archetype_evidence=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).evidence_by_archetype,
                    diversity_reason=reason, build_archetype_id=build.build_id, build_archetype_label=build.role,
                    build_compatibility=build.compatibility, build_confidence=build.confidence, build_maturity=build.maturity,
                    recommendation_score=recommendation_score,
                    incremental_capability_gain=max(0.0, score - gap.faction_existing_coverage),
                )
                for index, (recommendation_score, hull_id, build, reason) in enumerate(selected_builds)
                for score, weight, affinity in (by_build[(hull_id, build.build_id)],)
            )
            continue
        candidates.sort(key=lambda item: (-item[0], item[3]))
        by_hull_id = {hull_id: (score, weight, affinity) for _, score, weight, hull_id, affinity in candidates}
        top = _diverse_hull_shortlist(
            [(composite, hull_id) for composite, _, _, hull_id, _ in candidates],
            registry, max_recommendations, heuristic_set,
        )
        acquisitions[gap.role] = tuple(
            AcquisitionRecommendation(
                gap.role, hull_id, score, affinity.affinity, affinity.owning_faction_ids,
                weight, rank=index + 1,
                # The faction's resolved-hull coverage is the universal
                # evidence limit.  Pack approval adds no invented certainty:
                # it can only reduce confidence when its freshness/evidence
                # says less than one.
                confidence=gap.evidence_confidence * (affinity.guidance_confidence if affinity.guidance_confidence is not None else 1.0),
                archetype_scores=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).compatibility_scores,
                archetype_evidence=infer_mechanical_archetypes(registry.hulls.by_id[hull_id], registry).evidence_by_archetype,
                diversity_reason=reason,
                build_archetype_id=build.build_id if build else None,
                build_archetype_label=build.role if build else None,
                build_compatibility=build.compatibility if build else None,
                build_confidence=build.confidence if build else None,
                build_maturity=build.maturity if build else None,
                recommendation_score=score * weight,
                incremental_capability_gain=max(0.0, score - gap.faction_existing_coverage),
            )
            for index, (_, hull_id, reason) in enumerate(top)
            for score, weight, affinity in (by_hull_id[hull_id],)
            for build in (_build_for_gap(hull_id, gap.role, registry, heuristic_set),)
        )
    return acquisitions


def recommend_gap_solutions(
    faction: Faction,
    registry: Registry,
    heuristic_set: str = "baseline_0.2",
    knowledge_pack: ResolvedKnowledgePack | None = None,
    constraints: RecommendationConstraints | None = None,
) -> GapRecommendationResult:
    """All 3 implemented legs combined: `recommend_native_solutions`'s
    result, extended with `retrofit_recommendations`/
    `acquisition_recommendations` and a real `fully_unaddressed_gaps`
    (GAP_RECOMMENDATION_ENGINE.md section 15's full-maturity definition:
    a gap with no solution across native, retrofit, AND acquisition --
    not just no native solution, which `unaddressed_gaps` alone still
    means, unchanged, since that is itself real and distinct information
    ("this faction's own hulls can't cover this at all")).
    """
    constraints = constraints or RecommendationConstraints()
    native_result = recommend_native_solutions(faction, registry, heuristic_set, knowledge_pack, constraints)
    retrofit = recommend_retrofit_solutions(faction, registry, native_result.gaps, heuristic_set, constraints, knowledge_pack)
    acquisition = recommend_acquisition_solutions(faction, registry, native_result.gaps, heuristic_set, knowledge_pack, constraints)
    fully_unaddressed = tuple(
        role for role in native_result.unaddressed_gaps
        if not retrofit.get(role) and not acquisition.get(role)
    )
    return dataclass_replace(
        native_result,
        retrofit_recommendations=retrofit,
        acquisition_recommendations=acquisition,
        fully_unaddressed_gaps=fully_unaddressed,
        officer_guidance=officer_guidance(knowledge_pack, faction.id),
    )


# --- Result-cache reuse (core/result_cache.py) --------------------------
#
# `recommend_gap_solutions` is a heavier, multi-step computation than a
# single hull/faction report: its retrofit leg runs a genuine refit-
# improvement search (`generation/refit.py::improve_quality`) per
# candidate hull, and its acquisition leg scores every indexed hull in the
# registry. Repeated calls for the same faction/heuristic_set/knowledge-
# pack/constraints (a GUI user reopening the same faction, or a batch
# evaluation across runs) can safely reuse a prior result -- but only when
# every real input is honestly captured. See `_registry_wide_entity_hashes`
# below for why that surface is the whole registry, not a bounded slice.

# The retrofit leg's adapter-derived defense/mobility/logistics effects
# (`generation/refit.py` -> `starsector_variant_generator.adapters`,
# `analysis/combat_stats.py`, `analysis/mobility_stats.py`) are a fixed,
# hand-authored vanilla table -- never derived from scanned Java source, so
# no per-scan source hash applies to them. Bump this marker if that table's
# effect values or coverage ever change, the same way
# `hullmod_static_analysis.API_EFFECT_REGISTRY_VERSION` versions the
# separate, Java-derived hullmod registry.
GAP_RECOMMENDATION_ADAPTER_VERSION = "vanilla_static_adapters-1"


def _registry_wide_entity_hashes(registry: Registry) -> tuple[str, ...] | None:
    """Every consumed entity's real source hash, or ``None`` if incomplete.

    `recommend_gap_solutions` cannot be narrowed to one hull's or one
    faction's own referenced entities the way
    `output/analysis_reports.py`'s `_hull_profile_fingerprint` /
    `_faction_capability_fingerprint` are: its acquisition leg
    (`recommend_acquisition_solutions`) iterates every indexed hull in
    `registry.hulls.by_id` directly (not just this faction's known hulls),
    its retrofit leg's refit search draws weapon/hullmod substitutes from
    the entire weapon/hullmod registry the same way
    `generation/candidate.py` does, and cross-faction equipment affinity
    (`analysis/equipment_affinity.py`) depends on every other faction's own
    known-hull/known-weapon/known-hullmod sets. A change anywhere in the
    scan can therefore change this result, so the honest dependency
    surface is the whole registry. Any entity missing a source hash fails
    this closed rather than guessing the real surface is narrower.
    """
    hashes: list[str] = []
    for index in (registry.hulls, registry.weapons, registry.hullmods, registry.fighters, registry.variants, registry.factions):
        for entity in index.by_id.values():
            if entity.source_hash is None:
                return None
            hashes.append(entity.source_hash)
    return tuple(sorted(hashes))


def _knowledge_pack_fingerprint(knowledge_pack: ResolvedKnowledgePack | None) -> str:
    """A stable identifier for every resolved-pack field this engine actually
    consumes (build-archetype preference, progression guidance, capability-
    gap guidance, retrofit templates, officer guidance, approved equipment).
    Two packs at the same freshness status can still carry different
    resolved content, so freshness status alone would be unsafe here."""
    if knowledge_pack is None:
        return "NONE"
    payload = {
        "path": str(knowledge_pack.pack.path),
        "pack_version": knowledge_pack.pack.manifest.pack_version,
        "target_faction_id": knowledge_pack.pack.manifest.target_faction_id,
        "example_only": knowledge_pack.pack.example_only,
        "freshness_status": knowledge_pack.freshness.status,
        "freshness_reasons": list(knowledge_pack.freshness.reasons),
        "hull_archetypes": list(knowledge_pack.hull_archetypes),
        "retrofit_templates": list(knowledge_pack.retrofit_templates),
        "approved_equipment": list(knowledge_pack.approved_equipment),
        "unresolved_references": list(knowledge_pack.unresolved_references),
    }
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def gap_recommendation_fingerprint(
    faction: Faction,
    registry: Registry,
    heuristic_set: str,
    knowledge_pack: ResolvedKnowledgePack | None = None,
    constraints: RecommendationConstraints | None = None,
) -> AnalysisContextFingerprint:
    """Declare `recommend_gap_solutions`'s real, complete dependency context.

    `target_faction_id` is folded into `constraints_hash` (not just passed
    as the cache's `target_id`) because `AnalysisResultCache.key` only
    hashes the declared context -- two different factions evaluated against
    an otherwise-identical registry/heuristic_set/pack/constraints would
    otherwise produce the same context hash and collide in the cache's
    single-column primary key. See `analyze_faction_capability`'s own
    fingerprint sibling in `output/analysis_reports.py`, which avoids the
    same collision by hashing the faction entity itself as a dependency.
    """
    constraints = constraints or RecommendationConstraints()
    entity_hashes = _registry_wide_entity_hashes(registry)
    constraints_payload = {
        "target_faction_id": faction.id,
        "target_faction_source_hash": faction.source_hash,
        "allow_foreign_hulls": constraints.allow_foreign_hulls,
        "include_experimental_builds": constraints.include_experimental_builds,
        "campaign_stage": constraints.campaign_stage,
    }
    constraints_hash = hashlib.sha256(
        json.dumps(constraints_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    complete = entity_hashes is not None and faction.source_hash is not None
    return AnalysisContextFingerprint(
        operation="gap_recommendation",
        entity_hashes=entity_hashes if entity_hashes is not None else (),
        heuristic_set=heuristic_set,
        adapter_versions=(GAP_RECOMMENDATION_ADAPTER_VERSION,),
        knowledge_pack_freshness=_knowledge_pack_fingerprint(knowledge_pack),
        constraints_hash=constraints_hash,
        readiness=CacheReadiness.CACHE_SAFE if complete else CacheReadiness.CACHE_UNSAFE_INCOMPLETE_CONTEXT,
    )


def gap_recommendation_result_to_payload(result: GapRecommendationResult) -> dict[str, Any]:
    """JSON-safe serialization for the result cache. `dataclasses.asdict`
    already recursively converts every nested dataclass, and `EvidenceClass`
    (a `StrEnum`) serializes as a plain string, so no further conversion is
    needed on the write path."""
    return asdict(result)


def _restore_archetype_evidence(data: dict[str, Any] | None) -> dict[str, tuple[str, ...]]:
    return {key: tuple(value) for key, value in (data or {}).items()}


def _restore_capability_gap(data: dict[str, Any]) -> CapabilityGap:
    return CapabilityGap(
        role=data["role"], tier=data["tier"],
        faction_existing_coverage=data["faction_existing_coverage"],
        evidence_confidence=data["evidence_confidence"],
        guidance_notes=tuple(data.get("guidance_notes") or ()),
        guidance_confidence=data.get("guidance_confidence"),
        capability_dimension=data.get("capability_dimension"),
        vector_score=data.get("vector_score"),
        vector_confidence=data.get("vector_confidence"),
        evidence_class=EvidenceClass(data.get("evidence_class") or EvidenceClass.INFERRED_MECHANICS.value),
    )


def _restore_native(data: dict[str, Any]) -> NativeRecommendation:
    return NativeRecommendation(
        role=data["role"], hull_id=data["hull_id"], capability_score=data["capability_score"], rank=data["rank"],
        confidence=data.get("confidence", 1.0),
        archetype_scores=dict(data.get("archetype_scores") or {}),
        archetype_evidence=_restore_archetype_evidence(data.get("archetype_evidence")),
        diversity_reason=data.get("diversity_reason"),
        build_archetype_id=data.get("build_archetype_id"),
        build_archetype_label=data.get("build_archetype_label"),
        build_compatibility=data.get("build_compatibility"),
        build_confidence=data.get("build_confidence"),
        build_maturity=data.get("build_maturity"),
        recommendation_score=data.get("recommendation_score"),
        incremental_capability_gain=data.get("incremental_capability_gain", 0.0),
        evidence_class=EvidenceClass(data.get("evidence_class") or EvidenceClass.INFERRED_MECHANICS.value),
    )


def _restore_retrofit(data: dict[str, Any]) -> RetrofitRecommendation:
    return RetrofitRecommendation(
        role=data["role"], hull_id=data["hull_id"], variant_id=data["variant_id"],
        capability_score=data["capability_score"], role_match_before=data["role_match_before"],
        role_match_after=data["role_match_after"], quality_gain=data["quality_gain"],
        changes=data["changes"], change_cost=data["change_cost"], rank=data["rank"],
        confidence=data.get("confidence", 1.0),
        archetype_scores=dict(data.get("archetype_scores") or {}),
        archetype_evidence=_restore_archetype_evidence(data.get("archetype_evidence")),
        diversity_reason=data.get("diversity_reason"),
        build_archetype_id=data.get("build_archetype_id"),
        build_archetype_label=data.get("build_archetype_label"),
        build_compatibility=data.get("build_compatibility"),
        build_confidence=data.get("build_confidence"),
        build_maturity=data.get("build_maturity"),
        recommendation_score=data.get("recommendation_score"),
        incremental_capability_gain=data.get("incremental_capability_gain", 0.0),
        retrofit_disruption=data.get("retrofit_disruption", 0.0),
        role_distortion=data.get("role_distortion", 0.0),
        knowledge_template_ids=tuple(data.get("knowledge_template_ids") or ()),
        knowledge_guidance_confidence=data.get("knowledge_guidance_confidence"),
        evidence_class=EvidenceClass(data.get("evidence_class") or EvidenceClass.INFERRED_MECHANICS.value),
    )


def _restore_acquisition(data: dict[str, Any]) -> AcquisitionRecommendation:
    return AcquisitionRecommendation(
        role=data["role"], hull_id=data["hull_id"], capability_score=data["capability_score"],
        affinity=data["affinity"], owning_faction_ids=tuple(data.get("owning_faction_ids") or ()),
        preference_weight=data["preference_weight"], rank=data["rank"],
        confidence=data.get("confidence", 1.0),
        archetype_scores=dict(data.get("archetype_scores") or {}),
        archetype_evidence=_restore_archetype_evidence(data.get("archetype_evidence")),
        diversity_reason=data.get("diversity_reason"),
        build_archetype_id=data.get("build_archetype_id"),
        build_archetype_label=data.get("build_archetype_label"),
        build_compatibility=data.get("build_compatibility"),
        build_confidence=data.get("build_confidence"),
        build_maturity=data.get("build_maturity"),
        recommendation_score=data.get("recommendation_score"),
        incremental_capability_gain=data.get("incremental_capability_gain", 0.0),
        evidence_class=EvidenceClass(data.get("evidence_class") or EvidenceClass.INFERRED_MECHANICS.value),
    )


def gap_recommendation_result_from_payload(payload: dict[str, Any]) -> GapRecommendationResult:
    """Reconstruct a `GapRecommendationResult` from a cached JSON payload.

    Reverses `gap_recommendation_result_to_payload` field-for-field --
    every tuple- and `EvidenceClass`-typed field is rebuilt explicitly so a
    cache hit compares equal (`==`) to the same fresh computation. A plain
    JSON round-trip alone would leave tuples as lists, which fail dataclass
    equality against the real, freshly-computed result.
    """
    return GapRecommendationResult(
        faction_id=payload["faction_id"],
        gaps=tuple(_restore_capability_gap(item) for item in payload.get("gaps", ())),
        native_recommendations={
            role: tuple(_restore_native(item) for item in items)
            for role, items in (payload.get("native_recommendations") or {}).items()
        },
        unaddressed_gaps=tuple(payload.get("unaddressed_gaps") or ()),
        retrofit_recommendations={
            role: tuple(_restore_retrofit(item) for item in items)
            for role, items in (payload.get("retrofit_recommendations") or {}).items()
        },
        acquisition_recommendations={
            role: tuple(_restore_acquisition(item) for item in items)
            for role, items in (payload.get("acquisition_recommendations") or {}).items()
        },
        fully_unaddressed_gaps=tuple(payload.get("fully_unaddressed_gaps") or ()),
        officer_guidance=tuple(payload.get("officer_guidance") or ()),
    )


@dataclass(frozen=True)
class WhyNotExplanation:
    role: str
    hull_id: str
    resolved: bool  # is hull_id even a real, resolved known hull of this faction?
    capability_score: float | None  # this hull's real role_compatibility score, if resolved
    rank: int | None  # 1-based rank among ALL positive-scoring known hulls for this role (not just the top N recommended)
    total_candidates: int  # how many known hulls scored above zero for this role at all
    recommended: bool  # was this hull actually inside the top gap_recommendation_count?
    best_score: float | None  # the #1-ranked hull's score, for comparison
    reason: str
    archetype_scores: dict[str, float] = field(default_factory=dict)
    archetype_evidence: dict[str, tuple[str, ...]] = field(default_factory=dict)
    diversity_reason: str | None = None


def _rank_hull_among_build_candidates(
    role: str, hull_id: str, resolved_hulls: list, registry: Registry, heuristic_set: str, max_recommendations: int,
) -> tuple[int | None, int, float | None, bool, dict[str, str], float | None]:
    """Hull-level rank/recommended status collapsed from the exact same
    `Hull + BuildArchetype` ranking and diversity selection
    `recommend_native_solutions`'s build-aware branch uses (no knowledge
    pack or non-default constraints, matching `explain_native_candidate`'s
    own simpler scope), so this can never disagree with the real
    recommendation for equivalent inputs. Returns
    (rank, total_candidates, best_score, recommended, selection_reasons_by_hull, cutoff_score).
    """
    ranked = _rank_build_candidates_for_role(role, resolved_hulls, registry, heuristic_set)
    best_by_hull: dict[str, float] = {}
    for score, candidate_id, _build in ranked:
        if candidate_id not in best_by_hull:  # ranked is already sorted best-first
            best_by_hull[candidate_id] = score
    distinct_ranked = sorted(best_by_hull.items(), key=lambda item: (-item[1], item[0]))
    total_candidates = len(distinct_ranked)
    best_score = distinct_ranked[0][1] if distinct_ranked else None
    rank = next((index + 1 for index, (candidate_id, _score) in enumerate(distinct_ranked) if candidate_id == hull_id), None)
    selected = _diverse_build_shortlist(ranked, max_recommendations, heuristic_set, registry)
    selection_reasons: dict[str, str] = {}
    for _score, candidate_id, _build, reason in selected:
        selection_reasons.setdefault(candidate_id, reason)
    recommended = hull_id in selection_reasons
    cutoff_score = min((score for score, _, _, _ in selected), default=None)
    return rank, total_candidates, best_score, recommended, selection_reasons, cutoff_score


def explain_native_candidate(faction: Faction, registry: Registry, role: str, hull_id: str, heuristic_set: str = "baseline_0.2") -> WhyNotExplanation:
    """Answer "why wasn't <hull_id> recommended for <role>?" using the same
    ranking `recommend_native_solutions` already computes, without
    re-deriving a separate explanation mechanism -- every number here is
    read directly off the real ranked candidate list, not a new inference.

    `recommend_native_solutions` itself branches on whether the heuristic
    set is build-aware (`baseline_0.4`+, including the CLI's real default
    `baseline_0.7`): it ranks `Hull + BuildArchetype` combinations via
    `_rank_build_candidates_for_role`/`_diverse_build_shortlist`, not the
    legacy hull-only `_rank_candidates_for_role`/`_diverse_hull_shortlist`
    pair -- and `_diverse_build_shortlist` always performs similarity-based
    diversity selection (unlike the legacy pair, which only does so under
    `baseline_0.3`), so a build-aware shortlist is never simply "top N by
    raw score." This function must branch the exact same way -- found live
    against the real 148-mod install: without this branch, `svg why-not
    xlu MISSILE_SUPPORT xlu_chrominus` (no `--build-archetype`) reported
    "Recommended: ranked 2 of 13" under `baseline_0.7`, while the real
    `svg recommend xlu` result for that exact role never lists
    `xlu_chrominus` at all (its true native shortlist is `xlu_calc`,
    `xlu_wolfsteel`, `xlu_oxide`) -- exactly the "second inference
    mechanism that could disagree with the actual recommendations" this
    docstring says doesn't exist.
    """
    heuristics = get_heuristic_set(heuristic_set).values
    max_recommendations = int(heuristics["gap_recommendation_count"])
    resolved_hulls = _resolved_known_hulls(faction, registry)
    hull = registry.hulls.by_id.get(hull_id)
    if hull is None or hull_id not in {h.id for h in resolved_hulls}:
        return WhyNotExplanation(role, hull_id, False, None, None, 0, False, None, "Not a resolved known hull of this faction.")
    own_score = classify_hull(hull).role_compatibility.get(role, 0.0)
    build_aware = "build_archetype_viable_min_compatibility" in heuristics
    if build_aware:
        rank, total_candidates, best_score, recommended, selection_reasons, cutoff_score = _rank_hull_among_build_candidates(
            role, hull_id, resolved_hulls, registry, heuristic_set, max_recommendations,
        )
    else:
        ranked = _rank_candidates_for_role(role, resolved_hulls)
        best_score = ranked[0][0] if ranked else None
        total_candidates = len(ranked)
        rank = next((index + 1 for index, (_, candidate_id) in enumerate(ranked) if candidate_id == hull_id), None)
        selection = _diverse_hull_shortlist(ranked, registry, max_recommendations, heuristic_set)
        selection_reasons = {candidate_id: reason for _, candidate_id, reason in selection}
        recommended = hull_id in selection_reasons
        cutoff_score = ranked[max_recommendations - 1][0] if len(ranked) >= max_recommendations else None
    if own_score <= 0.0:
        return WhyNotExplanation(role, hull_id, True, own_score, None, total_candidates, False, best_score, f"Scores 0.0 on {role} -- no real evidence of this capability at all.")
    archetype = infer_mechanical_archetypes(hull, registry)
    # Diversity phrasing applies whenever the actual selection could deviate
    # from a pure top-N-by-score cutoff: build-aware ranking always uses
    # `_diverse_build_shortlist`'s similarity-based selection; the legacy
    # hull-only path only does under `baseline_0.3`.
    diversity_selection = build_aware or heuristic_set == "baseline_0.3"
    if recommended:
        reason = f"Recommended: ranked {rank} of {total_candidates} real known hulls scoring above zero on {role}. {selection_reasons[hull_id]}"
    elif diversity_selection:
        cutoff = cutoff_score if cutoff_score is not None else 0.0
        reason = f"Not selected after score-first diversity: ranked {rank} of {total_candidates}; score {own_score:.3f} versus selected cutoff {cutoff:.3f}. Its inferred functional-role/archetype evidence was not a more competitive distinct solution."
    else:
        gap_to_cutoff = (cutoff_score if cutoff_score is not None else own_score) - own_score
        reason = f"Ranked {rank} of {total_candidates}, {gap_to_cutoff:.3f} below the lowest-scoring hull that was recommended (top {max_recommendations} shown)."
    return WhyNotExplanation(role, hull_id, True, own_score, rank, total_candidates, recommended, best_score, reason,
                             archetype.compatibility_scores, archetype.evidence_by_archetype,
                             selection_reasons.get(hull_id))


@dataclass(frozen=True)
class RetrofitWhyNotExplanation:
    role: str
    hull_id: str
    considered: bool  # was this hull among the native leg's top-ranked structurally-capable candidates retrofit search even examines?
    has_real_variant: bool | None  # None only when not considered
    variant_id: str | None  # the specific real variant a retrofit pass would improve, if any
    role_match_before: float | None
    role_match_after: float | None
    quality_gain: float | None
    recommended: bool
    reason: str
    recommendation_score: float | None = None
    rank: int | None = None
    scoring_components: dict[str, float] = field(default_factory=dict)


def explain_retrofit_candidate(faction: Faction, registry: Registry, role: str, hull_id: str, heuristic_set: str = "baseline_0.2") -> RetrofitWhyNotExplanation:
    """Answer "why wasn't <hull_id> recommended for retrofit on <role>?"
    using the exact same real search `recommend_retrofit_solutions`
    already runs for this one (role, hull_id) pair -- not a second
    inference mechanism. Retrofit search only ever considers the native
    leg's own top `gap_recommendation_count` structurally-capable
    candidates (see the module docstring for why: refit can't raise a
    hull's structural capability_score), so a hull outside that shortlist
    is reported as "not considered" distinctly from one that was
    considered but had nothing to improve.
    """
    heuristics = get_heuristic_set(heuristic_set).values
    max_recommendations = int(heuristics["gap_recommendation_count"])
    min_gain = heuristics["refit_min_quality_gain"]
    resolved_hulls = _resolved_known_hulls(faction, registry)
    ranked = _rank_candidates_for_role(role, resolved_hulls)[:max_recommendations]
    considered_ids = {candidate_hull_id for _, candidate_hull_id in ranked}
    if hull_id not in considered_ids:
        return RetrofitWhyNotExplanation(role, hull_id, False, None, None, None, None, None, False, "Not among the native leg's top structurally-capable candidates for this role -- retrofit search only examines those (see recommend_native_solutions).")
    profile_id = _ROLE_TO_PROFILE.get(role)
    if profile_id is None:
        return RetrofitWhyNotExplanation(role, hull_id, True, None, None, None, None, None, False, f"No quality-profile mapping exists for capability axis {role!r} (see _ROLE_TO_PROFILE).")
    best = _best_retrofit_for_hull(hull_id, profile_id, registry, faction, heuristic_set, min_gain)
    if best is None:
        variants = _variants_for_hull(hull_id, registry)
        if not variants:
            return RetrofitWhyNotExplanation(role, hull_id, True, False, None, None, None, None, False, "This hull has no real, indexed variant to retrofit.")
        return RetrofitWhyNotExplanation(role, hull_id, True, True, None, None, None, None, False, f"This hull has {len(variants)} real variant(s), but none improve role_match by at least {min_gain:.2f} via IMPROVE_ROLE_MATCH -- already close to its own structural potential, or not a legal/scoreable starting point.")
    gain, variant, result = best
    # recommend_retrofit_solutions doesn't apply a further recommendation
    # cutoff beyond the native leg's own shortlist -- every hull with a
    # real, positive-gain retrofit is included, so rank here is purely
    # informational (there is no "ranked but below cutoff" case for this
    # leg the way the native leg has one).
    others: list[tuple[float, str]] = []
    for _, candidate_hull_id in ranked:
        candidate_best = _best_retrofit_for_hull(candidate_hull_id, profile_id, registry, faction, heuristic_set, min_gain)
        if candidate_best is not None:
            others.append((candidate_best[2].after_score, candidate_hull_id))
    others.sort(key=lambda item: (-item[0], item[1]))
    rank = next(index + 1 for index, (_, candidate_id) in enumerate(others) if candidate_id == hull_id)
    reason = f"Recommended: retrofitting {variant.id!r} improves role_match from {result.before_score:.1f} to {result.after_score:.1f} (rank {rank} of {len(others)} real retrofit opportunities found for this gap)."
    return RetrofitWhyNotExplanation(
        role, hull_id, True, True, variant.id, result.before_score, result.after_score, gain, True, reason,
        result.after_score, rank,
        {"quality_before": result.before_score, "quality_after": result.after_score, "quality_gain": gain,
         "change_cost": result.total_change_cost},
    )


@dataclass(frozen=True)
class AcquisitionWhyNotExplanation:
    role: str
    hull_id: str
    resolved: bool  # is hull_id even a real, indexed hull?
    is_native: bool  # already known by this faction -- acquisition doesn't apply, see native/retrofit legs instead
    capability_score: float | None
    affinity: str | None
    rank: int | None
    total_candidates: int
    recommended: bool
    reason: str
    recommendation_score: float | None = None
    preference_weight: float | None = None
    scoring_components: dict[str, float] = field(default_factory=dict)


def explain_acquisition_candidate(
    faction: Faction,
    registry: Registry,
    role: str,
    hull_id: str,
    heuristic_set: str = "baseline_0.2",
    knowledge_pack: ResolvedKnowledgePack | None = None,
) -> AcquisitionWhyNotExplanation:
    """Answer "why wasn't <hull_id> recommended for acquisition on <role>?"
    using the exact same real ranking `recommend_acquisition_solutions`
    already computes for this role -- every number here is read off that
    real ranked list, not a new inference.
    """
    heuristics = get_heuristic_set(heuristic_set).values
    max_recommendations = int(heuristics["gap_recommendation_count"])
    hull = registry.hulls.by_id.get(hull_id)
    if hull is None:
        return AcquisitionWhyNotExplanation(role, hull_id, False, False, None, None, None, 0, False, "Not a real, indexed hull.")
    native_hull_ids = {known_id for known_id in faction.known_hulls if known_id in registry.hulls.by_id}
    if hull_id in native_hull_ids:
        return AcquisitionWhyNotExplanation(role, hull_id, True, True, None, None, None, 0, False, "This hull is already known natively by this faction -- see the native/retrofit legs, not acquisition.")
    own_score = classify_hull(hull).role_compatibility.get(role, 0.0)
    if own_score <= 0.0:
        return AcquisitionWhyNotExplanation(role, hull_id, True, False, own_score, None, None, 0, False, f"Scores 0.0 on {role} -- no real evidence of this capability at all.")
    candidates: list[tuple[float, float, str, str]] = []  # (composite, raw capability, hull_id, affinity)
    for other_id, other_hull in registry.hulls.by_id.items():
        if other_id in native_hull_ids:
            continue
        score = classify_hull(other_hull).role_compatibility.get(role, 0.0)
        if score <= 0.0:
            continue
        affinity = classify_equipment_affinity(
            other_id, "hulls", registry, requesting_faction_id=faction.id,
            knowledge_pack=knowledge_pack,
        )
        weight = heuristics[f"affinity_preference_{affinity.affinity.lower()}"]
        candidates.append((score * weight, score, other_id, affinity.affinity))
    candidates.sort(key=lambda item: (-item[0], item[2]))
    rank = next(index + 1 for index, (_, _, candidate_id, _) in enumerate(candidates) if candidate_id == hull_id)
    own_affinity = next(affinity for _, _, candidate_id, affinity in candidates if candidate_id == hull_id)
    own_composite = next(composite for composite, _, candidate_id, _ in candidates if candidate_id == hull_id)
    preference_weight = heuristics[f"affinity_preference_{own_affinity.lower()}"]
    recommended = rank <= max_recommendations
    if recommended:
        reason = f"Recommended: ranked {rank} of {len(candidates)} real non-native candidates scoring above zero on {role} ({own_affinity.lower()} affinity)."
    else:
        gap_to_cutoff = candidates[max_recommendations - 1][0] - own_composite
        reason = f"Ranked {rank} of {len(candidates)}, {gap_to_cutoff:.3f} below the lowest-ranked hull that was recommended (top {max_recommendations} shown)."
    return AcquisitionWhyNotExplanation(
        role, hull_id, True, False, own_score, own_affinity, rank, len(candidates), recommended, reason,
        own_composite, preference_weight,
        {"functional_capability": own_score, "affinity_preference": preference_weight, "recommendation_score": own_composite},
    )


@dataclass(frozen=True)
class CombinedWhyNotExplanation:
    """All 3 implemented legs' answer to "why wasn't <hull_id> recommended
    for <role>?" in one call -- a real caller asking this question wants
    the full picture, not three separate lookups that could silently
    disagree about which leg's ranking is authoritative."""

    native: WhyNotExplanation
    retrofit: RetrofitWhyNotExplanation
    acquisition: AcquisitionWhyNotExplanation


@dataclass(frozen=True)
class BuildWhyNotExplanation:
    """Build-specific counterpart to the legacy hull-level Why-Not result."""

    role: str
    hull_id: str
    build_archetype_id: str
    resolved: bool
    build: BuildArchetypeProfile | None
    recommended_legs: tuple[str, ...]
    reason: str
    recommendation_score: float | None = None
    rank: int | None = None
    selected_cutoff: float | None = None
    scoring_components: dict[str, float] = field(default_factory=dict)
    diversity_evidence: str | None = None
    leg_scoring_components: dict[str, dict[str, float]] = field(default_factory=dict)


def explain_candidate(
    faction: Faction,
    registry: Registry,
    role: str,
    hull_id: str,
    heuristic_set: str = "baseline_0.2",
    knowledge_pack: ResolvedKnowledgePack | None = None,
) -> CombinedWhyNotExplanation:
    return CombinedWhyNotExplanation(
        explain_native_candidate(faction, registry, role, hull_id, heuristic_set),
        explain_retrofit_candidate(faction, registry, role, hull_id, heuristic_set),
        explain_acquisition_candidate(faction, registry, role, hull_id, heuristic_set, knowledge_pack),
    )


def explain_build_candidate(
    faction: Faction, registry: Registry, role: str, hull_id: str, build_archetype_id: str,
    heuristic_set: str = "baseline_0.2", knowledge_pack: ResolvedKnowledgePack | None = None,
    campaign_stage: str | None = None,
) -> BuildWhyNotExplanation:
    hull = registry.hulls.by_id.get(hull_id)
    if hull is None:
        return BuildWhyNotExplanation(role, hull_id, build_archetype_id, False, None, (), "Not a real, indexed hull.")
    if "build_archetype_viable_min_compatibility" not in get_heuristic_set(heuristic_set).values:
        return BuildWhyNotExplanation(role, hull_id, build_archetype_id, True, None, (), f"Heuristic set {heuristic_set} predates build-archetype recommendations.")
    build = next((item for item in infer_build_archetypes(hull, registry, heuristic_set) if item.build_id == build_archetype_id), None)
    if build is None:
        return BuildWhyNotExplanation(role, hull_id, build_archetype_id, True, None, (), "This hull has no mechanically supported viable or Experimental path with that build archetype id.")
    constraints = RecommendationConstraints(campaign_stage=campaign_stage)
    result = recommend_gap_solutions(faction, registry, heuristic_set, knowledge_pack, constraints)
    legs = tuple(name for name, recommendations in (
        ("NATIVE", result.native_recommendations.get(role, ())),
        ("RETROFIT", result.retrofit_recommendations.get(role, ())),
        ("ACQUISITION", result.acquisition_recommendations.get(role, ())),
    ) if any(item.hull_id == hull_id and item.build_archetype_id == build_archetype_id for item in recommendations))
    # Read components from the recommendation records themselves.  This is
    # intentionally not a second scoring implementation: selected legs carry
    # the exact values used to rank them.
    leg_components: dict[str, dict[str, float]] = {}
    native = next((item for item in result.native_recommendations.get(role, ()) if item.hull_id == hull_id and item.build_archetype_id == build_archetype_id), None)
    if native is not None:
        leg_components["NATIVE"] = {
            "functional_capability": native.capability_score,
            "build_compatibility": native.build_compatibility or 0.0,
            "recommendation_score": native.recommendation_score or 0.0,
        }
    retrofit = next((item for item in result.retrofit_recommendations.get(role, ()) if item.hull_id == hull_id and item.build_archetype_id == build_archetype_id), None)
    if retrofit is not None:
        leg_components["RETROFIT"] = {
            "quality_before": retrofit.role_match_before,
            "quality_after": retrofit.role_match_after,
            "quality_gain": retrofit.quality_gain,
            "change_cost": retrofit.change_cost,
            "retrofit_disruption": retrofit.retrofit_disruption,
            "role_distortion": retrofit.role_distortion,
            "recommendation_score": retrofit.recommendation_score or 0.0,
        }
    acquisition = next((item for item in result.acquisition_recommendations.get(role, ()) if item.hull_id == hull_id and item.build_archetype_id == build_archetype_id), None)
    if acquisition is not None:
        leg_components["ACQUISITION"] = {
            "functional_capability": acquisition.capability_score,
            "affinity_preference": acquisition.preference_weight,
            "build_compatibility": acquisition.build_compatibility or 0.0,
            "incremental_capability_gain": acquisition.incremental_capability_gain,
            "recommendation_score": acquisition.recommendation_score or 0.0,
        }
    resolved_hulls = _resolved_known_hulls(faction, registry)
    ranked = _rank_build_candidates_for_role(
        role, resolved_hulls, registry, heuristic_set, knowledge_pack, faction.id,
        campaign_stage=campaign_stage,
    )
    own = next((item for item in ranked if item[1] == hull_id and item[2].build_id == build_archetype_id), None)
    if own is None:
        return BuildWhyNotExplanation(
            role, hull_id, build_archetype_id, True, build, legs,
            f"This build is mechanically inferred but has no positive {role} functional-capability score, so it is not eligible for this recommendation leg.",
            scoring_components={"build_compatibility": build.compatibility, "functional_capability": 0.0},
        )
    selected = _diverse_build_shortlist(ranked, int(get_heuristic_set(heuristic_set).values["gap_recommendation_count"]), heuristic_set, registry)
    selected_keys = {(item[1], item[2].build_id): item for item in selected}
    rank = next(index + 1 for index, item in enumerate(ranked) if item[1] == hull_id and item[2].build_id == build_archetype_id)
    cutoff = min((item[0] for item in selected), default=None)
    components = {
        "functional_capability": classify_hull(hull).role_compatibility.get(role, 0.0),
        "build_compatibility": build.compatibility,
        "knowledge_pack_bias": round(own[0] / (classify_hull(hull).role_compatibility.get(role, 0.0) * build.compatibility), 6) if classify_hull(hull).role_compatibility.get(role, 0.0) and build.compatibility else 1.0,
        "recommendation_score": own[0],
    }
    selected_item = selected_keys.get((hull_id, build_archetype_id))
    if legs or selected_item:
        diversity = selected_item[3] if selected_item else None
        reason = f"Recommended as a Hull + BuildArchetype solution in {', '.join(legs) or 'the native ranking'}; rank {rank} of {len(ranked)} at exact score {own[0]:.6f}."
    else:
        diversity = None
        reason = f"Not selected for {role}: rank {rank} of {len(ranked)}, exact score {own[0]:.6f} versus selected cutoff {(cutoff or 0.0):.6f}. Compatibility is {build.compatibility:.3f}, maturity {build.maturity}; score-first mechanical/tactical diversity selected more competitive combinations."
    return BuildWhyNotExplanation(role, hull_id, build_archetype_id, True, build, legs, reason, own[0], rank, cutoff, components, diversity, leg_components)
