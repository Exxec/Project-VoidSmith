"""Offline static recognition of a bounded subset of HullMod Java effects."""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path

from starsector_variant_generator.core.evidence import EvidenceClass, EvidenceRecord
from starsector_variant_generator.core.models import Hullmod

API_EFFECT_REGISTRY_VERSION = "starsector-api-effects-0.2"
_CALLS = {
    "getMaxSpeed": ("max_speed", "SELF"), "getAcceleration": ("acceleration", "SELF"),
    "getDeceleration": ("deceleration", "SELF"), "getTurnAcceleration": ("turn_acceleration", "SELF"),
    "getMaxTurnRate": ("max_turn_rate", "SELF"), "getFluxDissipation": ("flux_dissipation", "SELF"),
    "getFluxCapacity": ("flux_capacity", "SELF"), "getArmorBonus": ("armor_rating", "SELF"),
    "getHullBonus": ("hull_hp", "SELF"), "getSuppliesPerMonth": ("supplies_per_month", "SELF"),
    "getBallisticWeaponFluxCostMod": ("ballistic_weapon_flux_cost", "SELF"),
    "getEnergyWeaponFluxCostMod": ("energy_weapon_flux_cost", "SELF"),
    "getMissileWeaponFluxCostMod": ("missile_weapon_flux_cost", "SELF"),
    "getWeaponTurnRateBonus": ("weapon_turn_rate", "SELF"), "getSightRadiusMod": ("sight_radius", "SELF"),
}
_MODIFIER = re.compile(r"stats\.(get\w+)\(\)\.(modifyFlat|modifyPercent|modifyMult)\([^,]+,\s*([A-Za-z_][\w]*|[-+]?\d+(?:\.\d+)?)[fFdD]?\)")
_CONSTANT = re.compile(r"(?:static\s+final\s+)?(?:float|double|int)\s+(\w+)\s*=\s*([-+]?\d+(?:\.\d+)?)")
_HULL_SIZE = re.compile(r"ShipAPI\.HullSize\.([A-Z_]+)")


@lru_cache(maxsize=256)
def _java_sources(source_root: str) -> tuple[tuple[Path, str], ...]:
    """Read each local Java source once per scan process/source root.

    This is deliberately an in-memory scan-local cache, not a persistent cache:
    source files remain the source of truth for each independent scan.
    """
    root = Path(source_root)
    sources: list[tuple[Path, str]] = []
    for path in sorted(root.rglob("*.java")):
        try:
            sources.append((path, path.read_text(encoding="utf-8")))
        except (OSError, UnicodeError):
            continue
    return tuple(sources)

@dataclass(frozen=True)
class HullmodEffectRecord:
    target_stat: str
    operation: str
    numeric_value: float
    applicability: str
    condition: str | None
    source_location: str
    confidence: float
    api_registry_version: str
    hull_size: str | None = None

@dataclass(frozen=True)
class HullmodStaticAnalysis:
    hullmod_id: str
    source_files: tuple[str, ...]
    source_association: str
    recognized_effects: tuple[HullmodEffectRecord, ...]
    unknown_scripted_portions: tuple[str, ...]
    confidence: float
    evidence: tuple[EvidenceRecord, ...] = ()

def analyze_hullmod_sources(hullmod: Hullmod, source_root: Path | None) -> HullmodStaticAnalysis:
    if source_root is None or not source_root.is_dir():
        return HullmodStaticAnalysis(hullmod.id, (), "NO_LOCAL_SOURCE", (), ("UNKNOWN_SCRIPTED_EFFECT: no readable local Java source root.",), 0.0, ())
    script = str(hullmod.raw.get("script", hullmod.raw.get("scriptClass", "")))
    script_class = script.rsplit(".", 1)[-1] if script else ""
    declared_candidates: list[tuple[Path, str]] = []
    reference_candidates: list[tuple[Path, str]] = []
    for path, text in _java_sources(str(source_root.resolve())):
        # The CSV script class is the authoritative local association.  Do not
        # merge classes that merely mention a hullmod ID when that class exists:
        # doing so makes unrelated API calls look like hullmod effects.
        if script_class and path.stem == script_class:
            declared_candidates.append((path, text))
        elif hullmod.id in text:
            reference_candidates.append((path, text))
    candidates = declared_candidates or reference_candidates
    association = "DECLARED_SCRIPT_CLASS" if declared_candidates else "ID_REFERENCE_FALLBACK"
    if not candidates:
        return HullmodStaticAnalysis(hullmod.id, (), "NO_ASSOCIATED_CLASS", (), ("UNKNOWN_SCRIPTED_EFFECT: no local Java class could be associated with this hullmod.",), 0.0, ())
    effects, unknown, evidence = [], [], []
    if association == "ID_REFERENCE_FALLBACK":
        unknown.append("UNKNOWN_SCRIPTED_EFFECT: source association is an ID-reference fallback, not a declared script class.")
    for path, text in candidates:
        constants = {name: float(value) for name, value in _CONSTANT.findall(text)}
        lines = text.splitlines()
        for line_no, line in enumerate(lines, 1):
            match = _MODIFIER.search(line)
            if match and match.group(1) in _CALLS:
                value = constants.get(match.group(3))
                if value is None:
                    try: value = float(match.group(3))
                    except ValueError: unknown.append(f"UNKNOWN_SCRIPTED_EFFECT: {path}:{line_no}: non-literal modifier value {match.group(3)!r}"); continue
                operation = {"modifyFlat": "FLAT_ADD", "modifyPercent": "PERCENT_ADD", "modifyMult": "MULTIPLY"}[match.group(2)]
                stat, applicability = _CALLS[match.group(1)]
                location = f"{path}:{line_no}"
                hull_size = _enclosing_hull_size(lines, line_no - 1)
                condition = f"ShipAPI.HullSize.{hull_size}" if hull_size else ("conditional context not statically interpreted" if "if (" in line else None)
                effect = HullmodEffectRecord(stat, operation, value, applicability, condition, location, .9, API_EFFECT_REGISTRY_VERSION, hull_size)
                effects.append(effect)
                evidence.append(EvidenceRecord(
                    evidence_id=f"hullmod:{hullmod.id}:java:{path.stem}:{line_no}:{stat}", entity_id=hullmod.id,
                    source_file=str(path), source_class=path.stem, source_line_or_symbol=str(line_no),
                    evidence_type="HULLMOD_EFFECT", extracted_value=asdict(effect), confidence=.9,
                    parser_or_adapter=f"api-effect-registry:{API_EFFECT_REGISTRY_VERSION}",
                    evidence_class=EvidenceClass.LOCAL_SOURCE_CODE,
                ))
            elif ".modify" in line or "stats." in line and "get" in line:
                unknown.append(f"UNKNOWN_SCRIPTED_EFFECT: {path}:{line_no}: unrecognized API modifier expression.")
    if not effects and not unknown:
        unknown.append("UNKNOWN_SCRIPTED_EFFECT: associated local Java class contains no recognized normalized stat modifier.")
    confidence = .9 if effects and not unknown else (.6 if effects else .2)
    return HullmodStaticAnalysis(hullmod.id, tuple(str(path) for path, _ in candidates), association, tuple(effects), tuple(unknown), confidence, tuple(evidence))

def static_analysis_record(analysis: HullmodStaticAnalysis) -> dict:
    return asdict(analysis)


def _enclosing_hull_size(lines: list[str], line_index: int) -> str | None:
    """Find the nearest simple local hull-size branch without interpreting code flow.

    This is deliberately bounded to the current lexical block. Nested control
    flow, variables, and method calls remain represented by the separate
    condition/unknown evidence rather than being guessed.
    """
    depth = 0
    for source in reversed(lines[:line_index]):
        depth += source.count("}") - source.count("{")
        match = _HULL_SIZE.search(source)
        if match and "if" in source and depth <= 1:
            return match.group(1)
        if depth > 1:
            break
    return None
